# Как добавлять фичу

Правила и идиомы проекта на примере реальных фич. Цель — новый код выглядит так же, как существующий: каждый слой делает своё и не знает лишнего.

## Слои за минуту

```
HTTP-запрос
   │
   ▼
handler/v1   разобрать запрос → DTO → вызвать сервис → ответ или ошибка через httpx
   │         (здесь же логирование: httpx пишет причину ошибки в лог)
   ▼
service      бизнес-сценарий: владелец, состояние, правила model, вызовы репозиториев
   │
   ▼
model        сущности и бизнес-правила без HTTP и SQL: конструкторы, Valid(), CanChangeTo()
   │
   ▼
repository   простой SQL без бизнес-условий, перевод ошибок БД в model-ошибки
```

| Слой | Отвечает за | НЕ делает |
|---|---|---|
| `handler/v1` | парсинг JSON, path и query; проверку **формата** (`validate`-теги); маппинг DTO ↔ model; HTTP-статус успеха; ответ с ошибкой через `httpx` | бизнес-проверки, обращения к репозиториям, свой `slog` |
| `service` | сценарий целиком: проверку владельца, чтение состояния, вызов правил `model`, запись; оборачивание ошибок контекстом | HTTP и JSON, SQL, логирование |
| `model` | сущности, enum, нормализацию (trim, lowercase, теги), **бизнес-валидацию**, переходы статусов | ввод-вывод, json-теги, знание о БД |
| `repository` | простой SQL (список — `count` + выборка), маппинг строк в model, перевод `ErrNoRows`/`23505`/`23503` в model-ошибки, optimistic lock | бизнес-условия в `WHERE` (`status = 'open'`), проверку владельца, логирование |

## Порядок работы

1. **model** — новые поля, enum, конструктор или метод с правилами.
2. **Миграция** (если меняется схема): `make migration name=add_x`, затем `make migrate` (при `MIGRATIONS_ENABLED=true`) или `make db-schema`. Миграции должны быть идемпотентными (`IF NOT EXISTS`): `make db-schema` прогоняет все файлы заново.
   Уже применённые миграции не править — только новая. Для новой таблицы или колонки с неочевидным смыслом (допустимые значения `TEXT`, `NULL` как «не указано», версия строки) в той же миграции добавить `COMMENT ON`, в `Down` — `COMMENT ON ... IS NULL`. Колонкам вроде `id`, `title`, `created_at` комментарий не нужен.
3. **repository** — метод в интерфейсе `internal/repository/repository.go`, реализация в `pgrepo`, затем `make mocks`.
4. **service** — новый файл на метод (`close_vacancy.go`), метод в интерфейсе `internal/service/service.go`, тест (`close_vacancy_test.go`).
5. **handler** — DTO в `*_dto.go`, метод хендлера, маршрут в `internal/handler/router.go`.
6. **Документация** — `docs/openapi.yaml` и README (таблица ручек, бизнес-модель, если поменялись правила).
7. **Проверка** — `go vet ./... && make test`, ручной вызов через Swagger или `curl`.

---

## Сквозной пример: «Закрыть вакансию»

`POST /api/v1/employer/vacancies/{id}/close`. Закрыть можно только свою открытую вакансию.

**Маршрут** — роль задаётся обёрткой, а не проверкой в хендлере:

```go
// internal/handler/router.go
mux.Handle("POST /api/v1/employer/vacancies/{id}/close", asEmployer(empH.CloseVacancy))
```

**Handler** — только HTTP: достать id, вызвать сервис, ответить:

```go
// internal/handler/v1/employer.go
func (h *employerHandler) CloseVacancy(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	if err := h.svc.CloseVacancy(r.Context(), userID(r), id); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
```

**Service** — сценарий: чья вакансия, в каком она состоянии, что записать:

```go
// internal/service/employer/close_vacancy.go
func (s *service) CloseVacancy(ctx context.Context, employerID, vacancyID int64) error {
	v, err := s.ownedVacancy(ctx, employerID, vacancyID) // чужая → 404
	if err != nil {
		return err
	}
	if v.Status == model.VacancyClosed {
		return model.Conflict("vacancy already closed") // → 409
	}
	v.Status = model.VacancyClosed
	if err := s.vacancies.UpdateStatus(ctx, v); err != nil {
		return fmt.Errorf("close vacancy: %w", err)
	}
	return nil
}
```

**Repository** — один `UPDATE`, без бизнес-условий. `updated_at` в `WHERE` — optimistic lock: если строку изменили после чтения в сервисе, запись не пройдёт:

```go
// internal/repository/pgrepo/vacancy.go
func (r *vacancyRepo) UpdateStatus(ctx context.Context, v *model.Vacancy) error {
	err := r.db.QueryRow(ctx,
		`UPDATE vacancies SET status = $3, updated_at = now()
		 WHERE id = $1 AND updated_at = $2
		 RETURNING updated_at`,
		v.ID, v.UpdatedAt, string(v.Status),
	).Scan(&v.UpdatedAt)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return errVacancyChanged // model.Conflict("vacancy was changed, try again")
		}
		return fmt.Errorf("update vacancy status: %w", err)
	}
	return nil
}
```

Что куда попало: формат id — handler (`400`), роль — middleware (`403`), владелец и состояние — service (`404`, `409`), гонка — repository (`409`), всё остальное — `500`.

---

## handler/v1

**Запрос с телом** — DTO с тегами `validate` и метод `toInput()`, который **только копирует** поля в model-тип:

```go
// internal/handler/v1/vacancy_dto.go
type vacancyRequest struct {
	Title          string   `json:"title" validate:"notblank,max=100"`
	Description    string   `json:"description" validate:"notblank,max=5000"`
	EmploymentType string   `json:"employment_type" validate:"required"`
	SalaryFrom     *int     `json:"salary_from"`
	Tags           []string `json:"tags" validate:"dive,notblank,max=50"`
	// ...
}

func (r vacancyRequest) toInput() model.VacancyInput { /* только копирование, без trim и проверок */ }
```

```go
func (h *employerHandler) CreateVacancy(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[vacancyRequest](w, r) // битый JSON или формат → 400, ответ уже записан
	if !ok {
		return
	}
	v, err := h.svc.CreateVacancy(r.Context(), userID(r), req.toInput())
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusCreated, idResponse{ID: v.ID})
}
```

Правила:

- **Валидация в handler — только формат:** обязательность (`required`, `notblank`), длина (`max`), формат (`email`), `gt=0`. Не «зарплата от ≤ до» и не «статус допустим» — это бизнес-правила, их проверяет `model`.
- **Параметры:** `httpx.PathID` для `{id}`, `httpx.ParsePage` для `limit`/`offset`, свои query-параметры разбирать как в `parseVacancyFilter`. Ошибка разбора — `httpx.WriteBadRequest`.
- **Ответ:** DTO ответа — неэкспортируемая структура с json-тегами и конструктор `newXxxResponse(*model.X)`. Списки — `newListResponse(page, newXxxResponse)`, `items` никогда не `null`. Время — `formatTime` (RFC3339, UTC).
- **Статусы успеха:** создание — `201` с `{"id"}`, изменение и удаление — `204`, чтение — `200`.
- **Кто пользователь:** `userID(r)`; роль уже проверил `RequireRole` в роутере.
- **Новая ручка по смыслу публичная или для любого пользователя?** Решить в роутере: без обёртки, `anyUser`, `asEmployer` или `asApplicant`.

## service

Один публичный метод — один файл, рядом его приватные хелперы. Общие хелперы (`ownedVacancy`) — в `service.go`.

```go
// internal/service/applicant/apply.go — создание с проверками по данным из БД
func (s *service) Apply(ctx context.Context, applicantID int64, in model.ApplyInput) (*model.Application, error) {
	v, err := s.vacancies.GetByID(ctx, in.VacancyID)
	if err != nil {
		return nil, fmt.Errorf("get vacancy: %w", err)
	}
	app, err := model.NewApplication(v, applicantID, in.CoverLetter) // правило «только открытая» — в model
	if err != nil {
		return nil, err
	}
	if _, err := s.resumes.GetByApplicant(ctx, applicantID); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil, model.Conflict("resume is required to apply")
		}
		return nil, fmt.Errorf("get resume: %w", err)
	}
	if err := s.applications.Create(ctx, app); err != nil {
		return nil, fmt.Errorf("create application: %w", err)
	}
	return app, nil
}
```

Правила:

- **Валидация в service — по данным из БД:** чья это сущность, в каком она состоянии, существует ли связанная (резюме для отклика, отклики у вакансии перед удалением). Правила, для которых БД не нужна, — в `model`.
- **Владелец проверяется в сервисе**, а не в SQL: прочитать (`GetByID`) и сравнить id. Чужое — `model.NotFound(...)`, а не `403`: нельзя узнать, существует ли чужой id.
- **Ошибки:** бизнес-отказ — конструктор `model` (`Conflict`, `NotFound`, `InvalidInput`, `Unauthorized`); ошибку снизу всегда оборачивать контекстом `fmt.Errorf("get vacancy: %w", err)`. Текст клиенту от этого не меняется: он лежит в `model.Error.Msg`.
- **Возвращать указатели:** `(*model.X, error)`, при ошибке `nil, err`.
- **Не логировать** и не знать про HTTP: никаких статусов, `http.*`, JSON.
- **Таймауты не добавлять:** дедлайн уже в `ctx` от `middleware.Timeout`.
- **Транзакций нет.** Если сценарий меняет одну строку на основе прочитанного — запись через метод с optimistic lock (`Update`/`UpdateStatus`/`Delete` с моделью). Если нужна атомарность нескольких таблиц — это повод обсудить подход до реализации.

## model

```go
// internal/model/application.go
var transitions = map[ApplicationStatus][]ApplicationStatus{
	ApplicationNew:    {ApplicationViewed, ApplicationInvited, ApplicationRejected},
	ApplicationViewed: {ApplicationInvited, ApplicationRejected},
}

func (s ApplicationStatus) Valid() bool { /* switch по известным значениям */ }
func (s ApplicationStatus) CanChangeTo(next ApplicationStatus) bool { return slices.Contains(transitions[s], next) }
```

Правила:

- **Бизнес-валидация и нормализация** — в конструкторах и методах: `NewUser`, `NewVacancy`/`Vacancy.Edit`, `NewResume`, `NewApplication`, `VacancyFilter.Normalize`. Нарушение — `InvalidInput` (`422`) или `Conflict` (`409`).
- **Enum** — тип-строка с константами и методом `Valid()`. Значения в БД — `TEXT` без `CHECK`.
- **Без json- и db-тегов:** формат API задают DTO в handler, формат БД — `*Row` в `pgrepo`.
- **Конструктор возвращает `*T`** и не трогает ввод-вывод: хеширование пароля, запросы в БД — в сервисе.

## repository

Интерфейс — в `internal/repository/repository.go` (по 1–3 метода, агрегаты только встраивают), реализация — в `pgrepo` или `redisrepo`.

| Ситуация | Что вернуть |
|---|---|
| строка не найдена (`pgx.ErrNoRows`, `RowsAffected() == 0` при удалении) | `model.NotFound("vacancy")` |
| нарушен `UNIQUE` (`23505`) | `model.Conflict("already applied to this vacancy")` |
| нарушен внешний ключ (`23503`) | `model.NotFound(...)` или `model.Conflict(...)` по смыслу |
| optimistic lock не сошёлся | `model.Conflict("<сущность> was changed, try again")` |
| любая другая ошибка | `fmt.Errorf("update vacancy status: %w", err)` |

Правила:

- **Простой SQL без бизнес-условий** (обычно один запрос, у списков — `count` + выборка): не `WHERE status = 'open'`, не `FOR SHARE`, не «сначала проверить, потом вставить». Решения принимает сервис.
- **Изменение строки, прочитанной сервисом**, — метод принимает модель и пишет `WHERE id = $1 AND updated_at = $2 … RETURNING updated_at`.
- **Чтение** — в `*Row`-структуру с `db`-тегами (`pgrepo/models.go`) через `pgx.RowToStructByName`, затем `toModel()`. Алиасы колонок в JOIN совпадают с тегами.
- **Запись** — позиционные аргументы; срезы (`tags`, `skills`) через `nonNil`, чтобы не записать `NULL`.
- **Списки** — `count(*)` + выборка с одним `WHERE`, возврат `*model.Paged[T]`.
- **После изменения интерфейса** — `make mocks` и коммит сгенерированного файла.
- **Не логировать.** Исключение — `redisrepo` для кэша и просмотров: Redis для них не обязателен, при сбое пишут `WARN` и работают дальше.

---

## Где какая валидация

| Проверка | Слой | Пример | Ответ |
|---|---|---|---|
| JSON разбирается, нет лишних полей | handler (`bind`) | `{"title":` | `400 invalid json body` |
| Поле есть, длина, формат | handler (`validate`-теги) | пустой `title`, `email` без `@` | `400` |
| Path и query параметры | handler (`PathID`, `ParsePage`) | `/vacancies/abc`, `limit=-1` | `400` |
| Роль | middleware (`RequireRole`) | соискатель создаёт вакансию | `403` |
| Значение допустимо, лимиты, нормализация | model | `employment_type=bogus`, 11 тегов, `salary_from > salary_to` | `422` |
| Владелец | service | чужая вакансия | `404` |
| Состояние и связанные данные | service + model | закрытая вакансия, нет резюме, недопустимый переход статуса | `409` / `404` |
| Уникальность, внешние ключи | repository (ограничения БД) | повторный отклик | `409` |
| Параллельное изменение | repository (optimistic lock) | статус изменили между чтением и записью | `409` |

## Ошибки и HTTP-статусы

| Конструктор | Статус | Текст клиенту |
|---|---|---|
| `model.InvalidInput("salary must not be negative")` | `422` | `invalid input: salary must not be negative` |
| `model.NotFound("vacancy")` | `404` | `vacancy not found` |
| `model.Conflict("vacancy already closed")` | `409` | `conflict: vacancy already closed` |
| `model.Unauthorized("invalid token")` | `401` | `unauthorized: invalid token` |
| любая другая ошибка | `500` | `internal server error` |
| истёк дедлайн запроса | `503` | `request timeout` |

Текст `Msg` уходит клиенту как есть — писать его для клиента, без внутренних деталей (имён таблиц, текстов драйвера). Перевод в статус — только в `httpx.WriteServiceError`, больше нигде.

## Логирование

Логирование — в одном месте, на уровне handler (HTTP-слоя). Сервисы, model и репозитории логгер не получают, они только возвращают ошибку с контекстом.

- **Handler сам `slog` не вызывает.** Ошибку он отдаёт через `httpx.WriteError`, `httpx.WriteBadRequest` или `httpx.WriteServiceError` — эти функции и пишут строку `request failed` с полной причиной (4xx — `WARN`, 5xx — `ERROR`). Своей строки лога рядом не добавлять: будет дубль.
- **Middleware `Logging`** пишет одну строку `http request` на каждый запрос, **`Recover`** — `panic recovered` со стеком.
- **Обе строки связаны `request_id`**: его ставит `middleware.RequestID`, логгер добавляет его сам, если логировать с `ctx` (`slog.ErrorContext(ctx, …)`, `log.WarnContext(ctx, …)`).
- **Чтобы причина была понятна в логе**, оборачивайте ошибки по пути: в лог попадёт вся цепочка, например `err="close vacancy: update vacancy status: connection refused"`.
- **Исключение** — кэш вакансий и просмотры в `redisrepo`: пишут `WARN` и продолжают работу без Redis.
- **В лог не писать** пароли, токены, тело запроса.

## Тесты

- **Сервис — обязательно:** table-driven, внешний пакет (`employer_test`), через `NewService` и моки mockery (`mocks.NewVacancyRepository(t)`, `EXPECT()`). Кейсы: успех, каждое бизнес-правило, чужой ресурс, ошибка чтения и записи, конфликт из репозитория.
- **Model** — правила валидации и переходы статусов.
- **Handler и SQL** целиком не тестируются (нужны HTTP и БД) — их проверяем вручную через Swagger или `curl`. Чистые функции рядом с ними тестируются: правила `validate` (`validate_test.go`), сборка `WHERE` поиска (`models_test.go`).
- **Проверять клиентский текст**, когда он часть контракта: `require.ErrorAs(t, err, &e)` и `e.Msg`.

## Чек-лист перед коммитом

- [ ] Handler: только формат, ошибки через `httpx`, нет `slog`.
- [ ] Service: владелец и состояние проверены, ошибки обёрнуты, бизнес-отказы — конструкторы `model`.
- [ ] Model: правила и нормализация здесь, а не в handler или SQL.
- [ ] Repository: простой SQL без бизнес-условий, ошибки БД переведены, `make mocks` после изменения интерфейса.
- [ ] Маршрут с правильной ролью в `router.go`.
- [ ] `docs/openapi.yaml` и README обновлены.
- [ ] `go vet ./... && make test` зелёные, ручка проверена руками.

## Чего не делать

- Бизнес-условия в `WHERE` или проверки «сначала SELECT, потом INSERT» в репозитории.
- Проверку владельца или статуса в handler.
- Свой `slog` в handler, сервисе или репозитории.
- `context.WithTimeout` в handler или сервисе.
- json-теги в `model`, экспортируемые DTO.
- Ручные фейки вместо моков mockery.
- Абстракции «на будущее»: менеджер транзакций, DI-контейнер, обёртки над bcrypt/JWT.
