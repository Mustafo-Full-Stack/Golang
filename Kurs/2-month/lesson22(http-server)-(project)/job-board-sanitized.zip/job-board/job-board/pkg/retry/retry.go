package retry

import (
	"context"
	"errors"
	"fmt"
	"time"
)

// Do повторяет fn с линейно растущей паузой (1s, 2s, 3s...).
func Do(ctx context.Context, attempts int, fn func() error) error {
	for attempt := 1; ; attempt++ {
		err := fn()
		if err == nil {
			return nil
		}
		if attempt >= attempts {
			return fmt.Errorf("after %d attempts: %w", attempt, err)
		}
		select {
		case <-ctx.Done():
			return errors.Join(ctx.Err(), err)
		case <-time.After(time.Duration(attempt) * time.Second):
		}
	}
}
