package logger_test

import (
	"context"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/pkg/logger"
)

func TestNew_Local(t *testing.T) {
	tests := []struct {
		name      string
		level     slog.Level
		wantDebug bool
	}{
		{"info level drops debug", slog.LevelInfo, false},
		{"debug level keeps debug", slog.LevelDebug, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			file := filepath.Join(t.TempDir(), "logs.txt")
			log, closeLog, err := logger.New("local", tt.level, file)
			require.NoError(t, err)

			log.Info("hello", "k", "v")
			log.Debug("details")
			require.NoError(t, closeLog())

			data, err := os.ReadFile(file)
			require.NoError(t, err)
			require.Contains(t, string(data), `level=INFO msg=hello k=v`)
			if tt.wantDebug {
				require.Contains(t, string(data), "level=DEBUG")
			} else {
				require.NotContains(t, string(data), "level=DEBUG")
			}
		})
	}
}

func TestNew_LocalBadFile(t *testing.T) {
	_, _, err := logger.New("local", slog.LevelInfo, filepath.Join(t.TempDir(), "no-dir", "logs.txt"))
	require.ErrorContains(t, err, "open log file")
}

func TestNew_ProdDoesNotCreateFile(t *testing.T) {
	file := filepath.Join(t.TempDir(), "logs.txt")

	log, closeLog, err := logger.New("prod", slog.LevelInfo, file)
	require.NoError(t, err)
	require.NotNil(t, log)
	require.NoError(t, closeLog())

	require.NoFileExists(t, file)
}

func TestNew_RequestIDFromContext(t *testing.T) {
	tests := []struct {
		name   string
		ctx    context.Context
		wantID bool
	}{
		{"id in context is logged", logger.WithRequestID(context.Background(), "abc123"), true},
		{"no id — no field", context.Background(), false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			file := filepath.Join(t.TempDir(), "logs.txt")
			log, closeLog, err := logger.New("local", slog.LevelInfo, file)
			require.NoError(t, err)

			log.With("component", "test").InfoContext(tt.ctx, "hello")
			require.NoError(t, closeLog())

			raw, err := os.ReadFile(file)
			require.NoError(t, err)
			require.Contains(t, string(raw), "component=test")
			require.Equal(t, tt.wantID, strings.Contains(string(raw), "request_id=abc123"))
		})
	}
}
