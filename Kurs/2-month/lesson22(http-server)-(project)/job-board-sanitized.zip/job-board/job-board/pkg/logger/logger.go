package logger

import (
	"fmt"
	"log/slog"
	"os"
)

// New: local — текстовые логи в файл (консоль остаётся чистой),
// иначе JSON в stdout для сборщика логов. Вторая функция закрывает файл.
func New(env string, level slog.Level, file string) (*slog.Logger, func() error, error) {
	opts := &slog.HandlerOptions{Level: level}
	if env != "local" {
		return slog.New(contextHandler{slog.NewJSONHandler(os.Stdout, opts)}), func() error { return nil }, nil
	}
	f, err := os.OpenFile(file, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return nil, nil, fmt.Errorf("open log file: %w", err)
	}
	return slog.New(contextHandler{slog.NewTextHandler(f, opts)}), f.Close, nil
}
