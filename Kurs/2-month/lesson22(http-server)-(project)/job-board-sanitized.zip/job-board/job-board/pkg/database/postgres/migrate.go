package postgres

import (
	"fmt"
	"io/fs"

	"github.com/jackc/pgx/v5/stdlib"
	"github.com/pressly/goose/v3"
)

// Миграции идут через уже открытый пул, отдельный DSN не нужен.
func (c *Client) Migrate(fsys fs.FS, dir string) error {
	db := stdlib.OpenDBFromPool(c.pool)
	defer db.Close()

	goose.SetBaseFS(fsys)
	if err := goose.SetDialect("postgres"); err != nil {
		return fmt.Errorf("set goose dialect: %w", err)
	}
	if err := goose.Up(db, dir); err != nil {
		return fmt.Errorf("apply migrations: %w", err)
	}
	return nil
}
