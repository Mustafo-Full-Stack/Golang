package redis

import (
	"context"
	"errors"
	"fmt"
	"net"
	"time"

	goredis "github.com/redis/go-redis/v9"

	"github.com/rabboni171/job-board/pkg/cache"
	"github.com/rabboni171/job-board/pkg/retry"
)

type Config struct {
	Host           string
	Port           string
	Password       string
	DB             int
	PoolSize       int
	ConnectRetries int
	DialTimeout    time.Duration
	ReadTimeout    time.Duration
	WriteTimeout   time.Duration
}

type Client struct {
	rdb *goredis.Client
}

func New(ctx context.Context, cfg Config) (*Client, error) {
	c := &Client{rdb: goredis.NewClient(&goredis.Options{
		Addr:         net.JoinHostPort(cfg.Host, cfg.Port),
		Password:     cfg.Password,
		DB:           cfg.DB,
		PoolSize:     cfg.PoolSize,
		DialTimeout:  cfg.DialTimeout,
		ReadTimeout:  cfg.ReadTimeout,
		WriteTimeout: cfg.WriteTimeout,
	})}

	if err := retry.Do(ctx, cfg.ConnectRetries, func() error { return c.Ping(ctx) }); err != nil {
		_ = c.Close()
		return nil, fmt.Errorf("connect to redis: %w", err)
	}
	return c, nil
}

func (c *Client) Get(ctx context.Context, key string) ([]byte, error) {
	b, err := c.rdb.Get(ctx, key).Bytes()
	if errors.Is(err, goredis.Nil) {
		return nil, cache.ErrNotFound
	}
	return b, err
}

func (c *Client) Set(ctx context.Context, key string, value any, ttl time.Duration) error {
	return c.rdb.Set(ctx, key, value, ttl).Err()
}

func (c *Client) SetNX(ctx context.Context, key string, value any, ttl time.Duration) (bool, error) {
	return c.rdb.SetNX(ctx, key, value, ttl).Result()
}

func (c *Client) Incr(ctx context.Context, key string) (int64, error) {
	return c.rdb.Incr(ctx, key).Result()
}

func (c *Client) GetDel(ctx context.Context, key string) ([]byte, error) {
	b, err := c.rdb.GetDel(ctx, key).Bytes()
	if errors.Is(err, goredis.Nil) {
		return nil, cache.ErrNotFound
	}
	return b, err
}

func (c *Client) Del(ctx context.Context, keys ...string) error {
	return c.rdb.Del(ctx, keys...).Err()
}

func (c *Client) Ping(ctx context.Context) error {
	return c.rdb.Ping(ctx).Err()
}

func (c *Client) Close() error {
	return c.rdb.Close()
}
