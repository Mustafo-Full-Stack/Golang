-- +goose Up
CREATE TABLE IF NOT EXISTS users (
    id            BIGSERIAL   PRIMARY KEY,
    email         TEXT        NOT NULL UNIQUE,
    password_hash TEXT        NOT NULL,
    name          TEXT        NOT NULL,   -- ФИО или название компании
    role          TEXT        NOT NULL,   -- employer | applicant (проверяет сервис)
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- одно резюме на соискателя
CREATE TABLE IF NOT EXISTS resumes (
    applicant_id       BIGINT      PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    title              TEXT        NOT NULL,   -- желаемая должность
    about              TEXT        NOT NULL,
    city               TEXT        NOT NULL,
    experience_years   INT         NOT NULL,
    salary_expectation INT,
    skills             TEXT[]      NOT NULL DEFAULT '{}',
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vacancies (
    id              BIGSERIAL   PRIMARY KEY,
    employer_id     BIGINT      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           TEXT        NOT NULL,
    description     TEXT        NOT NULL,
    city            TEXT        NOT NULL,
    employment_type TEXT        NOT NULL,   -- full | part | remote | internship
    salary_from     INT,
    salary_to       INT,
    tags            TEXT[]      NOT NULL DEFAULT '{}',
    status          TEXT        NOT NULL,   -- open | closed
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_vacancies_employer       ON vacancies(employer_id);
CREATE INDEX IF NOT EXISTS idx_vacancies_status_created ON vacancies(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_vacancies_tags           ON vacancies USING GIN (tags);

-- отклики
CREATE TABLE IF NOT EXISTS applications (
    id           BIGSERIAL   PRIMARY KEY,
    vacancy_id   BIGINT      NOT NULL REFERENCES vacancies(id) ON DELETE CASCADE,
    applicant_id BIGINT      NOT NULL REFERENCES users(id)     ON DELETE CASCADE,
    cover_letter TEXT        NOT NULL,
    status       TEXT        NOT NULL,   -- new | viewed | invited | rejected
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (vacancy_id, applicant_id)
);
CREATE INDEX IF NOT EXISTS idx_applications_applicant ON applications(applicant_id);

-- +goose Down
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS vacancies;
DROP TABLE IF EXISTS resumes;
DROP TABLE IF EXISTS users;
