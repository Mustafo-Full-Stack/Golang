-- +goose Up
-- Вакансию с откликами удалить нельзя: отклики соискателей не должны пропадать молча.
ALTER TABLE applications
    DROP CONSTRAINT IF EXISTS applications_vacancy_id_fkey,
    ADD CONSTRAINT applications_vacancy_id_fkey
        FOREIGN KEY (vacancy_id) REFERENCES vacancies(id) ON DELETE RESTRICT;

-- +goose Down
ALTER TABLE applications
    DROP CONSTRAINT IF EXISTS applications_vacancy_id_fkey,
    ADD CONSTRAINT applications_vacancy_id_fkey
        FOREIGN KEY (vacancy_id) REFERENCES vacancies(id) ON DELETE CASCADE;
