-- +goose Up
-- Описание схемы прямо в БД (видно в \d+, DBeaver, DataGrip). Комментируем только неочевидное:
-- назначение таблиц, допустимые значения TEXT-колонок (CHECK нет, проверяет код) и ключевые ограничения.

COMMENT ON TABLE users IS 'Учётные записи обеих ролей: работодатели и соискатели';
COMMENT ON COLUMN users.email IS 'Логин, хранится в нижнем регистре: уникален без учёта регистра';
COMMENT ON COLUMN users.password_hash IS 'bcrypt-хеш пароля';
COMMENT ON COLUMN users.name IS 'ФИО соискателя или название компании работодателя';
COMMENT ON COLUMN users.role IS 'employer | applicant; задаётся при регистрации и не меняется';

COMMENT ON TABLE resumes IS 'Резюме соискателя, одно на соискателя';
COMMENT ON COLUMN resumes.applicant_id IS 'Владелец резюме; первичный ключ, поэтому у соискателя не больше одного резюме';
COMMENT ON COLUMN resumes.title IS 'Желаемая должность';
COMMENT ON COLUMN resumes.experience_years IS 'Опыт работы в годах, 0..60';
COMMENT ON COLUMN resumes.salary_expectation IS 'Ожидаемая зарплата; NULL — не указана';
COMMENT ON COLUMN resumes.skills IS 'Навыки в нижнем регистре без дублей, до 20';

COMMENT ON TABLE vacancies IS 'Вакансии работодателей';
COMMENT ON COLUMN vacancies.employer_id IS 'Владелец вакансии (пользователь с ролью employer)';
COMMENT ON COLUMN vacancies.employment_type IS 'full | part | remote | internship';
COMMENT ON COLUMN vacancies.salary_from IS 'Нижняя граница вилки; NULL — не указана';
COMMENT ON COLUMN vacancies.salary_to IS 'Верхняя граница вилки; NULL — не указана';
COMMENT ON COLUMN vacancies.tags IS 'Теги в нижнем регистре без дублей, до 10; поиск требует все указанные';
COMMENT ON COLUMN vacancies.status IS 'open — в поиске и принимает отклики; closed — закрыта, необратимо';
COMMENT ON COLUMN vacancies.updated_at IS 'Время последнего изменения и версия строки для optimistic lock';

COMMENT ON TABLE applications IS 'Отклики: связь многие-ко-многим соискателей и вакансий со своими данными';
COMMENT ON COLUMN applications.applicant_id IS 'Соискатель, который откликнулся';
COMMENT ON COLUMN applications.status IS 'new -> viewed -> invited | rejected; отозвать (удалить) можно только new';
COMMENT ON COLUMN applications.updated_at IS 'Время смены статуса и версия строки для optimistic lock';
COMMENT ON CONSTRAINT applications_vacancy_id_applicant_id_key ON applications IS 'Один отклик соискателя на вакансию';
COMMENT ON CONSTRAINT applications_vacancy_id_fkey ON applications IS 'RESTRICT: вакансию с откликами удалить нельзя, только закрыть';

-- +goose Down
COMMENT ON TABLE users IS NULL;
COMMENT ON COLUMN users.email IS NULL;
COMMENT ON COLUMN users.password_hash IS NULL;
COMMENT ON COLUMN users.name IS NULL;
COMMENT ON COLUMN users.role IS NULL;

COMMENT ON TABLE resumes IS NULL;
COMMENT ON COLUMN resumes.applicant_id IS NULL;
COMMENT ON COLUMN resumes.title IS NULL;
COMMENT ON COLUMN resumes.experience_years IS NULL;
COMMENT ON COLUMN resumes.salary_expectation IS NULL;
COMMENT ON COLUMN resumes.skills IS NULL;

COMMENT ON TABLE vacancies IS NULL;
COMMENT ON COLUMN vacancies.employer_id IS NULL;
COMMENT ON COLUMN vacancies.employment_type IS NULL;
COMMENT ON COLUMN vacancies.salary_from IS NULL;
COMMENT ON COLUMN vacancies.salary_to IS NULL;
COMMENT ON COLUMN vacancies.tags IS NULL;
COMMENT ON COLUMN vacancies.status IS NULL;
COMMENT ON COLUMN vacancies.updated_at IS NULL;

COMMENT ON TABLE applications IS NULL;
COMMENT ON COLUMN applications.applicant_id IS NULL;
COMMENT ON COLUMN applications.status IS NULL;
COMMENT ON COLUMN applications.updated_at IS NULL;
COMMENT ON CONSTRAINT applications_vacancy_id_applicant_id_key ON applications IS NULL;
COMMENT ON CONSTRAINT applications_vacancy_id_fkey ON applications IS NULL;
