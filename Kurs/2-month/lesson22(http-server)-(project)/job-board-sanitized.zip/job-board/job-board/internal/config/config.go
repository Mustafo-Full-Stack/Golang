package config

import (
	"errors"
	"fmt"
	"log/slog"
	"slices"
	"time"

	"github.com/kelseyhightower/envconfig"
)

// Группы встроены без имени поля: так envconfig не добавляет префикс,
// и имя переменной окружения — ровно то, что написано в теге.
type Config struct {
	App
	JWT
	HTTP
	Cache
	Postgres
	Redis
}

type App struct {
	Env      string     `envconfig:"APP_ENV" default:"local"`  // local | prod
	LogLevel slog.Level `envconfig:"LOG_LEVEL" default:"info"` // debug | info | warn | error
	// используется только при APP_ENV=local, иначе логи идут в stdout
	LogFile string `envconfig:"LOG_FILE" default:"logs.txt"`
}

type JWT struct {
	Secret     string        `envconfig:"JWT_SECRET" required:"true"`
	AccessTTL  time.Duration `envconfig:"JWT_ACCESS_TTL" default:"1h"`
	RefreshTTL time.Duration `envconfig:"JWT_REFRESH_TTL" default:"720h"`
}

type HTTP struct {
	Port              string        `envconfig:"HTTP_PORT" default:"8080"`
	ReadHeaderTimeout time.Duration `envconfig:"HTTP_READ_HEADER_TIMEOUT" default:"5s"`
	ReadTimeout       time.Duration `envconfig:"HTTP_READ_TIMEOUT" default:"10s"`
	WriteTimeout      time.Duration `envconfig:"HTTP_WRITE_TIMEOUT" default:"25s"`
	IdleTimeout       time.Duration `envconfig:"HTTP_IDLE_TIMEOUT" default:"60s"`
	RequestTimeout    time.Duration `envconfig:"HTTP_REQUEST_TIMEOUT" default:"20s"`
	ShutdownTimeout   time.Duration `envconfig:"HTTP_SHUTDOWN_TIMEOUT" default:"10s"`
	// Через запятую: http://localhost:3000,https://app.example.com. Пусто — CORS выключен.
	CORSAllowedOrigins []string `envconfig:"CORS_ALLOWED_ORIGINS"`
}

// Поля совпадают с redisrepo.CacheTTL: в app приводится напрямую.
type Cache struct {
	VacancyTTL time.Duration `envconfig:"CACHE_VACANCY_TTL" default:"5m"`
	SearchTTL  time.Duration `envconfig:"CACHE_SEARCH_TTL" default:"60s"`
}

// Поля совпадают с postgres.Config и redis.Config: pkg не знает про ключи конфига.
type Postgres struct {
	Host           string        `envconfig:"POSTGRES_HOST" default:"localhost"`
	Port           string        `envconfig:"POSTGRES_PORT" default:"5432"`
	User           string        `envconfig:"POSTGRES_USER" default:"jobboard"`
	Password       string        `envconfig:"POSTGRES_PASSWORD" default:"jobboard"`
	Database       string        `envconfig:"POSTGRES_DB" default:"jobboard"`
	SSLMode        string        `envconfig:"POSTGRES_SSLMODE" default:"disable"`
	MaxConns       int32         `envconfig:"POSTGRES_MAX_CONNS" default:"10"`
	ConnectRetries int           `envconfig:"POSTGRES_CONNECT_RETRIES" default:"3"`
	ConnectTimeout time.Duration `envconfig:"POSTGRES_CONNECT_TIMEOUT" default:"5s"`
}

type Redis struct {
	Host           string        `envconfig:"REDIS_HOST" default:"localhost"`
	Port           string        `envconfig:"REDIS_PORT" default:"6379"`
	Password       string        `envconfig:"REDIS_PASSWORD"`
	DB             int           `envconfig:"REDIS_DB" default:"0"`
	PoolSize       int           `envconfig:"REDIS_POOL_SIZE" default:"10"`
	ConnectRetries int           `envconfig:"REDIS_CONNECT_RETRIES" default:"3"`
	DialTimeout    time.Duration `envconfig:"REDIS_DIAL_TIMEOUT" default:"5s"`
	ReadTimeout    time.Duration `envconfig:"REDIS_READ_TIMEOUT" default:"3s"`
	WriteTimeout   time.Duration `envconfig:"REDIS_WRITE_TIMEOUT" default:"3s"`
}

type Migrate struct {
	Enabled bool `envconfig:"MIGRATIONS_ENABLED" default:"false"`
	Postgres
}

func LoadMigrate() (*Migrate, error) {
	var cfg Migrate
	if err := envconfig.Process("", &cfg); err != nil {
		return nil, fmt.Errorf("load config: %w", err)
	}
	if cfg.Postgres.ConnectTimeout <= 0 {
		return nil, errors.New("POSTGRES_CONNECT_TIMEOUT must be positive")
	}
	return &cfg, nil
}

func Load() (*Config, error) {
	var cfg Config
	if err := envconfig.Process("", &cfg); err != nil {
		return nil, fmt.Errorf("load config: %w", err)
	}
	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (c *Config) validate() error {
	if len(c.JWT.Secret) < 32 {
		return errors.New("JWT_SECRET must be at least 32 bytes")
	}
	if err := c.validateDurations(); err != nil {
		return err
	}
	// Иначе сервер оборвёт соединение раньше, чем обработчик успеет ответить по таймауту запроса.
	if c.HTTP.WriteTimeout <= c.HTTP.RequestTimeout {
		return errors.New("HTTP_WRITE_TIMEOUT must be greater than HTTP_REQUEST_TIMEOUT")
	}
	if c.JWT.RefreshTTL < c.JWT.AccessTTL {
		return errors.New("JWT_REFRESH_TTL must not be less than JWT_ACCESS_TTL")
	}
	if c.App.Env == "local" && c.App.LogFile == "" {
		return errors.New("LOG_FILE is required when APP_ENV=local")
	}
	// Middleware сравнивает origin точно, поэтому "*" молча не сработал бы.
	if slices.Contains(c.HTTP.CORSAllowedOrigins, "*") {
		return errors.New("CORS_ALLOWED_ORIGINS: list origins explicitly, \"*\" is not supported")
	}
	return nil
}

// Нулевой или отрицательный таймаут/TTL означает «без ограничения» или мгновенное истечение — почти всегда ошибка конфига.
func (c *Config) validateDurations() error {
	for _, d := range []struct {
		name  string
		value time.Duration
	}{
		{"JWT_ACCESS_TTL", c.JWT.AccessTTL},
		{"JWT_REFRESH_TTL", c.JWT.RefreshTTL},
		{"CACHE_VACANCY_TTL", c.Cache.VacancyTTL},
		{"CACHE_SEARCH_TTL", c.Cache.SearchTTL},
		{"HTTP_READ_HEADER_TIMEOUT", c.HTTP.ReadHeaderTimeout},
		{"HTTP_READ_TIMEOUT", c.HTTP.ReadTimeout},
		{"HTTP_WRITE_TIMEOUT", c.HTTP.WriteTimeout},
		{"HTTP_IDLE_TIMEOUT", c.HTTP.IdleTimeout},
		{"HTTP_REQUEST_TIMEOUT", c.HTTP.RequestTimeout},
		{"HTTP_SHUTDOWN_TIMEOUT", c.HTTP.ShutdownTimeout},
		{"POSTGRES_CONNECT_TIMEOUT", c.Postgres.ConnectTimeout},
		{"REDIS_DIAL_TIMEOUT", c.Redis.DialTimeout},
		{"REDIS_READ_TIMEOUT", c.Redis.ReadTimeout},
		{"REDIS_WRITE_TIMEOUT", c.Redis.WriteTimeout},
	} {
		if d.value <= 0 {
			return fmt.Errorf("%s must be positive", d.name)
		}
	}
	return nil
}
