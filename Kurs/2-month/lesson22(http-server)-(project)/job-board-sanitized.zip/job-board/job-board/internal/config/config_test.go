package config

import (
	"log/slog"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

// 32+ байта: короче Load отклоняет.
const testSecret = "test-secret-with-at-least-32-bytes"

func TestLoad(t *testing.T) {
	tests := []struct {
		name  string
		env   map[string]string
		check func(t *testing.T, cfg *Config)
	}{
		{
			name: "defaults",
			check: func(t *testing.T, cfg *Config) {
				require.Equal(t, "local", cfg.App.Env)
				require.Equal(t, slog.LevelInfo, cfg.App.LogLevel)
				require.Equal(t, "logs.txt", cfg.App.LogFile)
				require.Equal(t, time.Hour, cfg.JWT.AccessTTL)
				require.Equal(t, 720*time.Hour, cfg.JWT.RefreshTTL)
				require.Equal(t, "8080", cfg.HTTP.Port)
				require.Equal(t, 5*time.Minute, cfg.Cache.VacancyTTL)
				require.Equal(t, "jobboard", cfg.Postgres.User)
				require.Equal(t, int32(10), cfg.Postgres.MaxConns)
				require.Equal(t, "6379", cfg.Redis.Port)
				require.Equal(t, 3*time.Second, cfg.Redis.ReadTimeout)
				require.Empty(t, cfg.HTTP.CORSAllowedOrigins)
			},
		},
		{
			name: "cors origins are comma separated",
			env:  map[string]string{"CORS_ALLOWED_ORIGINS": "http://localhost:3000,https://app.example.com"},
			check: func(t *testing.T, cfg *Config) {
				require.Equal(t, []string{"http://localhost:3000", "https://app.example.com"}, cfg.HTTP.CORSAllowedOrigins)
			},
		},
		{
			name: "env overrides defaults",
			env:  map[string]string{"HTTP_PORT": "9090", "LOG_LEVEL": "debug", "POSTGRES_USER": "me"},
			check: func(t *testing.T, cfg *Config) {
				require.Equal(t, "9090", cfg.HTTP.Port)
				require.Equal(t, slog.LevelDebug, cfg.App.LogLevel)
				require.Equal(t, "me", cfg.Postgres.User)
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Setenv("JWT_SECRET", testSecret)
			for k, v := range tt.env {
				t.Setenv(k, v)
			}

			cfg, err := Load()

			require.NoError(t, err)
			tt.check(t, cfg)
		})
	}
}

func TestLoad_Errors(t *testing.T) {
	tests := []struct {
		name    string
		env     map[string]string
		wantErr string
	}{
		{"no secret", map[string]string{"JWT_SECRET": ""}, "JWT_SECRET"},
		{"short secret", map[string]string{"JWT_SECRET": "short"}, "at least 32 bytes"},
		{"invalid log level", map[string]string{"LOG_LEVEL": "loud"}, "LOG_LEVEL"},
		{"write timeout not above request timeout", map[string]string{"HTTP_WRITE_TIMEOUT": "20s"}, "HTTP_WRITE_TIMEOUT must be greater"},
		{"refresh shorter than access", map[string]string{"JWT_ACCESS_TTL": "2h", "JWT_REFRESH_TTL": "1h"}, "JWT_REFRESH_TTL must not be less"},
		{"zero access ttl", map[string]string{"JWT_ACCESS_TTL": "0s"}, "JWT_ACCESS_TTL must be positive"},
		{"negative refresh ttl", map[string]string{"JWT_REFRESH_TTL": "-1h"}, "JWT_REFRESH_TTL must be positive"},
		{"zero vacancy cache ttl", map[string]string{"CACHE_VACANCY_TTL": "0s"}, "CACHE_VACANCY_TTL must be positive"},
		{"zero search cache ttl", map[string]string{"CACHE_SEARCH_TTL": "0s"}, "CACHE_SEARCH_TTL must be positive"},
		{"local without log file", map[string]string{"APP_ENV": "local", "LOG_FILE": ""}, "LOG_FILE is required"},
		{"cors wildcard", map[string]string{"CORS_ALLOWED_ORIGINS": "*"}, "CORS_ALLOWED_ORIGINS"},
		{"zero read timeout", map[string]string{"HTTP_READ_TIMEOUT": "0s"}, "HTTP_READ_TIMEOUT must be positive"},
		{"zero postgres connect timeout", map[string]string{"POSTGRES_CONNECT_TIMEOUT": "0s"}, "POSTGRES_CONNECT_TIMEOUT must be positive"},
		{"zero redis dial timeout", map[string]string{"REDIS_DIAL_TIMEOUT": "0s"}, "REDIS_DIAL_TIMEOUT must be positive"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Setenv("JWT_SECRET", testSecret)
			for k, v := range tt.env {
				t.Setenv(k, v)
			}

			_, err := Load()

			require.ErrorContains(t, err, tt.wantErr)
		})
	}
}

func TestLoadMigrate(t *testing.T) {
	tests := []struct {
		name        string
		env         map[string]string
		wantEnabled bool
		wantUser    string
		wantErr     string
	}{
		{name: "disabled by default, no JWT_SECRET needed", wantUser: "jobboard"},
		{name: "enabled with postgres settings", env: map[string]string{"MIGRATIONS_ENABLED": "true", "POSTGRES_USER": "me"}, wantEnabled: true, wantUser: "me"},
		{name: "invalid flag", env: map[string]string{"MIGRATIONS_ENABLED": "maybe"}, wantErr: "MIGRATIONS_ENABLED"},
		{name: "zero connect timeout", env: map[string]string{"POSTGRES_CONNECT_TIMEOUT": "0s"}, wantErr: "POSTGRES_CONNECT_TIMEOUT must be positive"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			for k, v := range tt.env {
				t.Setenv(k, v)
			}

			cfg, err := LoadMigrate()

			if tt.wantErr != "" {
				require.ErrorContains(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.wantEnabled, cfg.Enabled)
			require.Equal(t, tt.wantUser, cfg.Postgres.User)
		})
	}
}
