package app

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"runtime/debug"
	"syscall"

	"github.com/rabboni171/job-board/internal/config"
	"github.com/rabboni171/job-board/internal/handler"
	"github.com/rabboni171/job-board/internal/repository/pgrepo"
	"github.com/rabboni171/job-board/internal/repository/redisrepo"
	"github.com/rabboni171/job-board/internal/service/applicant"
	"github.com/rabboni171/job-board/internal/service/auth"
	"github.com/rabboni171/job-board/internal/service/employer"
	"github.com/rabboni171/job-board/pkg/cache/redis"
	"github.com/rabboni171/job-board/pkg/database/postgres"
	"github.com/rabboni171/job-board/pkg/logger"
)

// Run сам пишет в лог причину остановки: после возврата лог-файл уже закрыт.
func Run() (err error) {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	log, closeLog, err := logger.New(cfg.App.Env, cfg.App.LogLevel, cfg.App.LogFile)
	if err != nil {
		return err
	}
	defer func() { _ = closeLog() }()
	slog.SetDefault(log)

	// Паника вне HTTP-обработчиков (их ловит middleware.Recover): при сборке зависимостей или остановке.
	// Поднимать сервис дальше нельзя, но причина со стеком должна попасть в лог.
	defer func() {
		if r := recover(); r != nil {
			log.Error("panic", "panic", r, "stack", string(debug.Stack()))
			err = fmt.Errorf("panic: %v", r)
			return
		}
		if err != nil {
			log.Error("app stopped", "err", err)
		}
	}()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	db, err := postgres.New(ctx, postgres.Config(cfg.Postgres))
	if err != nil {
		return err
	}
	defer db.Close()

	rdb, err := redis.New(ctx, redis.Config(cfg.Redis))
	if err != nil {
		return err
	}
	defer rdb.Close()

	userRepo := pgrepo.NewUserRepo(db)
	vacancyRepo := redisrepo.NewCachedVacancyRepo(pgrepo.NewVacancyRepo(db), rdb, redisrepo.CacheTTL(cfg.Cache), log)
	resumeRepo := pgrepo.NewResumeRepo(db)
	appRepo := pgrepo.NewApplicationRepo(db)
	views := redisrepo.NewViewCounter(rdb, log)
	sessionRepo := redisrepo.NewSessionRepo(rdb)

	authSvc := auth.NewService(userRepo, sessionRepo, cfg.JWT.Secret, cfg.JWT.AccessTTL, cfg.JWT.RefreshTTL)
	employerSvc := employer.NewService(vacancyRepo, appRepo)
	applicantSvc := applicant.NewService(vacancyRepo, resumeRepo, appRepo, views)

	router := handler.NewRouter(log, handler.Services{
		Tokens:    authSvc,
		Auth:      authSvc,
		Sessions:  authSvc,
		Employer:  employerSvc,
		Applicant: applicantSvc,
	}, cfg.HTTP.RequestTimeout, cfg.HTTP.CORSAllowedOrigins,
		handler.HealthCheck{Name: "postgres", Ping: db.Ping},
		handler.HealthCheck{Name: "redis", Ping: rdb.Ping},
	)
	srv := &http.Server{
		Addr:              ":" + cfg.HTTP.Port,
		Handler:           router,
		ReadHeaderTimeout: cfg.HTTP.ReadHeaderTimeout,
		ReadTimeout:       cfg.HTTP.ReadTimeout,
		WriteTimeout:      cfg.HTTP.WriteTimeout,
		IdleTimeout:       cfg.HTTP.IdleTimeout,
		// Собственные ошибки net/http (обрывы TLS, паники мимо Recover) — в наш логгер, а не в stderr.
		ErrorLog: slog.NewLogLogger(log.Handler(), slog.LevelError),
	}

	errCh := make(chan error, 1)
	go func() {
		log.Info("server started", "addr", srv.Addr)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			errCh <- fmt.Errorf("listen and serve: %w", err)
		}
	}()

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		log.Info("shutting down")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), cfg.HTTP.ShutdownTimeout)
		defer cancel()
		if err := srv.Shutdown(shutdownCtx); err != nil {
			return fmt.Errorf("shutdown server: %w", err)
		}
		return nil
	}
}
