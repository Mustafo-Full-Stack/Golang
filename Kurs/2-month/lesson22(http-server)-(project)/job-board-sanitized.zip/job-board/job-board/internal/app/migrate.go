package app

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"syscall"

	"github.com/rabboni171/job-board/internal/config"
	"github.com/rabboni171/job-board/migrations"
	"github.com/rabboni171/job-board/pkg/database/postgres"
)

// Migrate применяет миграции goose и завершается. Запускается отдельным шагом перед API,
// чтобы несколько реплик не мигрировали одновременно, а упавшая миграция не роняла сервис.
func Migrate() error {
	cfg, err := config.LoadMigrate()
	if err != nil {
		return err
	}
	if !cfg.Enabled {
		slog.Info("migrations disabled (MIGRATIONS_ENABLED=false), apply schema with make db-schema")
		return nil
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	db, err := postgres.New(ctx, postgres.Config(cfg.Postgres))
	if err != nil {
		return err
	}
	defer db.Close()

	if err := db.Migrate(migrations.FS, "."); err != nil {
		return err
	}
	slog.Info("migrations applied")
	return nil
}
