package v1

import "github.com/rabboni171/job-board/internal/model"

type vacancyRequest struct {
	Title          string   `json:"title" validate:"notblank,max=100"`
	Description    string   `json:"description" validate:"notblank,max=5000"`
	City           string   `json:"city" validate:"max=100"`
	EmploymentType string   `json:"employment_type" validate:"required"`
	SalaryFrom     *int     `json:"salary_from"`
	SalaryTo       *int     `json:"salary_to"`
	Tags           []string `json:"tags" validate:"dive,notblank,max=50"`
}

func (r vacancyRequest) toInput() model.VacancyInput {
	return model.VacancyInput{
		Title:          r.Title,
		Description:    r.Description,
		City:           r.City,
		EmploymentType: model.EmploymentType(r.EmploymentType),
		SalaryFrom:     r.SalaryFrom,
		SalaryTo:       r.SalaryTo,
		Tags:           r.Tags,
	}
}

type statusRequest struct {
	Status string `json:"status" validate:"required"`
}

type applicationWithResumeResponse struct {
	ID            int64           `json:"id"`
	VacancyID     int64           `json:"vacancy_id"`
	ApplicantID   int64           `json:"applicant_id"`
	ApplicantName string          `json:"applicant_name"`
	CoverLetter   string          `json:"cover_letter"`
	Status        string          `json:"status"`
	CreatedAt     string          `json:"created_at"`
	UpdatedAt     string          `json:"updated_at"`
	Resume        *resumeResponse `json:"resume"`
}

func newApplicationWithResumeResponse(a model.ApplicationWithResume) applicationWithResumeResponse {
	resp := applicationWithResumeResponse{
		ID:            a.Application.ID,
		VacancyID:     a.Application.VacancyID,
		ApplicantID:   a.Application.ApplicantID,
		ApplicantName: a.ApplicantName,
		CoverLetter:   a.Application.CoverLetter,
		Status:        string(a.Application.Status),
		CreatedAt:     formatTime(a.Application.CreatedAt),
		UpdatedAt:     formatTime(a.Application.UpdatedAt),
	}
	if a.Resume != nil {
		r := newResumeResponse(a.Resume)
		resp.Resume = &r
	}
	return resp
}
