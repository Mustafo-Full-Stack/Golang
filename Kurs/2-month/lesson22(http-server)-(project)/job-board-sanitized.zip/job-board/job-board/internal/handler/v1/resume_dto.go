package v1

import "github.com/rabboni171/job-board/internal/model"

type resumeResponse struct {
	ApplicantID       int64    `json:"applicant_id"`
	Title             string   `json:"title"`
	About             string   `json:"about"`
	City              string   `json:"city"`
	ExperienceYears   int      `json:"experience_years"`
	SalaryExpectation *int     `json:"salary_expectation"`
	Skills            []string `json:"skills"`
	UpdatedAt         string   `json:"updated_at"`
}

func newResumeResponse(resume *model.Resume) resumeResponse {
	return resumeResponse{
		ApplicantID:       resume.ApplicantID,
		Title:             resume.Title,
		About:             resume.About,
		City:              resume.City,
		ExperienceYears:   resume.ExperienceYears,
		SalaryExpectation: resume.SalaryExpectation,
		Skills:            nonNil(resume.Skills),
		UpdatedAt:         formatTime(resume.UpdatedAt),
	}
}
