package middleware

import (
	"context"
	"net/http"
	"time"
)

// Timeout передаёт дедлайн через контекст в Postgres и Redis, чтобы зависший запрос прерывался.
func Timeout(d time.Duration) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx, cancel := context.WithTimeout(r.Context(), d)
			defer cancel()
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}
