package httpx_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/handler/httpx"
)

func TestPathID(t *testing.T) {
	tests := []struct {
		name    string
		value   string
		want    int64
		wantErr string
	}{
		{name: "valid", value: "42", want: 42},
		{name: "not a number", value: "abc", wantErr: "invalid id: must be a positive integer"},
		{name: "zero", value: "0", wantErr: "invalid id: must be a positive integer"},
		{name: "negative", value: "-5", wantErr: "invalid id: must be a positive integer"},
		{name: "overflow", value: "99999999999999999999", wantErr: "invalid id: must be a positive integer"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			r := httptest.NewRequest(http.MethodGet, "/", nil)
			r.SetPathValue("id", tt.value)

			got, err := httpx.PathID(r, "id")

			if tt.wantErr != "" {
				// Текст идёт клиенту как есть: во внутренности strconv он попадать не должен.
				require.EqualError(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.want, got)
		})
	}
}
