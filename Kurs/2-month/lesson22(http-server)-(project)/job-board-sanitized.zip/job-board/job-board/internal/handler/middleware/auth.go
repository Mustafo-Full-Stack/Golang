package middleware

import (
	"context"
	"errors"
	"net/http"
	"strings"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/service"
)

type claimsKey struct{}

func withClaims(ctx context.Context, c *model.Claims) context.Context {
	return context.WithValue(ctx, claimsKey{}, c)
}

func ClaimsFromContext(ctx context.Context) (*model.Claims, bool) {
	c, ok := ctx.Value(claimsKey{}).(*model.Claims)
	return c, ok
}

func Auth(tokens service.TokenAuthenticator) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Схема авторизации регистронезависима (RFC 7235).
			scheme, token, ok := strings.Cut(r.Header.Get("Authorization"), " ")
			token = strings.TrimSpace(token)
			if !ok || !strings.EqualFold(scheme, "Bearer") || token == "" {
				httpx.WriteError(w, r, http.StatusUnauthorized, "missing bearer token", nil)
				return
			}
			claims, err := tokens.Authenticate(r.Context(), token)
			if err != nil {
				if errors.Is(err, model.ErrUnauthorized) {
					httpx.WriteError(w, r, http.StatusUnauthorized, "invalid or expired token", err)
					return
				}
				httpx.WriteServiceError(w, r, err)
				return
			}
			next.ServeHTTP(w, r.WithContext(withClaims(r.Context(), claims)))
		})
	}
}
