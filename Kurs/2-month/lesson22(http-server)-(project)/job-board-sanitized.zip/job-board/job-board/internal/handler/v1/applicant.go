package v1

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/service"
)

type applicantHandler struct {
	svc service.ApplicantService
}

func NewApplicantHandler(svc service.ApplicantService) *applicantHandler {
	return &applicantHandler{svc: svc}
}

func (h *applicantHandler) SearchVacancies(w http.ResponseWriter, r *http.Request) {
	f, err := parseVacancyFilter(r)
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	vacancies, err := h.svc.SearchVacancies(r.Context(), f)
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newListResponse(vacancies, newVacancyResponse))
}

func (h *applicantHandler) GetVacancy(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	v, err := h.svc.GetVacancy(r.Context(), id, userID(r))
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newVacancyDetailResponse(v))
}

func (h *applicantHandler) SaveResume(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[resumeRequest](w, r)
	if !ok {
		return
	}
	if _, err := h.svc.SaveResume(r.Context(), userID(r), req.toInput()); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *applicantHandler) GetResume(w http.ResponseWriter, r *http.Request) {
	resume, err := h.svc.GetResume(r.Context(), userID(r))
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newResumeResponse(resume))
}

func (h *applicantHandler) DeleteResume(w http.ResponseWriter, r *http.Request) {
	if err := h.svc.DeleteResume(r.Context(), userID(r)); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *applicantHandler) Apply(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[applyRequest](w, r)
	if !ok {
		return
	}
	a, err := h.svc.Apply(r.Context(), userID(r), req.toInput())
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusCreated, newApplicationResponse(a))
}

func (h *applicantHandler) ListMyApplications(w http.ResponseWriter, r *http.Request) {
	page, err := httpx.ParsePage(r)
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	applications, err := h.svc.ListMyApplications(r.Context(), userID(r), page)
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newListResponse(applications, newMyApplicationResponse))
}

func (h *applicantHandler) Withdraw(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	if err := h.svc.Withdraw(r.Context(), userID(r), id); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

const (
	maxQueryLen = 200
	maxTagLen   = 50
)

func parseVacancyFilter(r *http.Request) (model.VacancyFilter, error) {
	page, err := httpx.ParsePage(r)
	if err != nil {
		return model.VacancyFilter{}, err
	}
	q := r.URL.Query()
	f := model.VacancyFilter{
		Query:          q.Get("q"),
		City:           q.Get("city"),
		EmploymentType: model.EmploymentType(q.Get("employment_type")),
		Tags:           splitTags(q.Get("tags")),
		Page:           page,
	}
	if utf8.RuneCountInString(f.Query) > maxQueryLen {
		return model.VacancyFilter{}, fmt.Errorf("q must be at most %d characters", maxQueryLen)
	}
	for _, t := range f.Tags {
		if utf8.RuneCountInString(t) > maxTagLen {
			return model.VacancyFilter{}, fmt.Errorf("tag must be at most %d characters", maxTagLen)
		}
	}
	if s := q.Get("salary_from"); s != "" {
		n, err := strconv.Atoi(s)
		if err != nil {
			return model.VacancyFilter{}, fmt.Errorf("invalid salary_from %q", s)
		}
		f.SalaryFrom = &n
	}
	return f, nil
}

func splitTags(s string) []string {
	var tags []string
	for t := range strings.SplitSeq(s, ",") {
		if t = strings.TrimSpace(t); t != "" {
			tags = append(tags, t)
		}
	}
	return tags
}
