package middleware_test

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/handler/middleware"
	"github.com/rabboni171/job-board/internal/model"
)

type fakeTokens struct {
	claims *model.Claims
	err    error
}

func (f fakeTokens) Authenticate(context.Context, string) (*model.Claims, error) {
	return f.claims, f.err
}

func TestAuth(t *testing.T) {
	tests := []struct {
		name       string
		header     string
		tokens     fakeTokens
		wantStatus int
	}{
		{"ok", "Bearer t", fakeTokens{claims: &model.Claims{UserID: 1}}, http.StatusOK},
		{"lowercase scheme", "bearer t", fakeTokens{claims: &model.Claims{UserID: 1}}, http.StatusOK},
		{"no header", "", fakeTokens{}, http.StatusUnauthorized},
		{"unauthorized", "Bearer t", fakeTokens{err: model.Unauthorized("bad token")}, http.StatusUnauthorized},
		{"unauthorized with context", "Bearer t", fakeTokens{err: fmt.Errorf("authenticate: %w", model.Unauthorized("bad token"))}, http.StatusUnauthorized},
		{"store failure", "Bearer t", fakeTokens{err: errors.New("redis down")}, http.StatusInternalServerError},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			h := middleware.Auth(tt.tokens)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				got, ok := middleware.ClaimsFromContext(r.Context())
				require.True(t, ok)
				require.Equal(t, tt.tokens.claims, got)
				w.WriteHeader(http.StatusOK)
			}))
			req := httptest.NewRequest(http.MethodGet, "/x", nil)
			if tt.header != "" {
				req.Header.Set("Authorization", tt.header)
			}
			rec := httptest.NewRecorder()

			h.ServeHTTP(rec, req)

			require.Equal(t, tt.wantStatus, rec.Code)
		})
	}
}
