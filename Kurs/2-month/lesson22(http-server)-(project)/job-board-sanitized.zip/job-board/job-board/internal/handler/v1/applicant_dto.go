package v1

import "github.com/rabboni171/job-board/internal/model"

type vacancyDetailResponse struct {
	vacancyResponse
	Views int64 `json:"views"`
}

func newVacancyDetailResponse(v *model.VacancyView) vacancyDetailResponse {
	return vacancyDetailResponse{vacancyResponse: newVacancyResponse(v.Vacancy), Views: v.Views}
}

type resumeRequest struct {
	Title             string   `json:"title" validate:"notblank,max=100"`
	About             string   `json:"about" validate:"max=5000"`
	City              string   `json:"city" validate:"max=100"`
	ExperienceYears   int      `json:"experience_years"`
	SalaryExpectation *int     `json:"salary_expectation"`
	Skills            []string `json:"skills" validate:"dive,notblank,max=50"`
}

func (r resumeRequest) toInput() model.ResumeInput {
	return model.ResumeInput{
		Title:             r.Title,
		About:             r.About,
		City:              r.City,
		ExperienceYears:   r.ExperienceYears,
		SalaryExpectation: r.SalaryExpectation,
		Skills:            r.Skills,
	}
}

type applyRequest struct {
	VacancyID   int64  `json:"vacancy_id" validate:"required,gt=0"`
	CoverLetter string `json:"cover_letter" validate:"notblank,max=5000"`
}

func (r applyRequest) toInput() model.ApplyInput {
	return model.ApplyInput{VacancyID: r.VacancyID, CoverLetter: r.CoverLetter}
}

type applicationResponse struct {
	ID int64 `json:"id"`
}

func newApplicationResponse(a *model.Application) applicationResponse {
	return applicationResponse{ID: a.ID}
}

type myApplicationResponse struct {
	ID            int64  `json:"id"`
	VacancyID     int64  `json:"vacancy_id"`
	VacancyTitle  string `json:"vacancy_title"`
	EmployerName  string `json:"employer_name"`
	VacancyStatus string `json:"vacancy_status"`
	Status        string `json:"status"`
	CoverLetter   string `json:"cover_letter"`
	CreatedAt     string `json:"created_at"`
	UpdatedAt     string `json:"updated_at"`
}

func newMyApplicationResponse(a model.ApplicationWithVacancy) myApplicationResponse {
	return myApplicationResponse{
		ID:            a.Application.ID,
		VacancyID:     a.Application.VacancyID,
		VacancyTitle:  a.VacancyTitle,
		EmployerName:  a.EmployerName,
		VacancyStatus: string(a.VacancyStatus),
		Status:        string(a.Application.Status),
		CoverLetter:   a.Application.CoverLetter,
		CreatedAt:     formatTime(a.Application.CreatedAt),
		UpdatedAt:     formatTime(a.Application.UpdatedAt),
	}
}
