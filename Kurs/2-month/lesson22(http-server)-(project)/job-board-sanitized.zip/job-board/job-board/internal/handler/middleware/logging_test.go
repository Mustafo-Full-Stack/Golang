package middleware_test

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/handler/middleware"
	"github.com/rabboni171/job-board/internal/model"
)

func TestLogging(t *testing.T) {
	tests := []struct {
		name      string
		handler   http.HandlerFunc
		wantLevel string
	}{
		{"200 info", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusOK) }, "INFO"},
		{"404 warn", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusNotFound) }, "WARN"},
		{"500 error", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusInternalServerError) }, "ERROR"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var buf bytes.Buffer
			log := slog.New(slog.NewJSONHandler(&buf, nil))
			h := middleware.Logging(log)(tt.handler)
			h.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest(http.MethodGet, "/x", nil))

			var rec map[string]any
			if err := json.Unmarshal(buf.Bytes(), &rec); err != nil {
				t.Fatal(err)
			}
			if rec["level"] != tt.wantLevel {
				t.Errorf("level = %v, want %v", rec["level"], tt.wantLevel)
			}
			for _, k := range []string{"method", "path", "status", "duration"} {
				if _, ok := rec[k]; !ok {
					t.Errorf("no %q in access log", k)
				}
			}
		})
	}
}

func TestLogging_ServiceError(t *testing.T) {
	tests := []struct {
		name      string
		err       error
		wantLevel string
		wantBody  string
	}{
		{
			name:      "client error is shown to client",
			err:       fmt.Errorf("close vacancy: %w", model.Conflict("vacancy is closed")),
			wantLevel: "WARN",
			wantBody:  `{"error":"conflict: vacancy is closed"}`,
		},
		{
			name:      "internal error is hidden from client but logged in full",
			err:       fmt.Errorf("create vacancy: %w", errors.New("connection refused")),
			wantLevel: "ERROR",
			wantBody:  `{"error":"internal server error"}`,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var buf, errLog bytes.Buffer
			prev := slog.Default()
			slog.SetDefault(slog.New(slog.NewTextHandler(&errLog, nil)))
			t.Cleanup(func() { slog.SetDefault(prev) })
			log := slog.New(slog.NewJSONHandler(&buf, nil))
			h := middleware.Logging(log)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				httpx.WriteServiceError(w, r, tt.err)
			}))
			resp := httptest.NewRecorder()
			h.ServeHTTP(resp, httptest.NewRequest(http.MethodGet, "/x", nil))

			var rec map[string]any
			if err := json.Unmarshal(buf.Bytes(), &rec); err != nil {
				t.Fatal(err)
			}
			if rec["level"] != tt.wantLevel {
				t.Errorf("level = %v, want %v", rec["level"], tt.wantLevel)
			}
			if got := strings.TrimSpace(resp.Body.String()); got != tt.wantBody {
				t.Errorf("body = %s, want %s", got, tt.wantBody)
			}
			// полную цепочку ошибки пишет httpx в slog.Default, а не middleware
			if !strings.Contains(errLog.String(), fmt.Sprintf("err=%q", tt.err.Error())) {
				t.Errorf("full error not in error log: %s", errLog.String())
			}
		})
	}
}
