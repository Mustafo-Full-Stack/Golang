package v1

import "github.com/rabboni171/job-board/internal/model"

type vacancyResponse struct {
	ID             int64    `json:"id"`
	EmployerName   string   `json:"employer_name"`
	Title          string   `json:"title"`
	Description    string   `json:"description"`
	City           string   `json:"city"`
	EmploymentType string   `json:"employment_type"`
	SalaryFrom     *int     `json:"salary_from"`
	SalaryTo       *int     `json:"salary_to"`
	Tags           []string `json:"tags"`
	Status         string   `json:"status"`
	CreatedAt      string   `json:"created_at"`
	UpdatedAt      string   `json:"updated_at"`
}

func newVacancyResponse(v model.Vacancy) vacancyResponse {
	return vacancyResponse{
		ID:             v.ID,
		EmployerName:   v.EmployerName,
		Title:          v.Title,
		Description:    v.Description,
		City:           v.City,
		EmploymentType: string(v.EmploymentType),
		SalaryFrom:     v.SalaryFrom,
		SalaryTo:       v.SalaryTo,
		Tags:           nonNil(v.Tags),
		Status:         string(v.Status),
		CreatedAt:      formatTime(v.CreatedAt),
		UpdatedAt:      formatTime(v.UpdatedAt),
	}
}
