package v1

import (
	"errors"
	"fmt"
	"reflect"
	"strings"

	"github.com/go-playground/validator/v10"
	"golang.org/x/net/publicsuffix"
)

var validate = newValidator()

func newValidator() *validator.Validate {
	v := validator.New(validator.WithRequiredStructEnabled())
	// в ошибках поля называются как в JSON
	v.RegisterTagNameFunc(func(f reflect.StructField) string {
		name, _, _ := strings.Cut(f.Tag.Get("json"), ",")
		if name == "-" {
			return ""
		}
		return name
	})
	// required пропускает строку из пробелов
	if err := v.RegisterValidation("notblank", func(fl validator.FieldLevel) bool {
		return strings.TrimSpace(fl.Field().String()) != ""
	}); err != nil {
		panic(err)
	}
	if err := v.RegisterValidation("emaildomain", validEmailDomain); err != nil {
		panic(err)
	}
	return v
}

// Формат email не ловит выдуманные зоны вроде a@b.qnxt: домен должен оканчиваться
// на существующую зону из списка ICANN. Есть ли такой ящик, проверить можно только письмом.
func validEmailDomain(fl validator.FieldLevel) bool {
	_, domain, ok := strings.Cut(fl.Field().String(), "@")
	if !ok {
		return false
	}
	domain = strings.ToLower(domain)
	suffix, icann := publicsuffix.PublicSuffix(domain)
	return icann && suffix != domain
}

func validateRequest(req any) error {
	err := validate.Struct(req)
	var errs validator.ValidationErrors
	if !errors.As(err, &errs) {
		return err
	}
	return errors.New(fieldMessage(errs[0]))
}

func fieldMessage(fe validator.FieldError) string {
	switch fe.Tag() {
	case "required", "notblank":
		return fe.Field() + " is required"
	case "email":
		return fe.Field() + " must be a valid email"
	case "emaildomain":
		return fe.Field() + " domain does not exist"
	case "max":
		return fmt.Sprintf("%s must be at most %s characters", fe.Field(), fe.Param())
	case "gt":
		return fe.Field() + " must be positive"
	}
	return fe.Field() + " is invalid"
}
