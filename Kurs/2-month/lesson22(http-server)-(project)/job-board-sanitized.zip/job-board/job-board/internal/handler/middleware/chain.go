package middleware

import "net/http"

type Middleware func(http.Handler) http.Handler

// Chain оборачивает h в middleware; первый в списке будет самым внешним.
func Chain(h http.Handler, mws ...Middleware) http.Handler {
	for i := len(mws) - 1; i >= 0; i-- {
		h = mws[i](h)
	}
	return h
}
