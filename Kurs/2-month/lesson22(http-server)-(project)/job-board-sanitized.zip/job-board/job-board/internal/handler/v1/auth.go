package v1

import (
	"net/http"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/service"
)

type authHandler struct {
	svc      service.AccountService
	sessions service.SessionManager
}

func NewAuthHandler(svc service.AccountService, sessions service.SessionManager) *authHandler {
	return &authHandler{svc: svc, sessions: sessions}
}

func (h *authHandler) SignUp(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[signUpRequest](w, r)
	if !ok {
		return
	}
	u, err := h.svc.SignUp(r.Context(), req.toInput())
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusCreated, newSignUpResponse(u))
}

func (h *authHandler) Login(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[loginRequest](w, r)
	if !ok {
		return
	}
	pair, err := h.svc.Login(r.Context(), req.toInput())
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newTokenResponse(pair))
}

func (h *authHandler) Refresh(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[refreshRequest](w, r)
	if !ok {
		return
	}
	pair, err := h.sessions.Refresh(r.Context(), req.RefreshToken)
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newTokenResponse(pair))
}

func (h *authHandler) Logout(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[refreshRequest](w, r)
	if !ok {
		return
	}
	if err := h.sessions.Logout(r.Context(), req.RefreshToken); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
