package httpx

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/rabboni171/job-board/internal/model"
)

const (
	defaultLimit = 20
	maxLimit     = 100
)

func DecodeJSON(w http.ResponseWriter, r *http.Request, dst any) error {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	return dec.Decode(dst)
}

func PathID(r *http.Request, name string) (int64, error) {
	id, err := strconv.ParseInt(r.PathValue(name), 10, 64)
	if err != nil || id <= 0 {
		// Текст ошибки strconv не включаем: сообщение уходит клиенту в ответе 400 как есть.
		return 0, fmt.Errorf("invalid %s: must be a positive integer", name)
	}
	return id, nil
}

func ParsePage(r *http.Request) (model.Page, error) {
	q := r.URL.Query()
	p := model.Page{Limit: defaultLimit}

	if s := q.Get("limit"); s != "" {
		limit, err := strconv.Atoi(s)
		if err != nil || limit < 1 {
			return model.Page{}, fmt.Errorf("invalid limit %q", s)
		}
		p.Limit = min(limit, maxLimit)
	}
	if s := q.Get("offset"); s != "" {
		offset, err := strconv.Atoi(s)
		if err != nil || offset < 0 {
			return model.Page{}, fmt.Errorf("invalid offset %q", s)
		}
		p.Offset = offset
	}
	return p, nil
}
