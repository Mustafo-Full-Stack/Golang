package v1

import "github.com/rabboni171/job-board/internal/model"

type signUpRequest struct {
	Email    string `json:"email" validate:"required,email,emaildomain,max=254"`
	Password string `json:"password" validate:"required"`
	Name     string `json:"name" validate:"notblank,max=100"`
	Role     string `json:"role" validate:"required"`
}

func (r signUpRequest) toInput() model.SignUpInput {
	return model.SignUpInput{
		Email:    r.Email,
		Password: r.Password,
		Name:     r.Name,
		Role:     model.Role(r.Role),
	}
}

type loginRequest struct {
	Email    string `json:"email" validate:"required,email,max=254"`
	Password string `json:"password" validate:"required"`
}

func (r loginRequest) toInput() model.LoginInput {
	return model.LoginInput{Email: r.Email, Password: r.Password}
}

type signUpResponse struct {
	ID int64 `json:"id"`
}

func newSignUpResponse(u *model.User) signUpResponse {
	return signUpResponse{ID: u.ID}
}

type refreshRequest struct {
	RefreshToken string `json:"refresh_token" validate:"required"`
}

type tokenResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	TokenType    string `json:"token_type"`
}

func newTokenResponse(p *model.TokenPair) tokenResponse {
	return tokenResponse{
		AccessToken:  p.AccessToken,
		RefreshToken: p.RefreshToken,
		TokenType:    "Bearer",
	}
}
