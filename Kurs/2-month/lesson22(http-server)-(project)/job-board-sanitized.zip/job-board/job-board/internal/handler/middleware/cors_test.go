package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/handler/middleware"
)

func TestCORS(t *testing.T) {
	const allowed = "http://localhost:3000"
	tests := []struct {
		name          string
		method        string
		origin        string
		preflight     bool
		wantStatus    int
		wantAllowed   bool
		wantNextCalls bool
	}{
		{name: "allowed origin gets headers", method: http.MethodGet, origin: allowed, wantStatus: http.StatusOK, wantAllowed: true, wantNextCalls: true},
		{name: "unknown origin gets no headers", method: http.MethodGet, origin: "https://evil.example", wantStatus: http.StatusOK, wantNextCalls: true},
		{name: "no origin (curl) passes as is", method: http.MethodGet, wantStatus: http.StatusOK, wantNextCalls: true},
		{name: "preflight from allowed origin answered here", method: http.MethodOptions, origin: allowed, preflight: true, wantStatus: http.StatusNoContent, wantAllowed: true},
		{name: "preflight from unknown origin goes to router", method: http.MethodOptions, origin: "https://evil.example", preflight: true, wantStatus: http.StatusOK, wantNextCalls: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			called := false
			h := middleware.CORS([]string{" " + allowed + " ", ""})(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
				called = true
			}))
			r := httptest.NewRequest(tt.method, "/api/v1/vacancies", nil)
			if tt.origin != "" {
				r.Header.Set("Origin", tt.origin)
			}
			if tt.preflight {
				r.Header.Set("Access-Control-Request-Method", http.MethodPost)
			}
			w := httptest.NewRecorder()

			h.ServeHTTP(w, r)

			require.Equal(t, tt.wantStatus, w.Code)
			require.Equal(t, tt.wantNextCalls, called)
			require.Equal(t, "Origin", w.Header().Get("Vary"))
			if !tt.wantAllowed {
				require.Empty(t, w.Header().Get("Access-Control-Allow-Origin"))
				return
			}
			require.Equal(t, tt.origin, w.Header().Get("Access-Control-Allow-Origin"))
			require.Equal(t, "X-Request-ID", w.Header().Get("Access-Control-Expose-Headers"))
			if tt.preflight {
				require.Contains(t, w.Header().Get("Access-Control-Allow-Headers"), "Authorization")
				require.Contains(t, w.Header().Get("Access-Control-Allow-Methods"), http.MethodPatch)
			}
		})
	}
}
