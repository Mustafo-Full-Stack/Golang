package v1

import (
	"net/http"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/service"
)

type employerHandler struct {
	svc service.EmployerService
}

func NewEmployerHandler(svc service.EmployerService) *employerHandler {
	return &employerHandler{svc: svc}
}

func (h *employerHandler) CreateVacancy(w http.ResponseWriter, r *http.Request) {
	req, ok := bind[vacancyRequest](w, r)
	if !ok {
		return
	}
	v, err := h.svc.CreateVacancy(r.Context(), userID(r), req.toInput())
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusCreated, idResponse{ID: v.ID})
}

func (h *employerHandler) ListMyVacancies(w http.ResponseWriter, r *http.Request) {
	page, err := httpx.ParsePage(r)
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	vacancies, err := h.svc.ListMyVacancies(r.Context(), userID(r), page)
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newListResponse(vacancies, newVacancyResponse))
}

func (h *employerHandler) UpdateVacancy(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	req, ok := bind[vacancyRequest](w, r)
	if !ok {
		return
	}
	if _, err := h.svc.UpdateVacancy(r.Context(), userID(r), id, req.toInput()); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *employerHandler) CloseVacancy(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	if err := h.svc.CloseVacancy(r.Context(), userID(r), id); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *employerHandler) DeleteVacancy(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	if err := h.svc.DeleteVacancy(r.Context(), userID(r), id); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *employerHandler) ListApplications(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	page, err := httpx.ParsePage(r)
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	status := model.ApplicationStatus(r.URL.Query().Get("status"))
	applications, err := h.svc.ListApplications(r.Context(), userID(r), id, status, page)
	if err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	httpx.WriteJSON(w, http.StatusOK, newListResponse(applications, newApplicationWithResumeResponse))
}

func (h *employerHandler) ChangeApplicationStatus(w http.ResponseWriter, r *http.Request) {
	id, err := httpx.PathID(r, "id")
	if err != nil {
		httpx.WriteBadRequest(w, r, err)
		return
	}
	req, ok := bind[statusRequest](w, r)
	if !ok {
		return
	}
	if err := h.svc.ChangeApplicationStatus(r.Context(), userID(r), id, model.ApplicationStatus(req.Status)); err != nil {
		httpx.WriteServiceError(w, r, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
