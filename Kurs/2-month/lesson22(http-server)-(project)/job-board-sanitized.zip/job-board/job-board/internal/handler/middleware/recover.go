package middleware

import (
	"log/slog"
	"net/http"
	"runtime/debug"

	"github.com/rabboni171/job-board/internal/handler/httpx"
)

func Recover(log *slog.Logger) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			defer func() {
				if rec := recover(); rec != nil {
					// так net/http сам обрывает ответ: это не ошибка, логировать и отвечать 500 не нужно
					if rec == http.ErrAbortHandler {
						panic(rec)
					}
					log.ErrorContext(r.Context(), "panic recovered",
						"method", r.Method,
						"path", r.URL.Path,
						"panic", rec,
						"stack", string(debug.Stack()),
					)
					// Причина со стеком уже в логе выше, поэтому отвечаем без WriteError и второй строки лога.
					httpx.WriteJSON(w, http.StatusInternalServerError, map[string]string{"error": "internal server error"})
				}
			}()
			next.ServeHTTP(w, r)
		})
	}
}
