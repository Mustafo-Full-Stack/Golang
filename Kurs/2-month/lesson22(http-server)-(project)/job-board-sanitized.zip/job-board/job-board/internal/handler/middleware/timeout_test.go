package middleware_test

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/handler/middleware"
)

func TestTimeout(t *testing.T) {

	tests := []struct {
		name       string
		timeout    time.Duration
		wantStatus int
	}{
		{name: "handler finishes in time", timeout: time.Second, wantStatus: http.StatusOK},
		{name: "deadline exceeded", timeout: 10 * time.Millisecond, wantStatus: http.StatusServiceUnavailable},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			h := middleware.Timeout(tt.timeout)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				_, ok := r.Context().Deadline()
				require.True(t, ok)
				// имитация запроса к БД, который уважает контекст
				select {
				case <-time.After(50 * time.Millisecond):
					w.WriteHeader(http.StatusOK)
				case <-r.Context().Done():
					httpx.WriteServiceError(w, r, errors.New("query failed"))
				}
			}))

			rec := httptest.NewRecorder()
			h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", nil))
			require.Equal(t, tt.wantStatus, rec.Code)
		})
	}
}
