package v1

import (
	"net/http"
	"time"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/handler/middleware"
	"github.com/rabboni171/job-board/internal/model"
)

// bind при ошибке сам пишет 400.
func bind[T any](w http.ResponseWriter, r *http.Request) (T, bool) {
	var req T
	if err := httpx.DecodeJSON(w, r, &req); err != nil {
		httpx.WriteError(w, r, http.StatusBadRequest, "invalid json body", err)
		return req, false
	}
	if err := validateRequest(&req); err != nil {
		httpx.WriteBadRequest(w, r, err)
		return req, false
	}
	return req, true
}

// idResponse — ответ на создание ресурса, если у него нет собственного DTO ответа.
type idResponse struct {
	ID int64 `json:"id"`
}

type listResponse[T any] struct {
	Items []T `json:"items"`
	Total int `json:"total"`
}

func newListResponse[M, T any](p *model.Paged[M], toDTO func(M) T) listResponse[T] {
	items := make([]T, 0, len(p.Items))
	for _, m := range p.Items {
		items = append(items, toDTO(m))
	}
	return listResponse[T]{Items: items, Total: p.Total}
}

func formatTime(t time.Time) string { return t.UTC().Format(time.RFC3339) }

// userID: Auth гарантирует claims в контексте, поэтому ok не проверяем.
func userID(r *http.Request) int64 {
	claims, _ := middleware.ClaimsFromContext(r.Context())
	return claims.UserID
}

func nonNil(s []string) []string {
	if s == nil {
		return []string{}
	}
	return s
}
