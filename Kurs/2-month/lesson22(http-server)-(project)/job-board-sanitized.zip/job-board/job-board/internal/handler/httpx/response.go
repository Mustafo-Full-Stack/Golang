package httpx

import (
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"

	"github.com/rabboni171/job-board/internal/model"
)

func WriteJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	if v != nil {
		_ = json.NewEncoder(w).Encode(v)
	}
}

// WriteError отвечает клиенту ошибкой msg и пишет в лог строку "request failed" с причиной:
// cause, если она есть (её видит только лог), иначе msg. Уровень по статусу: 4xx — WARN, 5xx — ERROR.
func WriteError(w http.ResponseWriter, r *http.Request, status int, msg string, cause error) {
	level := slog.LevelWarn
	if status >= http.StatusInternalServerError {
		level = slog.LevelError
	}
	var reason any = msg
	if cause != nil {
		reason = cause
	}
	slog.Log(r.Context(), level, "request failed",
		"method", r.Method, "path", r.URL.Path, "status", status, "err", reason)
	WriteJSON(w, status, map[string]string{"error": msg})
}

// WriteBadRequest — 400, когда текст ошибки разбора запроса и есть ответ клиенту.
func WriteBadRequest(w http.ResponseWriter, r *http.Request, err error) {
	WriteError(w, r, http.StatusBadRequest, err.Error(), err)
}

var statusByKind = map[error]int{
	model.ErrUnauthorized: http.StatusUnauthorized,
	model.ErrNotFound:     http.StatusNotFound,
	model.ErrConflict:     http.StatusConflict,
	model.ErrInvalidInput: http.StatusUnprocessableEntity,
}

// WriteServiceError переводит ошибку сервиса в HTTP-ответ. Клиентская ошибка (model.Error)
// уходит клиенту своим текстом, внутренняя — обезличенным сообщением; в лог всегда идёт полная цепочка.
func WriteServiceError(w http.ResponseWriter, r *http.Request, err error) {
	status, msg := statusAndMessage(r, err)
	WriteError(w, r, status, msg, err)
}

func statusAndMessage(r *http.Request, err error) (int, string) {
	var clientErr *model.Error
	if errors.As(err, &clientErr) {
		if status, ok := statusByKind[clientErr.Kind]; ok {
			return status, clientErr.Msg
		}
	}
	// Драйверы не всегда оборачивают context-ошибку, поэтому смотрим и на контекст запроса.
	if errors.Is(err, context.DeadlineExceeded) || errors.Is(r.Context().Err(), context.DeadlineExceeded) {
		return http.StatusServiceUnavailable, "request timeout"
	}
	return http.StatusInternalServerError, "internal server error"
}
