package httpx_test

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/model"
)

// captureLog подменяет slog.Default буфером и возвращает его; прежний логгер вернётся в t.Cleanup.
func captureLog(t *testing.T) *bytes.Buffer {
	t.Helper()
	var buf bytes.Buffer
	prev := slog.Default()
	slog.SetDefault(slog.New(slog.NewTextHandler(&buf, nil)))
	t.Cleanup(func() { slog.SetDefault(prev) })
	return &buf
}

func TestWriteServiceError(t *testing.T) {
	expired, cancel := context.WithTimeout(context.Background(), 0)
	defer cancel()

	tests := []struct {
		name       string
		ctx        context.Context
		err        error
		wantStatus int
		wantBody   string
		wantLevel  string
	}{
		{name: "unauthorized", err: model.Unauthorized("invalid email or password"), wantStatus: http.StatusUnauthorized, wantBody: "unauthorized: invalid email or password", wantLevel: "WARN"},
		{name: "not found", err: model.NotFound("vacancy"), wantStatus: http.StatusNotFound, wantBody: "vacancy not found", wantLevel: "WARN"},
		{name: "conflict", err: model.Conflict("vacancy is closed"), wantStatus: http.StatusConflict, wantBody: "conflict: vacancy is closed", wantLevel: "WARN"},
		{name: "invalid input", err: model.InvalidInput("salary must not be negative"), wantStatus: http.StatusUnprocessableEntity, wantBody: "invalid input: salary must not be negative", wantLevel: "WARN"},
		{name: "unauthorized with context", err: fmt.Errorf("parse token: %w", model.Unauthorized("wrong token type")), wantStatus: http.StatusUnauthorized, wantBody: "unauthorized: wrong token type", wantLevel: "WARN"},
		{name: "not found with context keeps client text", err: fmt.Errorf("get vacancy: %w", model.NotFound("vacancy")), wantStatus: http.StatusNotFound, wantBody: "vacancy not found", wantLevel: "WARN"},
		{name: "conflict with context keeps client text", err: fmt.Errorf("close vacancy: %w", model.Conflict("vacancy was changed, try again")), wantStatus: http.StatusConflict, wantBody: "conflict: vacancy was changed, try again", wantLevel: "WARN"},
		{name: "invalid input with context keeps client text", err: fmt.Errorf("create: %w", model.InvalidInput("at most %d tags", 10)), wantStatus: http.StatusUnprocessableEntity, wantBody: "invalid input: at most 10 tags", wantLevel: "WARN"},
		{name: "context nested twice", err: fmt.Errorf("apply: %w", fmt.Errorf("get vacancy: %w", model.NotFound("vacancy"))), wantStatus: http.StatusNotFound, wantBody: "vacancy not found", wantLevel: "WARN"},
		{name: "deadline in the chain", err: fmt.Errorf("search vacancies: %w", context.DeadlineExceeded), wantStatus: http.StatusServiceUnavailable, wantBody: "request timeout", wantLevel: "ERROR"},
		{name: "driver lost the deadline, request context has it", ctx: expired, err: errors.New("conn closed"), wantStatus: http.StatusServiceUnavailable, wantBody: "request timeout", wantLevel: "ERROR"},
		{name: "plain error is 500 and its text is hidden", err: fmt.Errorf("create vacancy: %w", errors.New(`relation "vacancies" does not exist`)), wantStatus: http.StatusInternalServerError, wantBody: "internal server error", wantLevel: "ERROR"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logs := captureLog(t)
			ctx := tt.ctx
			if ctx == nil {
				ctx = context.Background()
			}
			w := httptest.NewRecorder()
			r := httptest.NewRequest(http.MethodGet, "/x", nil).WithContext(ctx)

			httpx.WriteServiceError(w, r, tt.err)

			require.Equal(t, tt.wantStatus, w.Code)
			require.JSONEq(t, fmt.Sprintf(`{"error":%q}`, tt.wantBody), w.Body.String())
			// В лог уходит полная цепочка, даже если клиенту показан общий текст.
			require.Contains(t, logs.String(), "request failed")
			require.Contains(t, logs.String(), "level="+tt.wantLevel)
			require.Contains(t, logs.String(), "status="+fmt.Sprint(tt.wantStatus))
			require.Contains(t, logs.String(), "path=/x")
			require.Contains(t, logs.String(), fmt.Sprintf("err=%q", tt.err.Error()))
		})
	}
}

func TestWriteError(t *testing.T) {
	tests := []struct {
		name      string
		status    int
		msg       string
		cause     error
		wantLevel string
		wantErr   string // что попадает в лог
	}{
		{name: "without cause logs client text", status: http.StatusUnauthorized, msg: "missing bearer token", wantLevel: "WARN", wantErr: "missing bearer token"},
		{name: "cause is logged, client gets msg", status: http.StatusBadRequest, msg: "invalid json body", cause: errors.New("unexpected EOF"), wantLevel: "WARN", wantErr: "unexpected EOF"},
		{name: "5xx is error", status: http.StatusServiceUnavailable, msg: "postgres unavailable", cause: errors.New("dial tcp: connection refused"), wantLevel: "ERROR", wantErr: "dial tcp: connection refused"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logs := captureLog(t)
			w := httptest.NewRecorder()

			httpx.WriteError(w, httptest.NewRequest(http.MethodPost, "/x", nil), tt.status, tt.msg, tt.cause)

			require.Equal(t, tt.status, w.Code)
			require.JSONEq(t, fmt.Sprintf(`{"error":%q}`, tt.msg), w.Body.String())
			require.Contains(t, logs.String(), "request failed")
			require.Contains(t, logs.String(), "level="+tt.wantLevel)
			require.Contains(t, logs.String(), fmt.Sprintf("err=%q", tt.wantErr))
		})
	}
}

func TestWriteBadRequest(t *testing.T) {
	logs := captureLog(t)
	w := httptest.NewRecorder()

	httpx.WriteBadRequest(w, httptest.NewRequest(http.MethodGet, "/x", nil), errors.New("invalid limit \"abc\""))

	require.Equal(t, http.StatusBadRequest, w.Code)
	require.JSONEq(t, `{"error":"invalid limit \"abc\""}`, w.Body.String())
	require.Contains(t, logs.String(), "level=WARN")
}
