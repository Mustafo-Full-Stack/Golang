package middleware_test

import (
	"errors"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/handler/middleware"
	"github.com/rabboni171/job-board/pkg/logger"
)

// Строка запроса и строка с причиной ошибки связаны одним request_id, и он же уходит клиенту в заголовке.
func TestRequestID(t *testing.T) {
	file := filepath.Join(t.TempDir(), "app.log")
	log, closeLog, err := logger.New("local", slog.LevelInfo, file)
	require.NoError(t, err)
	t.Cleanup(func() { _ = closeLog() })
	prev := slog.Default()
	slog.SetDefault(log)
	t.Cleanup(func() { slog.SetDefault(prev) })

	h := middleware.Chain(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		httpx.WriteServiceError(w, r, errors.New("boom"))
	}), middleware.RequestID, middleware.Logging(log))
	w := httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/x", nil))

	id := w.Header().Get("X-Request-ID")
	require.NotEmpty(t, id)
	raw, err := os.ReadFile(file)
	require.NoError(t, err)
	lines := strings.Split(strings.TrimSpace(string(raw)), "\n")
	require.Len(t, lines, 2) // request failed + http request
	for _, line := range lines {
		require.Contains(t, line, "request_id="+id)
	}
}

func TestRequestID_Header(t *testing.T) {
	tests := []struct {
		name     string
		incoming string
		wantSame bool // id из запроса сохраняется
	}{
		{name: "incoming id is kept", incoming: "front-123", wantSame: true},
		{name: "empty header generates uuid"},
		{name: "too long id is replaced", incoming: strings.Repeat("a", 129)},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			h := middleware.RequestID(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
			r := httptest.NewRequest(http.MethodGet, "/x", nil)
			if tt.incoming != "" {
				r.Header.Set("X-Request-ID", tt.incoming)
			}
			w := httptest.NewRecorder()

			h.ServeHTTP(w, r)

			got := w.Header().Get("X-Request-ID")
			if tt.wantSame {
				require.Equal(t, tt.incoming, got)
				return
			}
			require.NoError(t, uuid.Validate(got))
		})
	}
}
