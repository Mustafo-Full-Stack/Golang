package middleware

import (
	"fmt"
	"net/http"

	"github.com/rabboni171/job-board/internal/handler/httpx"
	"github.com/rabboni171/job-board/internal/model"
)

func RequireRole(role model.Role) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			claims, ok := ClaimsFromContext(r.Context())
			if !ok || claims.Role != role {
				httpx.WriteError(w, r, http.StatusForbidden, "forbidden", fmt.Errorf("role %s required", role))
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}
