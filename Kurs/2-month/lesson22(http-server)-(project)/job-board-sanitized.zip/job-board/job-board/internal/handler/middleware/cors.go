package middleware

import (
	"net/http"
	"strings"
)

// CORS разрешает браузеру вызывать API со страниц другого origin (например, фронт на localhost:3000,
// API на localhost:8080). Заголовки получают только origin из списка, остальным браузер ответ не отдаст.
// curl и Postman CORS не проверяют. Allow-Credentials не нужен: токен идёт в Authorization, а не в cookie.
func CORS(allowedOrigins []string) Middleware {
	allowed := make(map[string]bool, len(allowedOrigins))
	for _, origin := range allowedOrigins {
		if origin = strings.TrimSpace(origin); origin != "" {
			allowed[origin] = true
		}
	}
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			origin := r.Header.Get("Origin")
			// Ответ зависит от Origin: кэши не должны отдавать его странице с другим origin.
			w.Header().Add("Vary", "Origin")
			if !allowed[origin] {
				next.ServeHTTP(w, r)
				return
			}

			h := w.Header()
			h.Set("Access-Control-Allow-Origin", origin)
			h.Set("Access-Control-Expose-Headers", requestIDHeader)
			// Preflight: перед запросом с Authorization или JSON браузер спрашивает разрешение через OPTIONS.
			if r.Method == http.MethodOptions && r.Header.Get("Access-Control-Request-Method") != "" {
				h.Set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE")
				h.Set("Access-Control-Allow-Headers", "Authorization, Content-Type, "+requestIDHeader)
				h.Set("Access-Control-Max-Age", "600") // браузер запомнит разрешение на 10 минут
				w.WriteHeader(http.StatusNoContent)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}
