package handler

import (
	"net/http"

	httpSwagger "github.com/swaggo/http-swagger/v2"

	"github.com/rabboni171/job-board/docs"
)

func registerDocs(mux *http.ServeMux) {
	mux.HandleFunc("GET /docs/openapi.yaml", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/yaml")
		_, _ = w.Write(docs.OpenAPI)
	})

	mux.Handle("GET /api/docs/", httpSwagger.Handler(httpSwagger.URL("/docs/openapi.yaml")))

	mux.HandleFunc("GET /api/docs", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/api/docs/index.html", http.StatusMovedPermanently)
	})
}
