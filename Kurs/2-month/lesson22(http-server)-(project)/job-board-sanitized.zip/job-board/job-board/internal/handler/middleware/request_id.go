package middleware

import (
	"net/http"

	"github.com/google/uuid"

	"github.com/rabboni171/job-board/pkg/logger"
)

const (
	requestIDHeader = "X-Request-ID"
	// Длинный чужой id раздувал бы каждую строку лога запроса: такой заменяем своим.
	maxRequestIDLen = 128
)

// RequestID берёт id запроса из X-Request-ID (его может выставить фронт или прокси), а если его нет —
// генерирует UUID. Id попадает во все строки лога запроса и возвращается в заголовке ответа,
// поэтому по нему сразу находятся все логи этого запроса.
func RequestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get(requestIDHeader)
		if id == "" || len(id) > maxRequestIDLen {
			id = uuid.NewString()
		}
		w.Header().Set(requestIDHeader, id)
		next.ServeHTTP(w, r.WithContext(logger.WithRequestID(r.Context(), id)))
	})
}
