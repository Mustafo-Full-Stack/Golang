package v1

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestValidateRequest(t *testing.T) {
	validVacancy := func() vacancyRequest {
		return vacancyRequest{Title: "Go dev", Description: "d", EmploymentType: "full"}
	}
	tests := []struct {
		name    string
		req     any
		wantErr string
	}{
		{name: "signup ok", req: &signUpRequest{Email: "a@b.io", Password: "12345678", Name: "N", Role: "applicant"}},
		{name: "signup empty email", req: &signUpRequest{Password: "p", Name: "N", Role: "r"}, wantErr: "email is required"},
		{name: "signup bad email", req: &signUpRequest{Email: "not-an-email", Password: "p", Name: "N", Role: "r"}, wantErr: "email must be a valid email"},
		{name: "signup made-up tld", req: &signUpRequest{Email: "QBld75e6XhJbB@sHcxXxXqJztTmLf.qnxt", Password: "p", Name: "N", Role: "r"}, wantErr: "email domain does not exist"},
		{name: "signup second-level zone", req: &signUpRequest{Email: "a@mail.co.uk", Password: "p", Name: "N", Role: "r"}},
		{name: "signup blank name", req: &signUpRequest{Email: "a@b.io", Password: "p", Name: "   ", Role: "r"}, wantErr: "name is required"},
		{name: "login ok", req: &loginRequest{Email: "a@b.io", Password: "p"}},
		{name: "vacancy ok", req: ptr(validVacancy())},
		{name: "vacancy long cyrillic title", req: ptr(func() vacancyRequest { r := validVacancy(); r.Title = strings.Repeat("я", 101); return r }()), wantErr: "title must be at most 100 characters"},
		{name: "vacancy empty tag", req: ptr(func() vacancyRequest { r := validVacancy(); r.Tags = []string{"go", ""}; return r }()), wantErr: "tags[1] is required"},
		{name: "apply ok", req: &applyRequest{VacancyID: 1, CoverLetter: "hi"}},
		{name: "apply zero vacancy_id", req: &applyRequest{CoverLetter: "hi"}, wantErr: "vacancy_id is required"},
		{name: "apply negative vacancy_id", req: &applyRequest{VacancyID: -1, CoverLetter: "hi"}, wantErr: "vacancy_id must be positive"},
		{name: "resume skill too long", req: &resumeRequest{Title: "t", Skills: []string{strings.Repeat("a", 51)}}, wantErr: "skills[0] must be at most 50 characters"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := validateRequest(tt.req)

			if tt.wantErr == "" {
				require.NoError(t, err)
				return
			}
			require.EqualError(t, err, tt.wantErr)
		})
	}
}

func ptr[T any](v T) *T { return &v }
