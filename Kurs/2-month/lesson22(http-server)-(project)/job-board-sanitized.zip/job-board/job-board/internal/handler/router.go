package handler

import (
	"log/slog"
	"net/http"
	"time"

	"github.com/rabboni171/job-board/internal/handler/middleware"
	v1 "github.com/rabboni171/job-board/internal/handler/v1"
	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/service"
)

type Services struct {
	Tokens    service.TokenAuthenticator
	Auth      service.AccountService
	Sessions  service.SessionManager
	Employer  service.EmployerService
	Applicant service.ApplicantService
}

func NewRouter(log *slog.Logger, svc Services, requestTimeout time.Duration, corsOrigins []string, checks ...HealthCheck) http.Handler {
	authH := v1.NewAuthHandler(svc.Auth, svc.Sessions)
	empH := v1.NewEmployerHandler(svc.Employer)
	appH := v1.NewApplicantHandler(svc.Applicant)

	authed := middleware.Auth(svc.Tokens)
	employerOnly := middleware.RequireRole(model.RoleEmployer)
	applicantOnly := middleware.RequireRole(model.RoleApplicant)

	anyUser := func(h http.HandlerFunc) http.Handler { return middleware.Chain(h, authed) }
	asEmployer := func(h http.HandlerFunc) http.Handler { return middleware.Chain(h, authed, employerOnly) }
	asApplicant := func(h http.HandlerFunc) http.Handler { return middleware.Chain(h, authed, applicantOnly) }

	mux := http.NewServeMux()

	mux.HandleFunc("GET /health", healthHandler(checks))
	registerDocs(mux)

	mux.HandleFunc("POST /api/v1/sign-up", authH.SignUp)
	mux.HandleFunc("POST /api/v1/login", authH.Login)
	mux.HandleFunc("POST /api/v1/refresh", authH.Refresh)
	mux.HandleFunc("POST /api/v1/logout", authH.Logout)

	mux.Handle("GET /api/v1/vacancies", anyUser(appH.SearchVacancies))
	mux.Handle("GET /api/v1/vacancies/{id}", anyUser(appH.GetVacancy))

	mux.Handle("POST /api/v1/employer/vacancies", asEmployer(empH.CreateVacancy))
	mux.Handle("GET /api/v1/employer/vacancies", asEmployer(empH.ListMyVacancies))
	mux.Handle("PUT /api/v1/employer/vacancies/{id}", asEmployer(empH.UpdateVacancy))
	mux.Handle("POST /api/v1/employer/vacancies/{id}/close", asEmployer(empH.CloseVacancy))
	mux.Handle("DELETE /api/v1/employer/vacancies/{id}", asEmployer(empH.DeleteVacancy))
	mux.Handle("GET /api/v1/employer/vacancies/{id}/applications", asEmployer(empH.ListApplications))
	mux.Handle("PATCH /api/v1/employer/applications/{id}/status", asEmployer(empH.ChangeApplicationStatus))

	mux.Handle("PUT /api/v1/applicant/resume", asApplicant(appH.SaveResume))
	mux.Handle("GET /api/v1/applicant/resume", asApplicant(appH.GetResume))
	mux.Handle("DELETE /api/v1/applicant/resume", asApplicant(appH.DeleteResume))
	mux.Handle("POST /api/v1/applicant/applications", asApplicant(appH.Apply))
	mux.Handle("GET /api/v1/applicant/applications", asApplicant(appH.ListMyApplications))
	mux.Handle("DELETE /api/v1/applicant/applications/{id}", asApplicant(appH.Withdraw))

	// Порядок — снаружи внутрь (описан в README, «Жизненный цикл запроса»):
	// request id — первым, чтобы попасть во все строки лога, включая панику;
	// CORS — внутри Logging, чтобы preflight попадал в лог, а заголовки — и в ответы с ошибкой;
	// таймаут — ближе всех к обработчику.
	return middleware.Chain(mux,
		middleware.RequestID,
		middleware.Recover(log),
		middleware.Logging(log),
		middleware.CORS(corsOrigins),
		middleware.Timeout(requestTimeout),
	)
}
