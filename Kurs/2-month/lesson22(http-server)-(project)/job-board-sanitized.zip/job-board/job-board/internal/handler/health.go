package handler

import (
	"context"
	"net/http"
	"time"

	"github.com/rabboni171/job-board/internal/handler/httpx"
)

const healthTimeout = 2 * time.Second

type HealthCheck struct {
	Name string
	Ping func(ctx context.Context) error
}

func healthHandler(checks []HealthCheck) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		for _, c := range checks {
			if err := ping(r.Context(), c); err != nil {
				httpx.WriteError(w, r, http.StatusServiceUnavailable, c.Name+" unavailable", err)
				return
			}
		}
		httpx.WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	}
}

func ping(ctx context.Context, c HealthCheck) error {
	ctx, cancel := context.WithTimeout(ctx, healthTimeout)
	defer cancel()
	return c.Ping(ctx)
}
