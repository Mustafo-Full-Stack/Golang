package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) ListMyVacancies(ctx context.Context, employerID int64, p model.Page) (*model.Paged[model.Vacancy], error) {
	vacancies, err := s.vacancies.ListByEmployer(ctx, employerID, p)
	if err != nil {
		return nil, fmt.Errorf("list vacancies: %w", err)
	}
	return vacancies, nil
}
