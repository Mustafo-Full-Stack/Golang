package employer_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_ChangeApplicationStatus(t *testing.T) {
	const applicationID = int64(5)
	application := func(status model.ApplicationStatus) *model.Application {
		return &model.Application{ID: applicationID, VacancyID: vacancyID, Status: status}
	}
	// owned: отклик в статусе from на вакансию ownerID найден при чтении.
	owned := func(d deps, from model.ApplicationStatus) {
		d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(application(from), nil)
		d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(vacancy(model.VacancyOpen), nil)
	}
	// withStatus: в репозиторий уходит отклик с новым статусом.
	withStatus := func(to model.ApplicationStatus) any {
		return mock.MatchedBy(func(a *model.Application) bool { return a.ID == applicationID && a.Status == to })
	}

	tests := []struct {
		name       string
		employerID int64
		to         model.ApplicationStatus
		setup      func(d deps) // nil — в базу не ходим
		wantErr    error
	}{
		{
			name: "new -> viewed", employerID: ownerID, to: model.ApplicationViewed,
			setup: func(d deps) {
				owned(d, model.ApplicationNew)
				d.apps.EXPECT().UpdateStatus(mock.Anything, withStatus(model.ApplicationViewed)).Return(nil)
			},
		},
		{
			name: "new -> invited", employerID: ownerID, to: model.ApplicationInvited,
			setup: func(d deps) {
				owned(d, model.ApplicationNew)
				d.apps.EXPECT().UpdateStatus(mock.Anything, withStatus(model.ApplicationInvited)).Return(nil)
			},
		},
		{
			name: "viewed -> rejected", employerID: ownerID, to: model.ApplicationRejected,
			setup: func(d deps) {
				owned(d, model.ApplicationViewed)
				d.apps.EXPECT().UpdateStatus(mock.Anything, withStatus(model.ApplicationRejected)).Return(nil)
			},
		},
		{name: "same status is idempotent", employerID: ownerID, to: model.ApplicationInvited, setup: func(d deps) { owned(d, model.ApplicationInvited) }},
		{name: "rejected -> invited is forbidden", employerID: ownerID, to: model.ApplicationInvited, setup: func(d deps) { owned(d, model.ApplicationRejected) }, wantErr: model.ErrConflict},
		{name: "invited -> viewed is forbidden", employerID: ownerID, to: model.ApplicationViewed, setup: func(d deps) { owned(d, model.ApplicationInvited) }, wantErr: model.ErrConflict},
		{name: "back to new is forbidden", employerID: ownerID, to: model.ApplicationNew, setup: func(d deps) { owned(d, model.ApplicationViewed) }, wantErr: model.ErrConflict},
		{name: "unknown status is rejected before db", employerID: ownerID, to: "weird", wantErr: model.ErrInvalidInput},
		{
			name: "application of a foreign vacancy looks like missing", employerID: otherID, to: model.ApplicationInvited,
			setup:   func(d deps) { owned(d, model.ApplicationNew) },
			wantErr: model.ErrNotFound,
		},
		{
			name: "application not found", employerID: ownerID, to: model.ApplicationInvited,
			setup: func(d deps) {
				d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(nil, model.NotFound("application"))
			},
			wantErr: model.ErrNotFound,
		},
		{
			name: "application changed concurrently: conflict propagates", employerID: ownerID, to: model.ApplicationInvited,
			setup: func(d deps) {
				owned(d, model.ApplicationNew)
				d.apps.EXPECT().UpdateStatus(mock.Anything, withStatus(model.ApplicationInvited)).Return(model.Conflict("application was changed, try again"))
			},
			wantErr: model.ErrConflict,
		},
		{
			name: "read failure", employerID: ownerID, to: model.ApplicationInvited,
			setup: func(d deps) {
				d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(nil, errDB)
			},
			wantErr: errDB,
		},
		{
			name: "vacancy read failure", employerID: ownerID, to: model.ApplicationInvited,
			setup: func(d deps) {
				d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(application(model.ApplicationNew), nil)
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(nil, errDB)
			},
			wantErr: errDB,
		},
		{
			name: "write failure", employerID: ownerID, to: model.ApplicationInvited,
			setup: func(d deps) {
				owned(d, model.ApplicationNew)
				d.apps.EXPECT().UpdateStatus(mock.Anything, withStatus(model.ApplicationInvited)).Return(errDB)
			},
			wantErr: errDB,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			if tt.setup != nil {
				tt.setup(d)
			}

			err := d.svc().ChangeApplicationStatus(context.Background(), tt.employerID, applicationID, tt.to)

			requireErr(t, err, tt.wantErr)
		})
	}
}
