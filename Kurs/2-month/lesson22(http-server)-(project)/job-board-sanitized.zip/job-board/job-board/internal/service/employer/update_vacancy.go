package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) UpdateVacancy(ctx context.Context, employerID, vacancyID int64, in model.VacancyInput) (*model.Vacancy, error) {
	v, err := s.ownedVacancy(ctx, employerID, vacancyID)
	if err != nil {
		return nil, err
	}
	if err := v.Edit(in); err != nil {
		return nil, err
	}
	if err := s.vacancies.Update(ctx, v); err != nil {
		return nil, fmt.Errorf("update vacancy: %w", err)
	}
	return v, nil
}
