package auth_test

import (
	"context"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
)

func TestService_Authenticate(t *testing.T) {
	pair, saved := loginPair(t, testUser(t), "12345678")
	sid := saved.ID

	// sign подписывает access-токен с корректными claims, которые случай может испортить.
	sign := func(method jwt.SigningMethod, key any, mutate func(jwt.MapClaims)) string {
		claims := jwt.MapClaims{"sub": "42", "jti": sid, "typ": "access", "role": "employer", "exp": time.Now().Add(time.Hour).Unix()}
		mutate(claims)
		token, err := jwt.NewWithClaims(method, claims).SignedString(key)
		require.NoError(t, err)
		return token
	}
	hs256 := func(mutate func(jwt.MapClaims)) string { return sign(jwt.SigningMethodHS256, []byte(secret), mutate) }
	keep := func(jwt.MapClaims) {}

	tests := []struct {
		name      string
		token     string
		setup     func(sessions *mocks.SessionRepository) // nil — до хранилища дело не доходит
		want      *model.Claims
		wantErr   error
		wantCause error // ошибка jwt остаётся в цепочке, а клиенту уходит общий текст
	}{
		{
			name:  "ok",
			token: pair.AccessToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(saved, nil)
			},
			want: &model.Claims{UserID: 42, Role: model.RoleEmployer, SessionID: sid},
		},
		{name: "refresh token is not accepted as access", token: pair.RefreshToken, wantErr: model.ErrUnauthorized},
		{name: "signed with another secret", token: sign(jwt.SigningMethodHS256, []byte("another-secret"), keep), wantErr: model.ErrUnauthorized, wantCause: jwt.ErrTokenSignatureInvalid},
		{name: "alg none", token: sign(jwt.SigningMethodNone, jwt.UnsafeAllowNoneSignatureType, keep), wantErr: model.ErrUnauthorized},
		{name: "expired", token: hs256(func(c jwt.MapClaims) { c["exp"] = time.Now().Add(-time.Hour).Unix() }), wantErr: model.ErrUnauthorized, wantCause: jwt.ErrTokenExpired},
		{name: "no exp", token: hs256(func(c jwt.MapClaims) { delete(c, "exp") }), wantErr: model.ErrUnauthorized},
		{name: "no typ", token: hs256(func(c jwt.MapClaims) { delete(c, "typ") }), wantErr: model.ErrUnauthorized},
		{name: "typ refresh", token: hs256(func(c jwt.MapClaims) { c["typ"] = "refresh" }), wantErr: model.ErrUnauthorized},
		{name: "subject is not a number", token: hs256(func(c jwt.MapClaims) { c["sub"] = "abc" }), wantErr: model.ErrUnauthorized},
		{name: "no session id", token: hs256(func(c jwt.MapClaims) { delete(c, "jti") }), wantErr: model.ErrUnauthorized},
		{name: "garbage", token: "not-a-token", wantErr: model.ErrUnauthorized},
		{name: "empty", token: "", wantErr: model.ErrUnauthorized},
		{
			name:  "session revoked",
			token: pair.AccessToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(nil, model.NotFound("session"))
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name:  "session of another user",
			token: pair.AccessToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(&model.Session{ID: sid, UserID: 43}, nil)
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name:  "store failure is not 401",
			token: pair.AccessToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(nil, errStore)
			},
			wantErr: errStore,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sessions := mocks.NewSessionRepository(t)
			if tt.setup != nil {
				tt.setup(sessions)
			}

			got, err := newService(mocks.NewUserRepository(t), sessions).Authenticate(context.Background(), tt.token)

			requireErr(t, err, tt.wantErr)
			if tt.wantCause != nil {
				require.ErrorIs(t, err, tt.wantCause)
				var e *model.Error
				require.ErrorAs(t, err, &e)
				require.Equal(t, "unauthorized: invalid token", e.Msg)
			}
			if tt.wantErr == nil {
				require.Equal(t, tt.want, got)
			}
		})
	}
}
