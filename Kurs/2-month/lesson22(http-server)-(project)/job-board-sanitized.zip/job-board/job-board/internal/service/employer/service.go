package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository"
)

type service struct {
	vacancies    repository.VacancyRepository
	applications repository.ApplicationRepository
}

func NewService(vacancies repository.VacancyRepository, applications repository.ApplicationRepository) *service {
	return &service{vacancies: vacancies, applications: applications}
}

func (s *service) ownedVacancy(ctx context.Context, employerID, vacancyID int64) (*model.Vacancy, error) {
	v, err := s.vacancies.GetByID(ctx, vacancyID)
	if err != nil {
		return nil, fmt.Errorf("get vacancy: %w", err)
	}
	if v.EmployerID != employerID {
		// Не раскрываем существование чужих вакансий.
		return nil, model.NotFound("vacancy")
	}
	return v, nil
}
