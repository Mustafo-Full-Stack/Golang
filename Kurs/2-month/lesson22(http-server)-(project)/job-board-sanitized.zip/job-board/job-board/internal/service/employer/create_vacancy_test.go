package employer_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_CreateVacancy(t *testing.T) {
	tests := []struct {
		name      string
		mutate    func(*model.VacancyInput)
		wantSaved *model.Vacancy // что уходит в репозиторий; nil — в базу не ходим
		createErr error
		wantErr   error
	}{
		{
			name:   "ok: open vacancy of the caller",
			mutate: func(*model.VacancyInput) {},
			wantSaved: &model.Vacancy{EmployerID: ownerID, Status: model.VacancyOpen, Title: "Go dev", Description: "d", City: "Almaty",
				EmploymentType: model.EmploymentFull, Tags: []string{}},
		},
		{
			name:   "tags are normalized before saving",
			mutate: func(in *model.VacancyInput) { in.Tags = []string{"Go", " go ", "Postgres"} },
			wantSaved: &model.Vacancy{EmployerID: ownerID, Status: model.VacancyOpen, Title: "Go dev", Description: "d", City: "Almaty",
				EmploymentType: model.EmploymentFull, Tags: []string{"go", "postgres"}},
		},
		{
			name:   "store failure",
			mutate: func(*model.VacancyInput) {},
			wantSaved: &model.Vacancy{EmployerID: ownerID, Status: model.VacancyOpen, Title: "Go dev", Description: "d", City: "Almaty",
				EmploymentType: model.EmploymentFull, Tags: []string{}},
			createErr: errDB,
			wantErr:   errDB,
		},
		{name: "salary_from > salary_to", mutate: func(in *model.VacancyInput) { in.SalaryFrom, in.SalaryTo = intPtr(200), intPtr(100) }, wantErr: model.ErrInvalidInput},
		{name: "negative salary_from", mutate: func(in *model.VacancyInput) { in.SalaryFrom = intPtr(-1) }, wantErr: model.ErrInvalidInput},
		{name: "negative salary_to", mutate: func(in *model.VacancyInput) { in.SalaryTo = intPtr(-1) }, wantErr: model.ErrInvalidInput},
		{name: "salary_to over limit", mutate: func(in *model.VacancyInput) { in.SalaryTo = intPtr(model.MaxSalary + 1) }, wantErr: model.ErrInvalidInput},
		{name: "unknown employment_type", mutate: func(in *model.VacancyInput) { in.EmploymentType = "weird" }, wantErr: model.ErrInvalidInput},
		{name: "too many tags", mutate: func(in *model.VacancyInput) {
			in.Tags = []string{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"}
		}, wantErr: model.ErrInvalidInput},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			if tt.wantSaved != nil {
				d.vacancies.EXPECT().Create(mock.Anything, tt.wantSaved).Return(tt.createErr)
			}
			in := validInput()
			tt.mutate(&in)

			got, err := d.svc().CreateVacancy(context.Background(), ownerID, in)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, tt.wantSaved, got)
			}
		})
	}
}
