package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) DeleteVacancy(ctx context.Context, employerID, vacancyID int64) error {
	if _, err := s.ownedVacancy(ctx, employerID, vacancyID); err != nil {
		return err
	}
	// Отклики соискателей не должны пропадать вместе с вакансией: её можно только закрыть.
	hasApplications, err := s.applications.ExistsByVacancy(ctx, vacancyID)
	if err != nil {
		return fmt.Errorf("check applications: %w", err)
	}
	if hasApplications {
		return model.Conflict("vacancy has applications")
	}
	if err := s.vacancies.Delete(ctx, vacancyID); err != nil {
		return fmt.Errorf("delete vacancy: %w", err)
	}
	return nil
}
