package applicant_test

import (
	"errors"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
	"github.com/rabboni171/job-board/internal/service"
	"github.com/rabboni171/job-board/internal/service/applicant"
)

const (
	applicantID = int64(7)
	ownerID     = int64(1)
	vacancyID   = int64(10)
)

var errDB = errors.New("db is down")

type deps struct {
	vacancies *mocks.VacancyReader
	resumes   *mocks.ResumeRepository
	apps      *mocks.ApplicationRepository
	views     *mocks.ViewCounter
}

// newDeps создаёт строгие моки: любой неожиданный вызов репозитория валит тест.
func newDeps(t *testing.T) deps {
	return deps{
		vacancies: mocks.NewVacancyReader(t),
		resumes:   mocks.NewResumeRepository(t),
		apps:      mocks.NewApplicationRepository(t),
		views:     mocks.NewViewCounter(t),
	}
}

func (d deps) svc() service.ApplicantService {
	return applicant.NewService(d.vacancies, d.resumes, d.apps, d.views)
}

// requireErr: при want == nil ошибки нет, иначе err содержит want.
// Сбой хранилища не должен выглядеть как клиентская ошибка: клиент получил бы 404/409/422 вместо 500.
func requireErr(t *testing.T, err, want error) {
	t.Helper()
	if want == nil {
		require.NoError(t, err)
		return
	}
	require.ErrorIs(t, err, want)
	if errors.Is(want, errDB) {
		for _, clientErr := range []error{model.ErrNotFound, model.ErrConflict, model.ErrInvalidInput, model.ErrUnauthorized} {
			require.NotErrorIs(t, err, clientErr)
		}
	}
}
