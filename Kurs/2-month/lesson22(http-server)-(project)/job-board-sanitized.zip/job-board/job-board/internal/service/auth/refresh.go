package auth

import (
	"context"
	"errors"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) Refresh(ctx context.Context, refreshToken string) (*model.TokenPair, error) {
	c, err := s.parse(refreshToken, typeRefresh)
	if err != nil {
		return nil, errInvalidRefresh
	}
	if err := s.checkSession(ctx, c); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil, errInvalidRefresh
		}
		return nil, err
	}
	// Роль берём из БД, а не из старого токена.
	u, err := s.users.GetByID(ctx, c.UserID)
	if err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil, errInvalidRefresh
		}
		return nil, fmt.Errorf("get user: %w", err)
	}
	// Сессию расходуем после всех проверок, чтобы сбой не стоил пользователю сессии. GETDEL
	// атомарен: из двух параллельных refresh одним токеном пройдёт один, старые токены умирают сразу.
	if err := s.sessions.Take(ctx, c.SessionID); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil, errInvalidRefresh
		}
		return nil, fmt.Errorf("take session: %w", err)
	}
	pair, err := s.newSession(ctx, u)
	if err != nil {
		return nil, fmt.Errorf("create session: %w", err)
	}
	return pair, nil
}
