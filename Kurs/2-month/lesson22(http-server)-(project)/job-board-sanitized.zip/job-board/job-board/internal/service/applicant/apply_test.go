package applicant_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_Apply(t *testing.T) {
	open := model.Vacancy{ID: vacancyID, Status: model.VacancyOpen}
	closed := model.Vacancy{ID: vacancyID, Status: model.VacancyClosed}
	want := model.Application{VacancyID: vacancyID, ApplicantID: applicantID, CoverLetter: "hi", Status: model.ApplicationNew}
	newApplication := mock.MatchedBy(func(a *model.Application) bool { return *a == want })

	// withResume: вакансия открыта и резюме есть, дальше дело за созданием отклика.
	withResume := func(d deps) {
		d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(&open, nil)
		d.resumes.EXPECT().GetByApplicant(mock.Anything, applicantID).Return(&model.Resume{ApplicantID: applicantID}, nil)
	}

	tests := []struct {
		name    string
		setup   func(d deps)
		wantErr error
		wantMsg string // текст клиентской ошибки; пусто — не проверяем
	}{
		{
			name: "ok: application is created in status new",
			setup: func(d deps) {
				withResume(d)
				d.apps.EXPECT().Create(mock.Anything, newApplication).Return(nil)
			},
		},
		{
			name: "vacancy not found",
			setup: func(d deps) {
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(nil, model.NotFound("vacancy"))
			},
			wantErr: model.ErrNotFound,
		},
		{
			name: "closed vacancy is invisible to applicant",
			setup: func(d deps) {
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(&closed, nil)
			},
			wantErr: model.ErrNotFound,
		},
		{
			name: "resume is required",
			setup: func(d deps) {
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(&open, nil)
				d.resumes.EXPECT().GetByApplicant(mock.Anything, applicantID).Return(nil, model.NotFound("resume"))
			},
			wantErr: model.ErrConflict,
			wantMsg: "conflict: resume is required to apply",
		},
		{
			name: "duplicate application",
			setup: func(d deps) {
				withResume(d)
				d.apps.EXPECT().Create(mock.Anything, newApplication).Return(model.Conflict("already applied to this vacancy"))
			},
			wantErr: model.ErrConflict,
			wantMsg: "conflict: already applied to this vacancy",
		},
		{
			name: "vacancy closed between read and insert",
			setup: func(d deps) {
				withResume(d)
				d.apps.EXPECT().Create(mock.Anything, newApplication).Return(model.NotFound("vacancy"))
			},
			wantErr: model.ErrNotFound,
		},
		{
			name: "vacancy store failure",
			setup: func(d deps) {
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(nil, errDB)
			},
			wantErr: errDB,
		},
		{
			name: "resume store failure is not «resume is required»",
			setup: func(d deps) {
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(&open, nil)
				d.resumes.EXPECT().GetByApplicant(mock.Anything, applicantID).Return(nil, errDB)
			},
			wantErr: errDB,
		},
		{
			name: "application store failure",
			setup: func(d deps) {
				withResume(d)
				d.apps.EXPECT().Create(mock.Anything, newApplication).Return(errDB)
			},
			wantErr: errDB,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			tt.setup(d)

			got, err := d.svc().Apply(context.Background(), applicantID, model.ApplyInput{VacancyID: vacancyID, CoverLetter: "hi"})

			requireErr(t, err, tt.wantErr)
			if tt.wantMsg != "" {
				var e *model.Error
				require.ErrorAs(t, err, &e)
				require.Equal(t, tt.wantMsg, e.Msg)
			}
			if tt.wantErr == nil {
				require.Equal(t, &want, got)
			}
		})
	}
}
