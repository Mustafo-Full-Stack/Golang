package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) CloseVacancy(ctx context.Context, employerID, vacancyID int64) error {
	v, err := s.ownedVacancy(ctx, employerID, vacancyID)
	if err != nil {
		return err
	}
	if v.Status == model.VacancyClosed {
		return model.Conflict("vacancy already closed")
	}
	v.Status = model.VacancyClosed
	if err := s.vacancies.UpdateStatus(ctx, v); err != nil {
		return fmt.Errorf("close vacancy: %w", err)
	}
	return nil
}
