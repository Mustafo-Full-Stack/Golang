package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) ListApplications(ctx context.Context, employerID, vacancyID int64, status model.ApplicationStatus, p model.Page) (*model.Paged[model.ApplicationWithResume], error) {
	if status != "" && !status.Valid() {
		return nil, model.InvalidInput("unknown status %q", status)
	}
	if _, err := s.ownedVacancy(ctx, employerID, vacancyID); err != nil {
		return nil, err
	}
	applications, err := s.applications.ListByVacancy(ctx, vacancyID, status, p)
	if err != nil {
		return nil, fmt.Errorf("list applications: %w", err)
	}
	return applications, nil
}
