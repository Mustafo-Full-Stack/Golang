package applicant_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_Withdraw(t *testing.T) {
	const applicationID = int64(5)
	application := func(status model.ApplicationStatus) *model.Application {
		return &model.Application{ID: applicationID, ApplicantID: applicantID, Status: status}
	}
	// found: отклик соискателя в нужном статусе находится при первом чтении.
	found := func(d deps, status model.ApplicationStatus) {
		d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(application(status), nil).Once()
	}

	tests := []struct {
		name    string
		setup   func(d deps)
		wantErr error
	}{
		{
			name: "new application is withdrawn",
			setup: func(d deps) {
				found(d, model.ApplicationNew)
				d.apps.EXPECT().Delete(mock.Anything, application(model.ApplicationNew)).Return(nil)
			},
		},
		{name: "viewed cannot be withdrawn", setup: func(d deps) { found(d, model.ApplicationViewed) }, wantErr: model.ErrConflict},
		{name: "invited cannot be withdrawn", setup: func(d deps) { found(d, model.ApplicationInvited) }, wantErr: model.ErrConflict},
		{name: "rejected cannot be withdrawn", setup: func(d deps) { found(d, model.ApplicationRejected) }, wantErr: model.ErrConflict},
		{
			name: "foreign application looks like missing",
			setup: func(d deps) {
				other := application(model.ApplicationNew)
				other.ApplicantID = applicantID + 1
				d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(other, nil)
			},
			wantErr: model.ErrNotFound,
		},
		{
			name: "not found",
			setup: func(d deps) {
				d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(nil, model.NotFound("application"))
			},
			wantErr: model.ErrNotFound,
		},
		{
			name: "application changed concurrently: conflict propagates without re-read",
			setup: func(d deps) {
				found(d, model.ApplicationNew)
				d.apps.EXPECT().Delete(mock.Anything, application(model.ApplicationNew)).Return(model.Conflict("application was changed, try again"))
			},
			wantErr: model.ErrConflict,
		},
		{
			name: "read failure",
			setup: func(d deps) {
				d.apps.EXPECT().GetByID(mock.Anything, applicationID).Return(nil, errDB)
			},
			wantErr: errDB,
		},
		{
			name: "delete failure",
			setup: func(d deps) {
				found(d, model.ApplicationNew)
				d.apps.EXPECT().Delete(mock.Anything, application(model.ApplicationNew)).Return(errDB)
			},
			wantErr: errDB,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			tt.setup(d)

			err := d.svc().Withdraw(context.Background(), applicantID, applicationID)

			requireErr(t, err, tt.wantErr)
		})
	}
}
