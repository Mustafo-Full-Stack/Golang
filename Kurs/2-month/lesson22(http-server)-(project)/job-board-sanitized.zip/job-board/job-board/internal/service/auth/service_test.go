package auth_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/bcrypt"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
	"github.com/rabboni171/job-board/internal/service/auth"
)

const secret = "test-secret"

const (
	accessTTL  = 15 * time.Minute
	refreshTTL = 720 * time.Hour
)

var errStore = errors.New("store is down")

func newService(users *mocks.UserRepository, sessions *mocks.SessionRepository) interface {
	Login(ctx context.Context, in model.LoginInput) (*model.TokenPair, error)
	Refresh(ctx context.Context, refreshToken string) (*model.TokenPair, error)
	Logout(ctx context.Context, refreshToken string) error
	Authenticate(ctx context.Context, token string) (*model.Claims, error)
} {
	return auth.NewService(users, sessions, secret, accessTTL, refreshTTL)
}

// loginPair логинит пользователя и возвращает пару и сессию, сохранённую в мок-репозитории.
func loginPair(t *testing.T, u *model.User, password string) (*model.TokenPair, *model.Session) {
	t.Helper()
	users := mocks.NewUserRepository(t)
	users.EXPECT().GetByEmail(mock.Anything, u.Email).Return(u, nil)
	sessions := mocks.NewSessionRepository(t)
	var saved *model.Session
	sessions.EXPECT().Create(mock.Anything, mock.Anything, refreshTTL).
		Run(func(_ context.Context, s *model.Session, _ time.Duration) { saved = s }).Return(nil)

	pair, err := newService(users, sessions).Login(context.Background(), model.LoginInput{Email: u.Email, Password: password})
	require.NoError(t, err)
	return pair, saved
}

func testUser(t *testing.T) *model.User {
	t.Helper()
	hash, err := bcrypt.GenerateFromPassword([]byte("12345678"), bcrypt.MinCost)
	require.NoError(t, err)
	return &model.User{ID: 42, Email: "a@b.c", PasswordHash: string(hash), Role: model.RoleEmployer}
}

// tokenClaims разбирает выпущенный сервисом токен, чтобы проверить его содержимое.
func tokenClaims(t *testing.T, token string) jwt.MapClaims {
	t.Helper()
	claims := jwt.MapClaims{}
	_, err := jwt.ParseWithClaims(token, claims, func(*jwt.Token) (any, error) { return []byte(secret), nil })
	require.NoError(t, err)
	return claims
}

// requireErr: при want == nil ошибки быть не должно. Иначе err содержит want,
// а сбой хранилища не маскируется под 401 (клиент получил бы «неверный токен» вместо 500).
func requireErr(t *testing.T, err, want error) {
	t.Helper()
	if want == nil {
		require.NoError(t, err)
		return
	}
	require.ErrorIs(t, err, want)
	if !errors.Is(want, model.ErrUnauthorized) {
		require.NotErrorIs(t, err, model.ErrUnauthorized)
	}
}
