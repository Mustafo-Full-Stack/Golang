package applicant

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) ListMyApplications(ctx context.Context, applicantID int64, p model.Page) (*model.Paged[model.ApplicationWithVacancy], error) {
	applications, err := s.applications.ListByApplicant(ctx, applicantID, p)
	if err != nil {
		return nil, fmt.Errorf("list applications: %w", err)
	}
	return applications, nil
}
