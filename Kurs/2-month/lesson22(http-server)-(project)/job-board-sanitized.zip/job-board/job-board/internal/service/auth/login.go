package auth

import (
	"context"
	"errors"
	"fmt"

	"golang.org/x/crypto/bcrypt"

	"github.com/rabboni171/job-board/internal/model"
)

// Одна ошибка и одно время ответа для неизвестного email и неверного пароля.
var errInvalidCredentials = model.Unauthorized("invalid email or password")

// Хеш считается один раз при старте: bcrypt для несуществующего email нужен только ради времени ответа.
var dummyHash = func() []byte {
	h, err := bcrypt.GenerateFromPassword([]byte("dummy-password"), bcrypt.DefaultCost)
	if err != nil {
		panic(fmt.Sprintf("auth: dummy bcrypt hash: %v", err))
	}
	return h
}()

func (s *service) Login(ctx context.Context, in model.LoginInput) (*model.TokenPair, error) {
	u, err := s.users.GetByEmail(ctx, model.NormalizeEmail(in.Email))
	if err != nil {
		if errors.Is(err, model.ErrNotFound) {
			// Время ответа не должно выдавать, зарегистрирован ли email.
			_ = bcrypt.CompareHashAndPassword(dummyHash, []byte(in.Password))
			return nil, errInvalidCredentials
		}
		return nil, fmt.Errorf("get user: %w", err)
	}
	if err := bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(in.Password)); err != nil {
		return nil, errInvalidCredentials
	}
	pair, err := s.newSession(ctx, u)
	if err != nil {
		return nil, fmt.Errorf("create session: %w", err)
	}
	return pair, nil
}
