package applicant

import (
	"github.com/rabboni171/job-board/internal/repository"
)

type service struct {
	vacancies    repository.VacancyReader
	resumes      repository.ResumeRepository
	applications repository.ApplicationRepository
	views        repository.ViewCounter
}

func NewService(
	vacancies repository.VacancyReader,
	resumes repository.ResumeRepository,
	applications repository.ApplicationRepository,
	views repository.ViewCounter,
) *service {
	return &service{
		vacancies:    vacancies,
		resumes:      resumes,
		applications: applications,
		views:        views,
	}
}
