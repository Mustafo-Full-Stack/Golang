package employer

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) CreateVacancy(ctx context.Context, employerID int64, in model.VacancyInput) (*model.Vacancy, error) {
	v, err := model.NewVacancy(employerID, in)
	if err != nil {
		return nil, err
	}
	if err := s.vacancies.Create(ctx, v); err != nil {
		return nil, fmt.Errorf("create vacancy: %w", err)
	}
	return v, nil
}
