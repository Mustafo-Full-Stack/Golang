package applicant

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) GetVacancy(ctx context.Context, vacancyID, viewerID int64) (*model.VacancyView, error) {
	v, err := s.vacancies.GetByID(ctx, vacancyID)
	if err != nil {
		return nil, fmt.Errorf("get vacancy: %w", err)
	}
	isOwner := v.EmployerID == viewerID
	// Закрытая вакансия видна только владельцу.
	if v.Status == model.VacancyClosed && !isOwner {
		return nil, model.NotFound("vacancy")
	}
	// Владелец видит число просмотров, но своими заходами его не накручивает.
	if isOwner {
		return &model.VacancyView{Vacancy: *v, Views: s.views.Count(ctx, vacancyID)}, nil
	}
	return &model.VacancyView{Vacancy: *v, Views: s.views.Hit(ctx, vacancyID, viewerID)}, nil
}
