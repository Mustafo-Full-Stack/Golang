package employer_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_UpdateVacancy(t *testing.T) {
	in := validInput()
	in.Title = " New title "
	updated := vacancy(model.VacancyOpen)
	updated.Title, updated.Description, updated.City, updated.Tags = "New title", "d", "Almaty", []string{}

	tests := []struct {
		name       string
		employerID int64
		in         model.VacancyInput
		stored     *model.Vacancy
		getErr     error
		updates    bool
		updateErr  error
		wantErr    error
	}{
		{name: "ok: owner edits open vacancy", employerID: ownerID, in: in, stored: vacancy(model.VacancyOpen), updates: true},
		{name: "closed vacancy is not editable", employerID: ownerID, in: in, stored: vacancy(model.VacancyClosed), wantErr: model.ErrConflict},
		{name: "foreign vacancy looks like missing", employerID: otherID, in: in, stored: vacancy(model.VacancyOpen), wantErr: model.ErrNotFound},
		{name: "not found", employerID: ownerID, in: in, getErr: model.NotFound("vacancy"), wantErr: model.ErrNotFound},
		{name: "invalid input", employerID: ownerID, in: model.VacancyInput{EmploymentType: "weird"}, stored: vacancy(model.VacancyOpen), wantErr: model.ErrInvalidInput},
		{name: "closed between read and write", employerID: ownerID, in: in, stored: vacancy(model.VacancyOpen), updates: true, updateErr: model.Conflict("vacancy was changed, try again"), wantErr: model.ErrConflict},
		{name: "read failure", employerID: ownerID, in: in, getErr: errDB, wantErr: errDB},
		{name: "write failure", employerID: ownerID, in: in, stored: vacancy(model.VacancyOpen), updates: true, updateErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(tt.stored, tt.getErr)
			if tt.updates {
				d.vacancies.EXPECT().Update(mock.Anything, updated).Return(tt.updateErr)
			}

			got, err := d.svc().UpdateVacancy(context.Background(), tt.employerID, vacancyID, tt.in)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, updated, got)
			}
		})
	}
}
