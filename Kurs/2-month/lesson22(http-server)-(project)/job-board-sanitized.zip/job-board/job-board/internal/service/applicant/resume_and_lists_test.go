package applicant_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

// Методы ниже только читают или удаляют данные соискателя. Проверяем, что берутся данные
// именно вызывающего, а «не найдено» доходит до хендлера как ErrNotFound (404).

func TestService_GetResume(t *testing.T) {
	resume := &model.Resume{ApplicantID: applicantID, Title: "Go dev"}
	tests := []struct {
		name    string
		repoErr error
		wantErr error
	}{
		{name: "ok"},
		{name: "no resume", repoErr: model.NotFound("resume"), wantErr: model.ErrNotFound},
		{name: "store failure", repoErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.resumes.EXPECT().GetByApplicant(mock.Anything, applicantID).Return(resume, tt.repoErr)

			got, err := d.svc().GetResume(context.Background(), applicantID)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, resume, got)
			}
		})
	}
}

func TestService_DeleteResume(t *testing.T) {
	tests := []struct {
		name    string
		repoErr error
		wantErr error
	}{
		{name: "ok"},
		{name: "no resume", repoErr: model.NotFound("resume"), wantErr: model.ErrNotFound},
		{name: "store failure", repoErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.resumes.EXPECT().Delete(mock.Anything, applicantID).Return(tt.repoErr)

			err := d.svc().DeleteResume(context.Background(), applicantID)

			requireErr(t, err, tt.wantErr)
		})
	}
}

func TestService_ListMyApplications(t *testing.T) {
	page := model.Page{Limit: 20}
	list := &model.Paged[model.ApplicationWithVacancy]{
		Items: []model.ApplicationWithVacancy{{Application: model.Application{ID: 5, ApplicantID: applicantID}}},
		Total: 1,
	}
	tests := []struct {
		name    string
		repoErr error
		wantErr error
	}{
		{name: "ok"},
		{name: "store failure", repoErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.apps.EXPECT().ListByApplicant(mock.Anything, applicantID, page).Return(list, tt.repoErr)

			got, err := d.svc().ListMyApplications(context.Background(), applicantID, page)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, list, got)
			}
		})
	}
}
