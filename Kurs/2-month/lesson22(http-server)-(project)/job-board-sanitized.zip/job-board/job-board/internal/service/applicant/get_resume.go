package applicant

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) GetResume(ctx context.Context, applicantID int64) (*model.Resume, error) {
	resume, err := s.resumes.GetByApplicant(ctx, applicantID)
	if err != nil {
		return nil, fmt.Errorf("get resume: %w", err)
	}
	return resume, nil
}
