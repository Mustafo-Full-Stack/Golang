package employer_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_DeleteVacancy(t *testing.T) {
	tests := []struct {
		name       string
		employerID int64
		getErr     error
		checks     bool // проверяем, есть ли отклики
		exists     bool
		existsErr  error
		deletes    bool
		deleteErr  error
		wantErr    error
		wantMsg    string // текст клиентской ошибки; пусто — не проверяем
	}{
		{name: "ok: no applications", employerID: ownerID, checks: true, deletes: true},
		{
			name: "vacancy with applications cannot be deleted", employerID: ownerID, checks: true, exists: true,
			wantErr: model.ErrConflict, wantMsg: "conflict: vacancy has applications",
		},
		{name: "foreign vacancy looks like missing", employerID: otherID, wantErr: model.ErrNotFound},
		{name: "not found", employerID: ownerID, getErr: model.NotFound("vacancy"), wantErr: model.ErrNotFound},
		{name: "applications check failure", employerID: ownerID, checks: true, existsErr: errDB, wantErr: errDB},
		{name: "deleted concurrently", employerID: ownerID, checks: true, deletes: true, deleteErr: model.NotFound("vacancy"), wantErr: model.ErrNotFound},
		{name: "read failure", employerID: ownerID, getErr: errDB, wantErr: errDB},
		{name: "write failure", employerID: ownerID, checks: true, deletes: true, deleteErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(vacancy(model.VacancyOpen), tt.getErr)
			if tt.checks {
				d.apps.EXPECT().ExistsByVacancy(mock.Anything, vacancyID).Return(tt.exists, tt.existsErr)
			}
			if tt.deletes {
				d.vacancies.EXPECT().Delete(mock.Anything, vacancyID).Return(tt.deleteErr)
			}

			err := d.svc().DeleteVacancy(context.Background(), tt.employerID, vacancyID)

			requireErr(t, err, tt.wantErr)
			if tt.wantMsg != "" {
				var e *model.Error
				require.ErrorAs(t, err, &e)
				require.Equal(t, tt.wantMsg, e.Msg)
			}
		})
	}
}
