package applicant_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_SearchVacancies(t *testing.T) {
	neg, over := -1, model.MaxSalary+1
	page := model.Page{Limit: 20, Offset: 40}
	found := &model.Paged[model.Vacancy]{Items: []model.Vacancy{{ID: vacancyID}}, Total: 1}

	tests := []struct {
		name       string
		filter     model.VacancyFilter
		wantFilter *model.VacancyFilter // что уходит в репозиторий (всегда со Status=open); nil — в базу не ходим
		searchErr  error
		wantErr    error
	}{
		{
			name:       "ok",
			filter:     model.VacancyFilter{EmploymentType: model.EmploymentFull, Page: page},
			wantFilter: &model.VacancyFilter{Status: model.VacancyOpen, EmploymentType: model.EmploymentFull, Tags: []string{}, Page: page},
		},
		{
			name:       "trims query and city, normalizes tags",
			filter:     model.VacancyFilter{Query: " go ", City: " Almaty ", Tags: []string{"Go", " GO ", "SQL"}, Page: page},
			wantFilter: &model.VacancyFilter{Status: model.VacancyOpen, Query: "go", City: "Almaty", Tags: []string{"go", "sql"}, Page: page},
		},
		{
			name:       "caller cannot override status: only open vacancies are searched",
			filter:     model.VacancyFilter{Status: model.VacancyClosed},
			wantFilter: &model.VacancyFilter{Status: model.VacancyOpen, Tags: []string{}},
		},
		{
			name:       "duplicate tags do not count towards the limit",
			filter:     model.VacancyFilter{Tags: []string{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "10"}},
			wantFilter: &model.VacancyFilter{Status: model.VacancyOpen, Tags: []string{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}},
		},
		{name: "unknown employment_type", filter: model.VacancyFilter{EmploymentType: "weird"}, wantErr: model.ErrInvalidInput},
		{name: "negative salary_from", filter: model.VacancyFilter{SalaryFrom: &neg}, wantErr: model.ErrInvalidInput},
		{name: "salary_from over limit", filter: model.VacancyFilter{SalaryFrom: &over}, wantErr: model.ErrInvalidInput},
		{name: "too many tags", filter: model.VacancyFilter{Tags: []string{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"}}, wantErr: model.ErrInvalidInput},
		{
			name:       "store failure",
			filter:     model.VacancyFilter{},
			wantFilter: &model.VacancyFilter{Status: model.VacancyOpen, Tags: []string{}},
			searchErr:  errDB,
			wantErr:    errDB,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			if tt.wantFilter != nil {
				d.vacancies.EXPECT().Search(mock.Anything, *tt.wantFilter).Return(found, tt.searchErr)
			}

			got, err := d.svc().SearchVacancies(context.Background(), tt.filter)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, found, got)
			}
		})
	}
}
