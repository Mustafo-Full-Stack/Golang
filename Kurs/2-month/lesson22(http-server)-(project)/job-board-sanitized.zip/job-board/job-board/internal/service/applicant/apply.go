package applicant

import (
	"context"
	"errors"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) Apply(ctx context.Context, applicantID int64, in model.ApplyInput) (*model.Application, error) {
	v, err := s.vacancies.GetByID(ctx, in.VacancyID)
	if err != nil {
		return nil, fmt.Errorf("get vacancy: %w", err)
	}
	app, err := model.NewApplication(v, applicantID, in.CoverLetter)
	if err != nil {
		return nil, err
	}
	if _, err := s.resumes.GetByApplicant(ctx, applicantID); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil, model.Conflict("resume is required to apply")
		}
		return nil, fmt.Errorf("get resume: %w", err)
	}
	if err := s.applications.Create(ctx, app); err != nil {
		return nil, fmt.Errorf("create application: %w", err)
	}
	return app, nil
}
