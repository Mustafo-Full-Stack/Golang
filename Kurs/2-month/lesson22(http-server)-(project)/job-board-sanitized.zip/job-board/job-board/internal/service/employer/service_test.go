package employer_test

import (
	"errors"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
	"github.com/rabboni171/job-board/internal/service"
	"github.com/rabboni171/job-board/internal/service/employer"
)

const (
	ownerID   = int64(1)
	otherID   = int64(2)
	vacancyID = int64(10)
)

var errDB = errors.New("db is down")

func intPtr(v int) *int { return &v }

func validInput() model.VacancyInput {
	return model.VacancyInput{Title: "Go dev", Description: "d", City: "Almaty", EmploymentType: model.EmploymentFull}
}

type deps struct {
	vacancies *mocks.VacancyRepository
	apps      *mocks.ApplicationRepository
}

// newDeps создаёт строгие моки: любой неожиданный вызов репозитория валит тест.
func newDeps(t *testing.T) deps {
	return deps{vacancies: mocks.NewVacancyRepository(t), apps: mocks.NewApplicationRepository(t)}
}

func (d deps) svc() service.EmployerService {
	return employer.NewService(d.vacancies, d.apps)
}

// vacancy — вакансия работодателя ownerID в заданном статусе.
func vacancy(status model.VacancyStatus) *model.Vacancy {
	return &model.Vacancy{ID: vacancyID, EmployerID: ownerID, Status: status, Title: "Go dev", EmploymentType: model.EmploymentFull}
}

// requireErr: при want == nil ошибки нет, иначе err содержит want.
// Сбой хранилища не должен выглядеть как клиентская ошибка: клиент получил бы 404/409/422 вместо 500.
func requireErr(t *testing.T, err, want error) {
	t.Helper()
	if want == nil {
		require.NoError(t, err)
		return
	}
	require.ErrorIs(t, err, want)
	if errors.Is(want, errDB) {
		for _, clientErr := range []error{model.ErrNotFound, model.ErrConflict, model.ErrInvalidInput, model.ErrUnauthorized} {
			require.NotErrorIs(t, err, clientErr)
		}
	}
}
