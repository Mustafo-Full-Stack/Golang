package auth

import (
	"time"

	"github.com/rabboni171/job-board/internal/repository"
)

type service struct {
	users      repository.UserRepository
	sessions   repository.SessionRepository
	secret     []byte
	accessTTL  time.Duration
	refreshTTL time.Duration
}

func NewService(
	users repository.UserRepository,
	sessions repository.SessionRepository,
	secret string,
	accessTTL, refreshTTL time.Duration,
) *service {
	return &service{
		users:      users,
		sessions:   sessions,
		secret:     []byte(secret),
		accessTTL:  accessTTL,
		refreshTTL: refreshTTL,
	}
}
