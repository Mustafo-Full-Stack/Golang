package auth

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/rabboni171/job-board/internal/model"
)

const (
	sessionIDBytes = 16

	typeAccess  = "access"
	typeRefresh = "refresh"
)

var errInvalidRefresh = model.Unauthorized("invalid refresh token")

type jwtClaims struct {
	jwt.RegisteredClaims
	// Оба токена подписаны одним секретом, поэтому тип обязателен: иначе refresh на 30 дней
	// сработал бы как access.
	Type string     `json:"typ"`
	Role model.Role `json:"role,omitempty"`
}

// newSession создаёт сессию в хранилище и выпускает пару токенов с её id в jti.
func (s *service) newSession(ctx context.Context, u *model.User) (*model.TokenPair, error) {
	sid, err := randomID(sessionIDBytes)
	if err != nil {
		return nil, err
	}
	if err := s.sessions.Create(ctx, &model.Session{ID: sid, UserID: u.ID}, s.refreshTTL); err != nil {
		return nil, fmt.Errorf("save session: %w", err)
	}
	now := time.Now()
	access, err := s.sign(jwtClaims{RegisteredClaims: registeredClaims(u.ID, sid, now, s.accessTTL), Type: typeAccess, Role: u.Role})
	if err != nil {
		return nil, fmt.Errorf("sign access token: %w", err)
	}
	refresh, err := s.sign(jwtClaims{RegisteredClaims: registeredClaims(u.ID, sid, now, s.refreshTTL), Type: typeRefresh})
	if err != nil {
		return nil, fmt.Errorf("sign refresh token: %w", err)
	}
	return &model.TokenPair{AccessToken: access, RefreshToken: refresh}, nil
}

func registeredClaims(userID int64, sid string, now time.Time, ttl time.Duration) jwt.RegisteredClaims {
	return jwt.RegisteredClaims{
		// sub — стандартное поле JWT (RFC 7519) для id пользователя, отдельное user_id было бы дублем.
		Subject:   strconv.FormatInt(userID, 10),
		ID:        sid,
		IssuedAt:  jwt.NewNumericDate(now),
		ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
	}
}

func (s *service) sign(c jwtClaims) (string, error) {
	return jwt.NewWithClaims(jwt.SigningMethodHS256, c).SignedString(s.secret)
}

// parse проверяет подпись, срок и тип токена.
func (s *service) parse(token, typ string) (*model.Claims, error) {
	var c jwtClaims
	_, err := jwt.ParseWithClaims(token, &c, func(*jwt.Token) (any, error) {
		return s.secret, nil
	}, jwt.WithValidMethods([]string{jwt.SigningMethodHS256.Alg()}), jwt.WithExpirationRequired())
	if err != nil {
		// Клиенту — общий текст, причина от jwt остаётся в цепочке для лога и errors.Is.
		return nil, fmt.Errorf("%w: %w", model.Unauthorized("invalid token"), err)
	}
	if c.Type != typ {
		return nil, model.Unauthorized("wrong token type")
	}
	id, err := strconv.ParseInt(c.Subject, 10, 64)
	if err != nil {
		return nil, model.Unauthorized("invalid subject")
	}
	if c.ID == "" {
		return nil, model.Unauthorized("missing session id")
	}
	return &model.Claims{UserID: id, Role: c.Role, SessionID: c.ID}, nil
}

// checkSession: подпись и срок ещё не значат, что токен действует — сессию могли отозвать.
// Отозванная сессия и сессия другого пользователя возвращаются одинаково, как model.ErrNotFound.
func (s *service) checkSession(ctx context.Context, c *model.Claims) error {
	sess, err := s.sessions.Get(ctx, c.SessionID)
	if err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return err
		}
		return fmt.Errorf("get session: %w", err)
	}
	if sess.UserID != c.UserID {
		return model.NotFound("session")
	}
	return nil
}

func randomID(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", fmt.Errorf("generate session id: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}
