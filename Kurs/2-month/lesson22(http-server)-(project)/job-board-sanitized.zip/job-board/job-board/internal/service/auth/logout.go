package auth

import (
	"context"
	"errors"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

// Идемпотентен: невалидный токен не ошибка и не раскрывает, существовала ли сессия.
func (s *service) Logout(ctx context.Context, refreshToken string) error {
	c, err := s.parse(refreshToken, typeRefresh)
	if err != nil {
		return nil
	}
	if err := s.checkSession(ctx, c); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil
		}
		return err
	}
	if err := s.sessions.Delete(ctx, c.SessionID); err != nil {
		return fmt.Errorf("delete session: %w", err)
	}
	return nil
}
