package auth_test

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/bcrypt"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
	"github.com/rabboni171/job-board/internal/service/auth"
)

func TestService_SignUp(t *testing.T) {
	tests := []struct {
		name      string
		in        model.SignUpInput
		callsDB   bool
		createErr error
		wantEmail string
		wantErr   error
	}{
		{name: "ok", in: model.SignUpInput{Email: "a@b.c", Password: "Secret123", Role: model.RoleApplicant}, callsDB: true, wantEmail: "a@b.c"},
		{name: "email is normalized", in: model.SignUpInput{Email: " A@B.c ", Password: "Secret123", Role: model.RoleEmployer}, callsDB: true, wantEmail: "a@b.c"},
		{name: "multibyte password", in: model.SignUpInput{Email: "a@b.c", Password: "Пароль12", Role: model.RoleApplicant}, callsDB: true, wantEmail: "a@b.c"},
		{name: "duplicate email", in: model.SignUpInput{Email: "a@b.c", Password: "Secret123", Role: model.RoleEmployer}, callsDB: true, createErr: model.Conflict("email already registered"), wantErr: model.ErrConflict},
		{name: "store failure is not a conflict", in: model.SignUpInput{Email: "a@b.c", Password: "Secret123", Role: model.RoleEmployer}, callsDB: true, createErr: errStore, wantErr: errStore},
		{name: "unknown role", in: model.SignUpInput{Email: "a@b.c", Password: "Secret123", Role: "admin"}, wantErr: model.ErrInvalidInput},
		{name: "short password", in: model.SignUpInput{Email: "a@b.c", Password: "1234567", Role: model.RoleApplicant}, wantErr: model.ErrInvalidInput},
		{name: "short password in characters", in: model.SignUpInput{Email: "a@b.c", Password: "ёёёё", Role: model.RoleApplicant}, wantErr: model.ErrInvalidInput},
		{name: "password over bcrypt limit", in: model.SignUpInput{Email: "a@b.c", Password: "Aa1" + strings.Repeat("ж", 35), Role: model.RoleApplicant}, wantErr: model.ErrInvalidInput},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			users := mocks.NewUserRepository(t)
			if tt.callsDB {
				users.EXPECT().Create(mock.Anything, mock.Anything).Return(tt.createErr)
			}
			s := auth.NewService(users, mocks.NewSessionRepository(t), secret, accessTTL, refreshTTL)

			u, err := s.SignUp(context.Background(), tt.in)

			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				if !errors.Is(tt.wantErr, model.ErrConflict) {
					require.NotErrorIs(t, err, model.ErrConflict)
				}
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.wantEmail, u.Email)
			require.Equal(t, tt.in.Role, u.Role)
			// В базу уходит хеш, а не пароль.
			require.NotEqual(t, tt.in.Password, u.PasswordHash)
			require.NoError(t, bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(tt.in.Password)))
		})
	}
}
