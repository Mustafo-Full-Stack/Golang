package service

import (
	"context"

	"github.com/rabboni171/job-board/internal/model"
)

type AccountService interface {
	SignUp(ctx context.Context, in model.SignUpInput) (*model.User, error)
	Login(ctx context.Context, in model.LoginInput) (*model.TokenPair, error)
}

type TokenAuthenticator interface {
	Authenticate(ctx context.Context, token string) (*model.Claims, error)
}

type SessionManager interface {
	Refresh(ctx context.Context, refreshToken string) (*model.TokenPair, error)
	Logout(ctx context.Context, refreshToken string) error
}

type VacancyManager interface {
	CreateVacancy(ctx context.Context, employerID int64, in model.VacancyInput) (*model.Vacancy, error)
	UpdateVacancy(ctx context.Context, employerID, vacancyID int64, in model.VacancyInput) (*model.Vacancy, error)
	ListMyVacancies(ctx context.Context, employerID int64, p model.Page) (*model.Paged[model.Vacancy], error)
}

type VacancyLifecycle interface {
	CloseVacancy(ctx context.Context, employerID, vacancyID int64) error
	DeleteVacancy(ctx context.Context, employerID, vacancyID int64) error
}

type ApplicationReviewer interface {
	ListApplications(ctx context.Context, employerID, vacancyID int64, status model.ApplicationStatus, p model.Page) (*model.Paged[model.ApplicationWithResume], error)
	ChangeApplicationStatus(ctx context.Context, employerID, applicationID int64, status model.ApplicationStatus) error
}

type EmployerService interface {
	VacancyManager
	VacancyLifecycle
	ApplicationReviewer
}

type VacancyFinder interface {
	SearchVacancies(ctx context.Context, f model.VacancyFilter) (*model.Paged[model.Vacancy], error)
	GetVacancy(ctx context.Context, vacancyID, viewerID int64) (*model.VacancyView, error)
}

type ResumeKeeper interface {
	SaveResume(ctx context.Context, applicantID int64, in model.ResumeInput) (*model.Resume, error)
	GetResume(ctx context.Context, applicantID int64) (*model.Resume, error)
	DeleteResume(ctx context.Context, applicantID int64) error
}

type Applier interface {
	Apply(ctx context.Context, applicantID int64, in model.ApplyInput) (*model.Application, error)
	ListMyApplications(ctx context.Context, applicantID int64, p model.Page) (*model.Paged[model.ApplicationWithVacancy], error)
	Withdraw(ctx context.Context, applicantID, applicationID int64) error
}

type ApplicantService interface {
	VacancyFinder
	ResumeKeeper
	Applier
}
