package employer_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_CloseVacancy(t *testing.T) {
	closedStatus := mock.MatchedBy(func(v *model.Vacancy) bool {
		return v.ID == vacancyID && v.Status == model.VacancyClosed
	})
	tests := []struct {
		name       string
		employerID int64
		stored     *model.Vacancy
		getErr     error
		closes     bool
		closeErr   error
		wantErr    error
		wantMsg    string // текст клиентской ошибки; пусто — не проверяем
	}{
		{name: "ok", employerID: ownerID, stored: vacancy(model.VacancyOpen), closes: true},
		{name: "already closed", employerID: ownerID, stored: vacancy(model.VacancyClosed), wantErr: model.ErrConflict, wantMsg: "conflict: vacancy already closed"},
		{name: "foreign vacancy looks like missing", employerID: otherID, stored: vacancy(model.VacancyOpen), wantErr: model.ErrNotFound, wantMsg: "vacancy not found"},
		{name: "not found", employerID: ownerID, getErr: model.NotFound("vacancy"), wantErr: model.ErrNotFound},
		{
			name: "changed concurrently", employerID: ownerID, stored: vacancy(model.VacancyOpen), closes: true,
			closeErr: model.Conflict("vacancy was changed, try again"), wantErr: model.ErrConflict, wantMsg: "conflict: vacancy was changed, try again",
		},
		{name: "read failure", employerID: ownerID, getErr: errDB, wantErr: errDB},
		{name: "write failure", employerID: ownerID, stored: vacancy(model.VacancyOpen), closes: true, closeErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(tt.stored, tt.getErr)
			if tt.closes {
				d.vacancies.EXPECT().UpdateStatus(mock.Anything, closedStatus).Return(tt.closeErr)
			}

			err := d.svc().CloseVacancy(context.Background(), tt.employerID, vacancyID)

			requireErr(t, err, tt.wantErr)
			if tt.wantMsg != "" {
				var e *model.Error
				require.ErrorAs(t, err, &e)
				require.Equal(t, tt.wantMsg, e.Msg)
			}
		})
	}
}
