package auth_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
)

func TestService_Logout(t *testing.T) {
	pair, saved := loginPair(t, testUser(t), "12345678")
	sid := saved.ID

	tests := []struct {
		name    string
		token   string
		setup   func(sessions *mocks.SessionRepository) // nil — в хранилище ходить нельзя
		wantErr error
	}{
		{
			name:  "ok",
			token: pair.RefreshToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(saved, nil)
				sessions.EXPECT().Delete(mock.Anything, sid).Return(nil)
			},
		},
		{
			name:  "no session is idempotent",
			token: pair.RefreshToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(nil, model.NotFound("session"))
			},
		},
		{
			name:  "session of another user is kept",
			token: pair.RefreshToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(&model.Session{ID: sid, UserID: 43}, nil)
			},
		},
		{name: "access token is a no-op", token: pair.AccessToken},
		{name: "malformed token is a no-op", token: "abc"},
		{
			name:  "store failure on read",
			token: pair.RefreshToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(nil, errStore)
			},
			wantErr: errStore,
		},
		{
			name:  "store failure on delete",
			token: pair.RefreshToken,
			setup: func(sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, sid).Return(saved, nil)
				sessions.EXPECT().Delete(mock.Anything, sid).Return(errStore)
			},
			wantErr: errStore,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sessions := mocks.NewSessionRepository(t)
			if tt.setup != nil {
				tt.setup(sessions)
			}

			err := newService(mocks.NewUserRepository(t), sessions).Logout(context.Background(), tt.token)

			requireErr(t, err, tt.wantErr)
		})
	}
}
