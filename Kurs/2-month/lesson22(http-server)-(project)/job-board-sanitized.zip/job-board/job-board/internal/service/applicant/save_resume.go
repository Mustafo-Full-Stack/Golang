package applicant

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) SaveResume(ctx context.Context, applicantID int64, in model.ResumeInput) (*model.Resume, error) {
	r, err := model.NewResume(applicantID, in)
	if err != nil {
		return nil, err
	}
	if err := s.resumes.Upsert(ctx, r); err != nil {
		return nil, fmt.Errorf("save resume: %w", err)
	}
	return r, nil
}
