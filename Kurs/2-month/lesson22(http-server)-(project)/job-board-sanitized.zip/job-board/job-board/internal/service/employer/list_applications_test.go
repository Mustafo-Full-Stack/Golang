package employer_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_ListApplications(t *testing.T) {
	page := model.Page{Limit: 20}
	list := &model.Paged[model.ApplicationWithResume]{
		Items: []model.ApplicationWithResume{{Application: model.Application{ID: 5, VacancyID: vacancyID}}},
		Total: 1,
	}
	tests := []struct {
		name       string
		employerID int64
		status     model.ApplicationStatus
		checksOwn  bool // читаем вакансию, чтобы проверить владельца
		getErr     error
		lists      bool
		listErr    error
		wantErr    error
	}{
		{name: "ok", employerID: ownerID, checksOwn: true, lists: true},
		{name: "ok with status filter", employerID: ownerID, status: model.ApplicationInvited, checksOwn: true, lists: true},
		{name: "unknown status is rejected before db", employerID: ownerID, status: "weird", wantErr: model.ErrInvalidInput},
		{name: "foreign vacancy looks like missing", employerID: otherID, checksOwn: true, wantErr: model.ErrNotFound},
		{name: "vacancy not found", employerID: ownerID, checksOwn: true, getErr: model.NotFound("vacancy"), wantErr: model.ErrNotFound},
		{name: "list failure", employerID: ownerID, checksOwn: true, lists: true, listErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			if tt.checksOwn {
				d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(vacancy(model.VacancyOpen), tt.getErr)
			}
			if tt.lists {
				d.apps.EXPECT().ListByVacancy(mock.Anything, vacancyID, tt.status, page).Return(list, tt.listErr)
			}

			got, err := d.svc().ListApplications(context.Background(), tt.employerID, vacancyID, tt.status, page)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, list, got)
			}
		})
	}
}

func TestService_ListMyVacancies(t *testing.T) {
	page := model.Page{Limit: 20, Offset: 20}
	list := &model.Paged[model.Vacancy]{Items: []model.Vacancy{*vacancy(model.VacancyOpen)}, Total: 21}
	tests := []struct {
		name    string
		listErr error
		wantErr error
	}{
		{name: "ok: vacancies of the caller"},
		{name: "store failure", listErr: errDB, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.vacancies.EXPECT().ListByEmployer(mock.Anything, ownerID, page).Return(list, tt.listErr)

			got, err := d.svc().ListMyVacancies(context.Background(), ownerID, page)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, list, got)
			}
		})
	}
}
