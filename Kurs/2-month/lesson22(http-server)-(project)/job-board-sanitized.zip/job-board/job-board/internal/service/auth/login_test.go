package auth_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
)

func TestService_Login(t *testing.T) {
	user := testUser(t) // a@b.c / 12345678, id 42, employer
	sessionOfUser := mock.MatchedBy(func(s *model.Session) bool { return s.ID != "" && s.UserID == 42 })

	tests := []struct {
		name    string
		in      model.LoginInput
		setup   func(users *mocks.UserRepository, sessions *mocks.SessionRepository)
		wantErr error
	}{
		{
			name: "ok",
			in:   model.LoginInput{Email: "a@b.c", Password: "12345678"},
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				users.EXPECT().GetByEmail(mock.Anything, "a@b.c").Return(user, nil)
				sessions.EXPECT().Create(mock.Anything, sessionOfUser, refreshTTL).Return(nil)
			},
		},
		{
			name: "email is normalized before lookup",
			in:   model.LoginInput{Email: " A@B.c ", Password: "12345678"},
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				users.EXPECT().GetByEmail(mock.Anything, "a@b.c").Return(user, nil)
				sessions.EXPECT().Create(mock.Anything, sessionOfUser, refreshTTL).Return(nil)
			},
		},
		{
			name: "wrong password creates no session",
			in:   model.LoginInput{Email: "a@b.c", Password: "wrong-pass"},
			setup: func(users *mocks.UserRepository, _ *mocks.SessionRepository) {
				users.EXPECT().GetByEmail(mock.Anything, "a@b.c").Return(user, nil)
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name: "unknown email gives the same error",
			in:   model.LoginInput{Email: "a@b.c", Password: "12345678"},
			setup: func(users *mocks.UserRepository, _ *mocks.SessionRepository) {
				users.EXPECT().GetByEmail(mock.Anything, "a@b.c").Return(nil, model.NotFound("user"))
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name: "user store failure is not 401",
			in:   model.LoginInput{Email: "a@b.c", Password: "12345678"},
			setup: func(users *mocks.UserRepository, _ *mocks.SessionRepository) {
				users.EXPECT().GetByEmail(mock.Anything, "a@b.c").Return(nil, errStore)
			},
			wantErr: errStore,
		},
		{
			name: "session store failure is not 401",
			in:   model.LoginInput{Email: "a@b.c", Password: "12345678"},
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				users.EXPECT().GetByEmail(mock.Anything, "a@b.c").Return(user, nil)
				sessions.EXPECT().Create(mock.Anything, sessionOfUser, refreshTTL).Return(errStore)
			},
			wantErr: errStore,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			users, sessions := mocks.NewUserRepository(t), mocks.NewSessionRepository(t)
			tt.setup(users, sessions)

			pair, err := newService(users, sessions).Login(context.Background(), tt.in)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr != nil {
				return
			}
			access, refresh := tokenClaims(t, pair.AccessToken), tokenClaims(t, pair.RefreshToken)
			require.Equal(t, "42", access["sub"])
			require.Equal(t, "access", access["typ"])
			require.Equal(t, string(model.RoleEmployer), access["role"])
			require.Equal(t, "refresh", refresh["typ"])
			// Оба токена принадлежат одной сессии.
			require.NotEmpty(t, access["jti"])
			require.Equal(t, access["jti"], refresh["jti"])
		})
	}
}
