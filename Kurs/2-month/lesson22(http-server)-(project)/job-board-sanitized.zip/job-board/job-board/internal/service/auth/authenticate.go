package auth

import (
	"context"
	"errors"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) Authenticate(ctx context.Context, token string) (*model.Claims, error) {
	c, err := s.parse(token, typeAccess)
	if err != nil {
		return nil, err
	}
	if err := s.checkSession(ctx, c); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return nil, model.Unauthorized("session expired or revoked")
		}
		return nil, err
	}
	return c, nil
}
