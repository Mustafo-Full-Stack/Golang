package applicant_test

import (
	"context"
	"fmt"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_SaveResume(t *testing.T) {
	neg, over := -1, model.MaxSalary+1
	normalized := model.Resume{ApplicantID: applicantID, Title: "Go dev", City: "Almaty", ExperienceYears: 3, Skills: []string{"go", "sql"}}

	tests := []struct {
		name      string
		in        model.ResumeInput
		callsDB   bool
		upsertErr error
		wantErr   error
	}{
		{name: "ok: saves normalized resume of the caller", in: model.ResumeInput{Title: " Go dev ", City: " Almaty", ExperienceYears: 3, Skills: []string{"Go", "go", "SQL"}}, callsDB: true},
		{name: "store failure", in: model.ResumeInput{Title: " Go dev ", City: " Almaty", ExperienceYears: 3, Skills: []string{"Go", "go", "SQL"}}, callsDB: true, upsertErr: errDB, wantErr: errDB},
		{name: "experience over limit", in: model.ResumeInput{ExperienceYears: 61}, wantErr: model.ErrInvalidInput},
		{name: "negative experience", in: model.ResumeInput{ExperienceYears: -1}, wantErr: model.ErrInvalidInput},
		{name: "salary over limit", in: model.ResumeInput{SalaryExpectation: &over}, wantErr: model.ErrInvalidInput},
		{name: "negative salary", in: model.ResumeInput{SalaryExpectation: &neg}, wantErr: model.ErrInvalidInput},
		{name: "too many skills", in: model.ResumeInput{Skills: manySkills(21)}, wantErr: model.ErrInvalidInput},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			if tt.callsDB {
				d.resumes.EXPECT().Upsert(mock.Anything, &normalized).Return(tt.upsertErr)
			}

			got, err := d.svc().SaveResume(context.Background(), applicantID, tt.in)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, &normalized, got)
			}
		})
	}
}

func manySkills(n int) []string {
	out := make([]string, n)
	for i := range out {
		out[i] = fmt.Sprintf("skill%d", i)
	}
	return out
}
