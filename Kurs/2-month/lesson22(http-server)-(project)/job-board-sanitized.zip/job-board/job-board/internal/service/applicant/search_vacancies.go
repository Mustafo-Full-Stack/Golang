package applicant

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) SearchVacancies(ctx context.Context, f model.VacancyFilter) (*model.Paged[model.Vacancy], error) {
	if err := f.Normalize(); err != nil {
		return nil, err
	}
	// Соискатель ищет только среди открытых вакансий.
	f.Status = model.VacancyOpen
	vacancies, err := s.vacancies.Search(ctx, f)
	if err != nil {
		return nil, fmt.Errorf("search vacancies: %w", err)
	}
	return vacancies, nil
}
