package applicant

import (
	"context"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) Withdraw(ctx context.Context, applicantID, applicationID int64) error {
	app, err := s.applications.GetByID(ctx, applicationID)
	if err != nil {
		return fmt.Errorf("get application: %w", err)
	}
	if app.ApplicantID != applicantID {
		return model.NotFound("application")
	}
	if !app.Status.CanWithdraw() {
		return model.Conflict("cannot withdraw application in status %s", app.Status)
	}
	if err := s.applications.Delete(ctx, app); err != nil {
		return fmt.Errorf("withdraw application: %w", err)
	}
	return nil
}
