package auth_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
)

func TestService_Refresh(t *testing.T) {
	user := testUser(t)
	pair, saved := loginPair(t, user, "12345678")
	oldSID := saved.ID
	promoted := *user
	promoted.Role = model.RoleApplicant
	var createdSID string

	// validSession: сессия жива и принадлежит владельцу токена.
	validSession := func(sessions *mocks.SessionRepository) {
		sessions.EXPECT().Get(mock.Anything, oldSID).Return(saved, nil)
	}

	tests := []struct {
		name     string
		token    string
		setup    func(users *mocks.UserRepository, sessions *mocks.SessionRepository) // nil — в хранилища не ходим
		wantRole model.Role
		wantErr  error
	}{
		{
			name:  "ok: new session, role is taken from the database",
			token: pair.RefreshToken,
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				validSession(sessions)
				users.EXPECT().GetByID(mock.Anything, int64(42)).Return(&promoted, nil)
				sessions.EXPECT().Take(mock.Anything, oldSID).Return(nil)
				sessions.EXPECT().Create(mock.Anything, mock.Anything, refreshTTL).
					Run(func(_ context.Context, s *model.Session, _ time.Duration) { createdSID = s.ID }).Return(nil)
			},
			wantRole: model.RoleApplicant,
		},
		{name: "access token is not accepted as refresh", token: pair.AccessToken, wantErr: model.ErrUnauthorized},
		{name: "malformed token", token: "abc", wantErr: model.ErrUnauthorized},
		{
			name:  "unknown session",
			token: pair.RefreshToken,
			setup: func(_ *mocks.UserRepository, sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, oldSID).Return(nil, model.NotFound("session"))
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name:  "session of another user is not revoked",
			token: pair.RefreshToken,
			setup: func(_ *mocks.UserRepository, sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, oldSID).Return(&model.Session{ID: oldSID, UserID: 43}, nil)
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name:  "deleted user",
			token: pair.RefreshToken,
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				validSession(sessions)
				users.EXPECT().GetByID(mock.Anything, int64(42)).Return(nil, model.NotFound("user"))
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name:  "concurrent refresh with the same token: session already taken",
			token: pair.RefreshToken,
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				validSession(sessions)
				users.EXPECT().GetByID(mock.Anything, int64(42)).Return(user, nil)
				sessions.EXPECT().Take(mock.Anything, oldSID).Return(model.NotFound("session"))
			},
			wantErr: model.ErrUnauthorized,
		},
		{
			name:  "session store failure on read",
			token: pair.RefreshToken,
			setup: func(_ *mocks.UserRepository, sessions *mocks.SessionRepository) {
				sessions.EXPECT().Get(mock.Anything, oldSID).Return(nil, errStore)
			},
			wantErr: errStore,
		},
		{
			name:  "user store failure keeps the session",
			token: pair.RefreshToken,
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				validSession(sessions)
				users.EXPECT().GetByID(mock.Anything, int64(42)).Return(nil, errStore)
			},
			wantErr: errStore,
		},
		{
			name:  "session store failure on take",
			token: pair.RefreshToken,
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				validSession(sessions)
				users.EXPECT().GetByID(mock.Anything, int64(42)).Return(user, nil)
				sessions.EXPECT().Take(mock.Anything, oldSID).Return(errStore)
			},
			wantErr: errStore,
		},
		{
			name:  "session store failure on create",
			token: pair.RefreshToken,
			setup: func(users *mocks.UserRepository, sessions *mocks.SessionRepository) {
				validSession(sessions)
				users.EXPECT().GetByID(mock.Anything, int64(42)).Return(user, nil)
				sessions.EXPECT().Take(mock.Anything, oldSID).Return(nil)
				sessions.EXPECT().Create(mock.Anything, mock.Anything, refreshTTL).Return(errStore)
			},
			wantErr: errStore,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			users, sessions := mocks.NewUserRepository(t), mocks.NewSessionRepository(t)
			if tt.setup != nil {
				tt.setup(users, sessions)
			}

			got, err := newService(users, sessions).Refresh(context.Background(), tt.token)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr != nil {
				return
			}
			access := tokenClaims(t, got.AccessToken)
			require.Equal(t, string(tt.wantRole), access["role"])
			require.Equal(t, createdSID, access["jti"])
			require.NotEqual(t, oldSID, access["jti"])
			require.Equal(t, createdSID, tokenClaims(t, got.RefreshToken)["jti"])
		})
	}
}
