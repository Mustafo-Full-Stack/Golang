package applicant

import (
	"context"
	"fmt"
)

func (s *service) DeleteResume(ctx context.Context, applicantID int64) error {
	if err := s.resumes.Delete(ctx, applicantID); err != nil {
		return fmt.Errorf("delete resume: %w", err)
	}
	return nil
}
