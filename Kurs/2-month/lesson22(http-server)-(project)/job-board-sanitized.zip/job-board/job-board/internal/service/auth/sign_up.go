package auth

import (
	"context"
	"fmt"

	"golang.org/x/crypto/bcrypt"

	"github.com/rabboni171/job-board/internal/model"
)

const maxPasswordBytes = 72 // лимит bcrypt

func (s *service) SignUp(ctx context.Context, in model.SignUpInput) (*model.User, error) {
	u, err := model.NewUser(in)
	if err != nil {
		return nil, err
	}
	if len(in.Password) > maxPasswordBytes {
		return nil, model.InvalidInput("password must be at most %d bytes", maxPasswordBytes)
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, fmt.Errorf("hash password: %w", err)
	}
	u.PasswordHash = string(hash)
	if err := s.users.Create(ctx, u); err != nil {
		return nil, fmt.Errorf("create user: %w", err)
	}
	return u, nil
}
