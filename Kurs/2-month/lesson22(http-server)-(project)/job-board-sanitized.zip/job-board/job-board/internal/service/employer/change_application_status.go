package employer

import (
	"context"
	"errors"
	"fmt"

	"github.com/rabboni171/job-board/internal/model"
)

func (s *service) ChangeApplicationStatus(ctx context.Context, employerID, applicationID int64, status model.ApplicationStatus) error {
	if !status.Valid() {
		return model.InvalidInput("unknown status %q", status)
	}
	app, err := s.applications.GetByID(ctx, applicationID)
	if err != nil {
		return fmt.Errorf("get application: %w", err)
	}
	if _, err := s.ownedVacancy(ctx, employerID, app.VacancyID); err != nil {
		if errors.Is(err, model.ErrNotFound) {
			// Чужой отклик неотличим от несуществующего.
			return model.NotFound("application")
		}
		return err
	}
	// Повтор того же статуса — не конфликт: запрос идемпотентен.
	if app.Status == status {
		return nil
	}
	if !app.Status.CanChangeTo(status) {
		return model.Conflict("cannot change status from %s to %s", app.Status, status)
	}
	app.Status = status
	if err := s.applications.UpdateStatus(ctx, app); err != nil {
		return fmt.Errorf("update application status: %w", err)
	}
	return nil
}
