package applicant_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestService_GetVacancy(t *testing.T) {
	const strangerID = applicantID
	tests := []struct {
		name      string
		vacancy   *model.Vacancy
		getErr    error
		viewerID  int64
		hit       bool // засчитать просмотр (Hit) — только для чужих вакансий
		count     bool // только прочитать счётчик (Count) — для владельца
		wantViews int64
		wantErr   error
	}{
		{name: "open vacancy: stranger's view is counted", vacancy: &model.Vacancy{ID: vacancyID, EmployerID: ownerID, Status: model.VacancyOpen}, viewerID: strangerID, hit: true, wantViews: 4},
		{name: "open vacancy: owner does not inflate views", vacancy: &model.Vacancy{ID: vacancyID, EmployerID: ownerID, Status: model.VacancyOpen}, viewerID: ownerID, count: true, wantViews: 3},
		{name: "closed vacancy: owner still sees it", vacancy: &model.Vacancy{ID: vacancyID, EmployerID: ownerID, Status: model.VacancyClosed}, viewerID: ownerID, count: true, wantViews: 3},
		{name: "closed vacancy: hidden from stranger", vacancy: &model.Vacancy{ID: vacancyID, EmployerID: ownerID, Status: model.VacancyClosed}, viewerID: strangerID, wantErr: model.ErrNotFound},
		{name: "not found", getErr: model.NotFound("vacancy"), viewerID: strangerID, wantErr: model.ErrNotFound},
		{name: "store failure", getErr: errDB, viewerID: strangerID, wantErr: errDB},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := newDeps(t)
			d.vacancies.EXPECT().GetByID(mock.Anything, vacancyID).Return(tt.vacancy, tt.getErr)
			// Моки строгие: если владельцу засчитают просмотр (Hit), тест упадёт.
			if tt.hit {
				d.views.EXPECT().Hit(mock.Anything, vacancyID, tt.viewerID).Return(4)
			}
			if tt.count {
				d.views.EXPECT().Count(mock.Anything, vacancyID).Return(3)
			}

			got, err := d.svc().GetVacancy(context.Background(), vacancyID, tt.viewerID)

			requireErr(t, err, tt.wantErr)
			if tt.wantErr == nil {
				require.Equal(t, *tt.vacancy, got.Vacancy)
				require.Equal(t, tt.wantViews, got.Views)
			}
		})
	}
}
