package model

import (
	"errors"
	"fmt"
)

// Виды клиентских ошибок: по ним HTTP-слой выбирает статус ответа.
var (
	ErrNotFound     = errors.New("not found")
	ErrConflict     = errors.New("conflict")
	ErrInvalidInput = errors.New("invalid input")
	ErrUnauthorized = errors.New("unauthorized")
)

// Error — ошибка, адресованная клиенту. Msg уходит в ответ как есть, поэтому выше по стеку
// её можно свободно оборачивать контекстом: текст ответа от этого не меняется.
type Error struct {
	Kind error
	Msg  string
}

func (e *Error) Error() string { return e.Msg }

func (e *Error) Unwrap() error { return e.Kind }

// NotFound: NotFound("vacancy") → "vacancy not found".
func NotFound(what string) error {
	return &Error{Kind: ErrNotFound, Msg: what + " not found"}
}

func Conflict(format string, args ...any) error {
	return newError(ErrConflict, format, args...)
}

func InvalidInput(format string, args ...any) error {
	return newError(ErrInvalidInput, format, args...)
}

func Unauthorized(format string, args ...any) error {
	return newError(ErrUnauthorized, format, args...)
}

// newError добавляет вид ошибки префиксом: "conflict: already applied to this vacancy".
func newError(kind error, format string, args ...any) error {
	return &Error{Kind: kind, Msg: kind.Error() + ": " + fmt.Sprintf(format, args...)}
}
