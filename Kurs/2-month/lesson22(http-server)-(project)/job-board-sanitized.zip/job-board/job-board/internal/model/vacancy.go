package model

import (
	"strings"
	"time"
)

type EmploymentType string

const (
	EmploymentFull       EmploymentType = "full"
	EmploymentPart       EmploymentType = "part"
	EmploymentRemote     EmploymentType = "remote"
	EmploymentInternship EmploymentType = "internship"
)

func (t EmploymentType) Valid() bool {
	switch t {
	case EmploymentFull, EmploymentPart, EmploymentRemote, EmploymentInternship:
		return true
	}
	return false
}

type VacancyStatus string

const (
	VacancyOpen   VacancyStatus = "open"
	VacancyClosed VacancyStatus = "closed"
)

type Vacancy struct {
	ID             int64
	EmployerID     int64
	EmployerName   string
	Title          string
	Description    string
	City           string
	EmploymentType EmploymentType
	SalaryFrom     *int
	SalaryTo       *int
	Tags           []string
	Status         VacancyStatus
	CreatedAt      time.Time
	UpdatedAt      time.Time
}

type VacancyInput struct {
	Title          string
	Description    string
	City           string
	EmploymentType EmploymentType
	SalaryFrom     *int
	SalaryTo       *int
	Tags           []string
}

type VacancyFilter struct {
	Query          string
	City           string
	EmploymentType EmploymentType
	SalaryFrom     *int
	Tags           []string
	Status         VacancyStatus // пусто — любой статус
	Page           Page
}

// Normalize обрезает пробелы, нормализует теги как у вакансий и проверяет значения фильтра.
func (f *VacancyFilter) Normalize() error {
	f.Query = strings.TrimSpace(f.Query)
	f.City = strings.TrimSpace(f.City)
	f.Tags = NormalizeTags(f.Tags)
	switch {
	case f.EmploymentType != "" && !f.EmploymentType.Valid():
		return InvalidInput("unknown employment_type %q", f.EmploymentType)
	case f.SalaryFrom != nil && *f.SalaryFrom < 0:
		return InvalidInput("salary_from must not be negative")
	case f.SalaryFrom != nil && *f.SalaryFrom > MaxSalary:
		return InvalidInput("salary_from must be at most %d", MaxSalary)
	case len(f.Tags) > MaxVacancyTags:
		return InvalidInput("at most %d tags", MaxVacancyTags)
	}
	return nil
}

type VacancyView struct {
	Vacancy Vacancy
	Views   int64
}

const (
	MaxVacancyTags = 10
	MaxSalary      = 1_000_000_000 // зарплаты хранятся в INT, больше — ошибка Postgres
)

// NormalizeTags приводит теги к нижнему регистру и убирает пустые и повторы:
// поиск по тегам регистрозависимый.
func NormalizeTags(tags []string) []string {
	out := make([]string, 0, len(tags))
	seen := make(map[string]struct{}, len(tags))
	for _, t := range tags {
		t = strings.ToLower(strings.TrimSpace(t))
		if _, dup := seen[t]; t == "" || dup {
			continue
		}
		seen[t] = struct{}{}
		out = append(out, t)
	}
	return out
}

func NewVacancy(employerID int64, in VacancyInput) (*Vacancy, error) {
	v := &Vacancy{EmployerID: employerID, Status: VacancyOpen}
	if err := v.Edit(in); err != nil {
		return nil, err
	}
	return v, nil
}

// Edit валидирует как при создании; при ошибке вакансия не меняется.
func (v *Vacancy) Edit(in VacancyInput) error {
	if v.Status == VacancyClosed {
		return Conflict("vacancy is closed")
	}
	in.Tags = NormalizeTags(in.Tags)
	switch {
	case !in.EmploymentType.Valid():
		return InvalidInput("unknown employment_type %q", in.EmploymentType)
	case in.SalaryFrom != nil && *in.SalaryFrom < 0, in.SalaryTo != nil && *in.SalaryTo < 0:
		return InvalidInput("salary must not be negative")
	case in.SalaryFrom != nil && in.SalaryTo != nil && *in.SalaryFrom > *in.SalaryTo:
		return InvalidInput("salary_from must be <= salary_to")
	case in.SalaryFrom != nil && *in.SalaryFrom > MaxSalary, in.SalaryTo != nil && *in.SalaryTo > MaxSalary:
		return InvalidInput("salary must be at most %d", MaxSalary)
	case len(in.Tags) > MaxVacancyTags:
		return InvalidInput("at most %d tags", MaxVacancyTags)
	}
	v.Title, v.Description, v.City = strings.TrimSpace(in.Title), in.Description, strings.TrimSpace(in.City)
	v.EmploymentType, v.SalaryFrom, v.SalaryTo, v.Tags = in.EmploymentType, in.SalaryFrom, in.SalaryTo, in.Tags
	return nil
}
