package model_test

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestNewUser(t *testing.T) {
	tests := []struct {
		name    string
		in      model.SignUpInput
		want    model.User
		wantErr error
	}{
		{name: "unknown role", in: model.SignUpInput{Email: "a@b.c", Password: "Secret123", Role: "admin"}, wantErr: model.ErrInvalidInput},
		{name: "short password", in: model.SignUpInput{Email: "a@b.c", Password: "Secre12", Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "long password", in: model.SignUpInput{Email: "a@b.c", Password: "Aa1" + strings.Repeat("x", 62), Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "4 runes of 8 bytes is too short", in: model.SignUpInput{Email: "a@b.c", Password: "Ёё1ё", Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "space", in: model.SignUpInput{Email: "a@b.c", Password: "Secret 123", Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "no digit", in: model.SignUpInput{Email: "a@b.c", Password: "SecretPass", Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "no uppercase", in: model.SignUpInput{Email: "a@b.c", Password: "secret123", Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "no lowercase", in: model.SignUpInput{Email: "a@b.c", Password: "SECRET123", Role: model.RoleEmployer}, wantErr: model.ErrInvalidInput},
		{name: "8 characters is the minimum", in: model.SignUpInput{Email: "a@b.c", Password: "Secret12", Role: model.RoleApplicant},
			want: model.User{Email: "a@b.c", Role: model.RoleApplicant}},
		{name: "64 characters is the maximum", in: model.SignUpInput{Email: "a@b.c", Password: "Aa1" + strings.Repeat("x", 61), Role: model.RoleApplicant},
			want: model.User{Email: "a@b.c", Role: model.RoleApplicant}},
		{name: "cyrillic is fine", in: model.SignUpInput{Email: "a@b.c", Password: "Пароль123", Role: model.RoleEmployer},
			want: model.User{Email: "a@b.c", Role: model.RoleEmployer}},
		{name: "normalizes", in: model.SignUpInput{Email: " HR@Acme.io ", Password: "Secret123", Name: "  Acme  ", Role: model.RoleEmployer},
			want: model.User{Email: "hr@acme.io", Name: "Acme", Role: model.RoleEmployer}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			u, err := model.NewUser(tt.in)
			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.want, *u)
		})
	}
}
