package model_test

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestNormalizeTags(t *testing.T) {
	tests := []struct {
		name string
		in   []string
		want []string
	}{
		{name: "nil", in: nil, want: []string{}},
		{name: "empty and blank", in: []string{"", "  "}, want: []string{}},
		{name: "duplicates by case and spaces", in: []string{"Go", " go ", "Postgres", "GO"}, want: []string{"go", "postgres"}},
		{name: "keeps first occurrence order", in: []string{"b", "A", "b"}, want: []string{"b", "a"}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			require.Equal(t, tt.want, model.NormalizeTags(tt.in))
		})
	}
}

func validVacancyInput() model.VacancyInput {
	return model.VacancyInput{Title: "Go dev", Description: "desc", EmploymentType: model.EmploymentFull}
}

func TestNewVacancy(t *testing.T) {
	tests := []struct {
		name    string
		mutate  func(in *model.VacancyInput)
		want    model.Vacancy
		wantErr error
	}{
		{
			name:   "ok: new vacancy is open and belongs to employer",
			mutate: func(*model.VacancyInput) {},
			want: model.Vacancy{EmployerID: 5, Status: model.VacancyOpen, Title: "Go dev", Description: "desc",
				EmploymentType: model.EmploymentFull, Tags: []string{}},
		},
		{
			name: "trims title and city, normalizes tags",
			mutate: func(in *model.VacancyInput) {
				in.Title, in.City, in.Tags = "  Go dev ", " Almaty ", []string{"Go", " go ", "SQL"}
			},
			want: model.Vacancy{EmployerID: 5, Status: model.VacancyOpen, Title: "Go dev", Description: "desc", City: "Almaty",
				EmploymentType: model.EmploymentFull, Tags: []string{"go", "sql"}},
		},
		{
			name:   "salary from equals to",
			mutate: func(in *model.VacancyInput) { in.SalaryFrom, in.SalaryTo = intPtr(100), intPtr(100) },
			want: model.Vacancy{EmployerID: 5, Status: model.VacancyOpen, Title: "Go dev", Description: "desc",
				EmploymentType: model.EmploymentFull, SalaryFrom: intPtr(100), SalaryTo: intPtr(100), Tags: []string{}},
		},
		{
			name:   "10 tags is the limit",
			mutate: func(in *model.VacancyInput) { in.Tags = strings.Fields("a b c d e f g h i j") },
			want: model.Vacancy{EmployerID: 5, Status: model.VacancyOpen, Title: "Go dev", Description: "desc",
				EmploymentType: model.EmploymentFull, Tags: strings.Fields("a b c d e f g h i j")},
		},
		{name: "unknown employment type", mutate: func(in *model.VacancyInput) { in.EmploymentType = "weird" }, wantErr: model.ErrInvalidInput},
		{name: "salary from > to", mutate: func(in *model.VacancyInput) { in.SalaryFrom, in.SalaryTo = intPtr(200), intPtr(100) }, wantErr: model.ErrInvalidInput},
		{name: "salary above max", mutate: func(in *model.VacancyInput) { in.SalaryTo = intPtr(model.MaxSalary + 1) }, wantErr: model.ErrInvalidInput},
		{name: "salary from negative", mutate: func(in *model.VacancyInput) { in.SalaryFrom = intPtr(-1) }, wantErr: model.ErrInvalidInput},
		{name: "salary to negative", mutate: func(in *model.VacancyInput) { in.SalaryTo = intPtr(-1) }, wantErr: model.ErrInvalidInput},
		{name: "11 tags", mutate: func(in *model.VacancyInput) { in.Tags = strings.Fields("a b c d e f g h i j k") }, wantErr: model.ErrInvalidInput},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			in := validVacancyInput()
			tt.mutate(&in)

			got, err := model.NewVacancy(5, in)

			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.want, *got)
		})
	}
}

func TestVacancy_Edit(t *testing.T) {
	open := model.Vacancy{ID: 1, EmployerID: 5, Status: model.VacancyOpen, Title: "old", EmploymentType: model.EmploymentPart, Tags: []string{"x"}}
	closed := open
	closed.Status = model.VacancyClosed

	tests := []struct {
		name    string
		vacancy model.Vacancy
		mutate  func(in *model.VacancyInput)
		want    model.Vacancy // при ошибке вакансия должна остаться как была
		wantErr error
	}{
		{
			name:    "applies input, keeps id, owner and status",
			vacancy: open,
			mutate:  func(in *model.VacancyInput) { in.Title = " new " },
			want: model.Vacancy{ID: 1, EmployerID: 5, Status: model.VacancyOpen, Title: "new", Description: "desc",
				EmploymentType: model.EmploymentFull, Tags: []string{}},
		},
		{name: "closed vacancy is not editable", vacancy: closed, mutate: func(*model.VacancyInput) {}, want: closed, wantErr: model.ErrConflict},
		{
			name:    "invalid input leaves vacancy unchanged",
			vacancy: open,
			mutate:  func(in *model.VacancyInput) { in.EmploymentType = "weird" },
			want:    open,
			wantErr: model.ErrInvalidInput,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			v := tt.vacancy
			in := validVacancyInput()
			tt.mutate(&in)

			err := v.Edit(in)

			require.ErrorIs(t, err, tt.wantErr)
			require.Equal(t, tt.want, v)
		})
	}
}

func TestVacancyFilter_Normalize(t *testing.T) {
	tests := []struct {
		name    string
		in      model.VacancyFilter
		want    model.VacancyFilter
		wantErr error
	}{
		{
			name: "trims query and city, normalizes tags",
			in:   model.VacancyFilter{Query: "  go ", City: " Almaty ", Tags: []string{"Go", " go ", "SQL"}},
			want: model.VacancyFilter{Query: "go", City: "Almaty", Tags: []string{"go", "sql"}},
		},
		{name: "empty filter gets non-nil tags", in: model.VacancyFilter{}, want: model.VacancyFilter{Tags: []string{}}},
		{
			name: "valid employment type and salary",
			in:   model.VacancyFilter{EmploymentType: model.EmploymentRemote, SalaryFrom: intPtr(100)},
			want: model.VacancyFilter{EmploymentType: model.EmploymentRemote, SalaryFrom: intPtr(100), Tags: []string{}},
		},
		{name: "salary zero is allowed", in: model.VacancyFilter{SalaryFrom: intPtr(0)}, want: model.VacancyFilter{SalaryFrom: intPtr(0), Tags: []string{}}},
		{name: "salary at max is allowed", in: model.VacancyFilter{SalaryFrom: intPtr(model.MaxSalary)}, want: model.VacancyFilter{SalaryFrom: intPtr(model.MaxSalary), Tags: []string{}}},
		{name: "10 tags is the limit", in: model.VacancyFilter{Tags: strings.Fields("a b c d e f g h i j")}, want: model.VacancyFilter{Tags: strings.Fields("a b c d e f g h i j")}},
		{name: "unknown employment type", in: model.VacancyFilter{EmploymentType: "weird"}, wantErr: model.ErrInvalidInput},
		{name: "negative salary", in: model.VacancyFilter{SalaryFrom: intPtr(-1)}, wantErr: model.ErrInvalidInput},
		{name: "salary above max", in: model.VacancyFilter{SalaryFrom: intPtr(model.MaxSalary + 1)}, wantErr: model.ErrInvalidInput},
		{name: "11 tags", in: model.VacancyFilter{Tags: strings.Fields("a b c d e f g h i j k")}, wantErr: model.ErrInvalidInput},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			f := tt.in

			err := f.Normalize()

			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.want, f)
		})
	}
}
