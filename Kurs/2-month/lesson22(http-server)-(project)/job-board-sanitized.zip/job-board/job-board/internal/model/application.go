package model

import (
	"slices"
	"time"
)

type ApplicationStatus string

const (
	ApplicationNew      ApplicationStatus = "new"
	ApplicationViewed   ApplicationStatus = "viewed"
	ApplicationInvited  ApplicationStatus = "invited"
	ApplicationRejected ApplicationStatus = "rejected"
)

// Из invited и rejected переходов нет: решение работодателя окончательное.
var transitions = map[ApplicationStatus][]ApplicationStatus{
	ApplicationNew:    {ApplicationViewed, ApplicationInvited, ApplicationRejected},
	ApplicationViewed: {ApplicationInvited, ApplicationRejected},
}

func (s ApplicationStatus) Valid() bool {
	switch s {
	case ApplicationNew, ApplicationViewed, ApplicationInvited, ApplicationRejected:
		return true
	}
	return false
}

func (s ApplicationStatus) CanChangeTo(next ApplicationStatus) bool {
	return slices.Contains(transitions[s], next)
}

// Отозвать можно только непросмотренный отклик: иначе отзыв и повторная подача
// сбрасывали бы решение работодателя.
func (s ApplicationStatus) CanWithdraw() bool {
	return s == ApplicationNew
}

type Application struct {
	ID          int64
	VacancyID   int64
	ApplicantID int64
	CoverLetter string
	Status      ApplicationStatus
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

type ApplyInput struct {
	VacancyID   int64
	CoverLetter string
}

type ApplicationWithResume struct {
	Application   Application
	ApplicantName string
	Resume        *Resume // nil, если соискатель удалил резюме после отклика
}

type ApplicationWithVacancy struct {
	Application   Application
	VacancyTitle  string
	EmployerName  string
	VacancyStatus VacancyStatus
}

// NewApplication: откликнуться можно только на открытую вакансию.
func NewApplication(v *Vacancy, applicantID int64, coverLetter string) (*Application, error) {
	if v.Status != VacancyOpen {
		// Закрытая вакансия невидима соискателю, как в GetVacancy.
		return nil, NotFound("vacancy")
	}
	return &Application{VacancyID: v.ID, ApplicantID: applicantID, CoverLetter: coverLetter, Status: ApplicationNew}, nil
}
