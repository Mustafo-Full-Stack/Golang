package model_test

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func intPtr(v int) *int { return &v }

func distinctSkills(n int) []string {
	out := make([]string, n)
	for i := range out {
		out[i] = fmt.Sprintf("skill%d", i)
	}
	return out
}

func TestNewResume(t *testing.T) {
	tests := []struct {
		name    string
		in      model.ResumeInput
		want    model.Resume
		wantErr error
	}{
		{
			name: "trims title and city, normalizes skills, keeps about as is",
			in: model.ResumeInput{
				Title: "  Go dev ", About: " text ", City: " Almaty  ", ExperienceYears: 3,
				SalaryExpectation: intPtr(100), Skills: []string{" Go ", "GO", "SQL"},
			},
			want: model.Resume{
				ApplicantID: 7, Title: "Go dev", About: " text ", City: "Almaty", ExperienceYears: 3,
				SalaryExpectation: intPtr(100), Skills: []string{"go", "sql"},
			},
		},
		{name: "empty input", in: model.ResumeInput{}, want: model.Resume{ApplicantID: 7, Skills: []string{}}},
		{
			name: "experience 60 is the limit",
			in:   model.ResumeInput{ExperienceYears: 60},
			want: model.Resume{ApplicantID: 7, ExperienceYears: 60, Skills: []string{}},
		},
		{
			name: "salary bounds are inclusive",
			in:   model.ResumeInput{SalaryExpectation: intPtr(model.MaxSalary)},
			want: model.Resume{ApplicantID: 7, SalaryExpectation: intPtr(model.MaxSalary), Skills: []string{}},
		},
		{
			name: "duplicates do not count towards the skills limit",
			in:   model.ResumeInput{Skills: append(distinctSkills(20), "SKILL0", " skill1 ")},
			want: model.Resume{ApplicantID: 7, Skills: distinctSkills(20)},
		},
		{name: "experience 61", in: model.ResumeInput{ExperienceYears: 61}, wantErr: model.ErrInvalidInput},
		{name: "experience negative", in: model.ResumeInput{ExperienceYears: -1}, wantErr: model.ErrInvalidInput},
		{name: "21 skills", in: model.ResumeInput{Skills: distinctSkills(21)}, wantErr: model.ErrInvalidInput},
		{name: "salary above max", in: model.ResumeInput{SalaryExpectation: intPtr(model.MaxSalary + 1)}, wantErr: model.ErrInvalidInput},
		{name: "salary negative", in: model.ResumeInput{SalaryExpectation: intPtr(-1)}, wantErr: model.ErrInvalidInput},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := model.NewResume(7, tt.in)

			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.want, *got)
		})
	}
}
