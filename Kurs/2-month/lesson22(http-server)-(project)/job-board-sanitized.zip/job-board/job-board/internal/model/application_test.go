package model_test

import (
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestApplicationStatus_Valid(t *testing.T) {
	tests := []struct {
		name   string
		status model.ApplicationStatus
		want   bool
	}{
		{name: "new", status: model.ApplicationNew, want: true},
		{name: "viewed", status: model.ApplicationViewed, want: true},
		{name: "invited", status: model.ApplicationInvited, want: true},
		{name: "rejected", status: model.ApplicationRejected, want: true},
		{name: "empty", status: "", want: false},
		{name: "unknown", status: "archived", want: false},
		{name: "case matters", status: "NEW", want: false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			require.Equal(t, tt.want, tt.status.Valid())
		})
	}
}

// Перебираем все пары статусов: разрешены только переходы из диаграммы, остальные запрещены.
func TestApplicationStatus_CanChangeTo(t *testing.T) {
	all := []model.ApplicationStatus{model.ApplicationNew, model.ApplicationViewed, model.ApplicationInvited, model.ApplicationRejected}
	allowed := map[[2]model.ApplicationStatus]bool{
		{model.ApplicationNew, model.ApplicationViewed}:      true,
		{model.ApplicationNew, model.ApplicationInvited}:     true,
		{model.ApplicationNew, model.ApplicationRejected}:    true,
		{model.ApplicationViewed, model.ApplicationInvited}:  true,
		{model.ApplicationViewed, model.ApplicationRejected}: true,
	}
	for _, from := range all {
		for _, to := range all {
			t.Run(string(from)+"->"+string(to), func(t *testing.T) {
				require.Equal(t, allowed[[2]model.ApplicationStatus{from, to}], from.CanChangeTo(to))
			})
		}
	}
}

func TestApplicationStatus_CanWithdraw(t *testing.T) {
	tests := []struct {
		status model.ApplicationStatus
		want   bool
	}{
		{model.ApplicationNew, true},
		{model.ApplicationViewed, false},
		{model.ApplicationInvited, false},
		{model.ApplicationRejected, false},
	}
	for _, tt := range tests {
		t.Run(string(tt.status), func(t *testing.T) {
			require.Equal(t, tt.want, tt.status.CanWithdraw())
		})
	}
}

func TestNewApplication(t *testing.T) {
	tests := []struct {
		name    string
		vacancy model.Vacancy
		want    model.Application
		wantErr error
	}{
		{
			name:    "open vacancy",
			vacancy: model.Vacancy{ID: 9, Status: model.VacancyOpen},
			want:    model.Application{VacancyID: 9, ApplicantID: 2, CoverLetter: "hi", Status: model.ApplicationNew},
		},
		{
			name:    "closed vacancy is invisible to applicant",
			vacancy: model.Vacancy{ID: 9, Status: model.VacancyClosed},
			wantErr: model.ErrNotFound,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := model.NewApplication(&tt.vacancy, 2, "hi")

			if tt.wantErr != nil {
				require.ErrorIs(t, err, tt.wantErr)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tt.want, *got)
		})
	}
}
