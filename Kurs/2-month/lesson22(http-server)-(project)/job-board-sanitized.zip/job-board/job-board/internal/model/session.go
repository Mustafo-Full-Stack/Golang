package model

// Session — одна пара токенов: её ID лежит в jti обоих JWT.
type Session struct {
	ID     string
	UserID int64
}

type TokenPair struct {
	AccessToken  string
	RefreshToken string
}
