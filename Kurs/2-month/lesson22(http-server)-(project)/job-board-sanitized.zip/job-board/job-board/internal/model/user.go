package model

import (
	"strings"
	"time"
	"unicode"
	"unicode/utf8"
)

type Role string

const (
	RoleEmployer  Role = "employer"
	RoleApplicant Role = "applicant"
)

func (r Role) Valid() bool {
	switch r {
	case RoleEmployer, RoleApplicant:
		return true
	}
	return false
}

type User struct {
	ID           int64
	Email        string
	PasswordHash string
	Name         string
	Role         Role
	CreatedAt    time.Time
}

type SignUpInput struct {
	Email    string
	Password string
	Name     string
	Role     Role
}

type LoginInput struct {
	Email    string
	Password string
}

type Claims struct {
	UserID    int64
	Role      Role
	SessionID string
}

const (
	minPasswordLen = 8
	maxPasswordLen = 64
)

// NormalizeEmail: email уникален без учёта регистра.
func NormalizeEmail(email string) string { return strings.ToLower(strings.TrimSpace(email)) }

// NewUser проверяет данные регистрации и возвращает пользователя без хеша пароля:
// хешированием занимается сервис.
func NewUser(in SignUpInput) (*User, error) {
	if !in.Role.Valid() {
		return nil, InvalidInput("unknown role %q", in.Role)
	}
	if err := validatePassword(in.Password); err != nil {
		return nil, err
	}
	return &User{Email: NormalizeEmail(in.Email), Name: strings.TrimSpace(in.Name), Role: in.Role}, nil
}

func validatePassword(p string) error {
	if n := utf8.RuneCountInString(p); n < minPasswordLen || n > maxPasswordLen {
		return InvalidInput("password must be %d to %d characters", minPasswordLen, maxPasswordLen)
	}
	var upper, lower, digit bool
	for _, r := range p {
		switch {
		case unicode.IsSpace(r):
			return InvalidInput("password must not contain spaces")
		case unicode.IsUpper(r):
			upper = true
		case unicode.IsLower(r):
			lower = true
		case unicode.IsDigit(r):
			digit = true
		}
	}
	if !upper || !lower || !digit {
		return InvalidInput("password must contain an uppercase letter, a lowercase letter and a digit")
	}
	return nil
}
