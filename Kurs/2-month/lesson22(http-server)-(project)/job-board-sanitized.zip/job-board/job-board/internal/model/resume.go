package model

import (
	"strings"
	"time"
)

type Resume struct {
	ApplicantID       int64
	Title             string
	About             string
	City              string
	ExperienceYears   int
	SalaryExpectation *int
	Skills            []string
	UpdatedAt         time.Time
}

type ResumeInput struct {
	Title             string
	About             string
	City              string
	ExperienceYears   int
	SalaryExpectation *int
	Skills            []string
}

const (
	maxSkills          = 20
	maxExperienceYears = 60
)

func NewResume(applicantID int64, in ResumeInput) (*Resume, error) {
	in.Skills = NormalizeTags(in.Skills)
	switch {
	case len(in.Skills) > maxSkills:
		return nil, InvalidInput("at most %d skills", maxSkills)
	case in.ExperienceYears < 0:
		return nil, InvalidInput("experience_years must not be negative")
	case in.ExperienceYears > maxExperienceYears:
		return nil, InvalidInput("experience_years must be at most %d", maxExperienceYears)
	case in.SalaryExpectation != nil && *in.SalaryExpectation < 0:
		return nil, InvalidInput("salary_expectation must not be negative")
	case in.SalaryExpectation != nil && *in.SalaryExpectation > MaxSalary:
		return nil, InvalidInput("salary_expectation must be at most %d", MaxSalary)
	}
	return &Resume{
		ApplicantID:       applicantID,
		Title:             strings.TrimSpace(in.Title),
		About:             in.About,
		City:              strings.TrimSpace(in.City),
		ExperienceYears:   in.ExperienceYears,
		SalaryExpectation: in.SalaryExpectation,
		Skills:            in.Skills,
	}, nil
}
