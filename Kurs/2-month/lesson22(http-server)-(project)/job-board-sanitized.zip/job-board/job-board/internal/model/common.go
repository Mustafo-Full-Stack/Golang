package model

type Page struct {
	Limit  int
	Offset int
}

type Paged[T any] struct {
	Items []T
	Total int
}
