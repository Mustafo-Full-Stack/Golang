package pgrepo

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/pkg/database"
)

const vacancySelect = `SELECT v.id, v.employer_id, u.name AS employer_name, v.title, v.description, v.city, v.employment_type,
	v.salary_from, v.salary_to, v.tags, v.status, v.created_at, v.updated_at
	FROM vacancies v JOIN users u ON u.id = v.employer_id`

var (
	errVacancyChanged = model.Conflict("vacancy was changed, try again")
	// Тот же текст, что у проверки в сервисе: для клиента это одна и та же ситуация.
	errVacancyHasApplications = model.Conflict("vacancy has applications")
)

type vacancyRepo struct {
	db database.DB
}

func NewVacancyRepo(db database.DB) *vacancyRepo {
	return &vacancyRepo{db: db}
}

func (r *vacancyRepo) Create(ctx context.Context, v *model.Vacancy) error {
	err := r.db.QueryRow(ctx,
		`INSERT INTO vacancies (employer_id, title, description, city, employment_type,
		   salary_from, salary_to, tags, status)
		 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		 RETURNING id, created_at, updated_at`,
		v.EmployerID, v.Title, v.Description, v.City, string(v.EmploymentType),
		v.SalaryFrom, v.SalaryTo, nonNil(v.Tags), string(v.Status),
	).Scan(&v.ID, &v.CreatedAt, &v.UpdatedAt)
	if err != nil {
		return fmt.Errorf("create vacancy: %w", err)
	}
	return nil
}

func (r *vacancyRepo) GetByID(ctx context.Context, id int64) (*model.Vacancy, error) {
	rows, err := r.db.Query(ctx, vacancySelect+` WHERE v.id = $1`, id)
	if err != nil {
		return nil, fmt.Errorf("get vacancy: %w", err)
	}
	row, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[vacancyRow])
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, model.NotFound("vacancy")
		}
		return nil, fmt.Errorf("get vacancy: %w", err)
	}
	v := row.toModel()
	return &v, nil
}

func (r *vacancyRepo) Update(ctx context.Context, v *model.Vacancy) error {
	err := r.db.QueryRow(ctx,
		`UPDATE vacancies SET title = $3, description = $4, city = $5, employment_type = $6,
		   salary_from = $7, salary_to = $8, tags = $9, updated_at = now()
		 WHERE id = $1 AND updated_at = $2
		 RETURNING updated_at`,
		v.ID, v.UpdatedAt, v.Title, v.Description, v.City, string(v.EmploymentType),
		v.SalaryFrom, v.SalaryTo, nonNil(v.Tags),
	).Scan(&v.UpdatedAt)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return errVacancyChanged
		}
		return fmt.Errorf("update vacancy: %w", err)
	}
	return nil
}

func (r *vacancyRepo) UpdateStatus(ctx context.Context, v *model.Vacancy) error {
	err := r.db.QueryRow(ctx,
		`UPDATE vacancies SET status = $3, updated_at = now()
		 WHERE id = $1 AND updated_at = $2
		 RETURNING updated_at`,
		v.ID, v.UpdatedAt, string(v.Status),
	).Scan(&v.UpdatedAt)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return errVacancyChanged
		}
		return fmt.Errorf("update vacancy status: %w", err)
	}
	return nil
}

func (r *vacancyRepo) Delete(ctx context.Context, id int64) error {
	tag, err := r.db.Exec(ctx, `DELETE FROM vacancies WHERE id = $1`, id)
	if err != nil {
		// ON DELETE RESTRICT страхует проверку сервиса от отклика, пришедшего в момент удаления.
		if isForeignKeyViolation(err) {
			return errVacancyHasApplications
		}
		return fmt.Errorf("delete vacancy: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return model.NotFound("vacancy")
	}
	return nil
}

func (r *vacancyRepo) Search(ctx context.Context, f model.VacancyFilter) (*model.Paged[model.Vacancy], error) {
	where, args := buildSearchWhere(f)

	var total int
	if err := r.db.QueryRow(ctx, `SELECT count(*) FROM vacancies v`+where, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count vacancies: %w", err)
	}

	q := vacancySelect + where + fmt.Sprintf(
		` ORDER BY v.created_at DESC, v.id DESC LIMIT $%d OFFSET $%d`, len(args)+1, len(args)+2)
	items, err := r.queryVacancies(ctx, q, append(args, f.Page.Limit, f.Page.Offset)...)
	if err != nil {
		return nil, fmt.Errorf("search vacancies: %w", err)
	}
	return &model.Paged[model.Vacancy]{Items: items, Total: total}, nil
}

func (r *vacancyRepo) ListByEmployer(ctx context.Context, employerID int64, p model.Page) (*model.Paged[model.Vacancy], error) {
	var total int
	if err := r.db.QueryRow(ctx,
		`SELECT count(*) FROM vacancies WHERE employer_id = $1`, employerID).Scan(&total); err != nil {
		return nil, fmt.Errorf("count employer vacancies: %w", err)
	}

	items, err := r.queryVacancies(ctx,
		vacancySelect+` WHERE v.employer_id = $1 ORDER BY v.created_at DESC, v.id DESC LIMIT $2 OFFSET $3`,
		employerID, p.Limit, p.Offset)
	if err != nil {
		return nil, fmt.Errorf("list employer vacancies: %w", err)
	}
	return &model.Paged[model.Vacancy]{Items: items, Total: total}, nil
}

func (r *vacancyRepo) queryVacancies(ctx context.Context, q string, args ...any) ([]model.Vacancy, error) {
	rows, err := r.db.Query(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	list, err := pgx.CollectRows(rows, pgx.RowToStructByName[vacancyRow])
	if err != nil {
		return nil, err
	}

	items := make([]model.Vacancy, 0, len(list))
	for _, row := range list {
		items = append(items, row.toModel())
	}
	return items, nil
}

// escapeLike экранирует спецсимволы ILIKE, иначе q=% находит всё.
// Сам слэш тоже экранируется: у Postgres он escape-символ ILIKE по умолчанию.
func escapeLike(s string) string {
	return likeEscaper.Replace(s)
}

var likeEscaper = strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)

// buildSearchWhere общий для выборки и count(*), чтобы total не расходился с items.
// В условиях $n — заглушка номера: add подставляет позицию аргумента.
func buildSearchWhere(f model.VacancyFilter) (string, []any) {
	var conds []string
	var args []any
	add := func(cond string, arg any) {
		args = append(args, arg)
		conds = append(conds, strings.ReplaceAll(cond, "$n", "$"+strconv.Itoa(len(args))))
	}

	if f.Status != "" {
		add(`v.status = $n`, string(f.Status))
	}
	if f.Query != "" {
		add(`(v.title ILIKE $n OR v.description ILIKE $n)`, "%"+escapeLike(f.Query)+"%")
	}
	if f.City != "" {
		add(`lower(v.city) = lower($n)`, f.City)
	}
	if f.EmploymentType != "" {
		add(`v.employment_type = $n`, string(f.EmploymentType))
	}
	if f.SalaryFrom != nil {
		// Вилка подходит, если её верхняя граница не ниже желаемой; без верхней — смотрим нижнюю.
		add(`COALESCE(v.salary_to, v.salary_from) >= $n`, *f.SalaryFrom)
	}
	if len(f.Tags) > 0 {
		add(`v.tags @> $n`, f.Tags)
	}
	if len(conds) == 0 {
		return "", nil
	}
	return " WHERE " + strings.Join(conds, " AND "), args
}
