package redisrepo

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestSessionRepo(t *testing.T) {
	ctx := context.Background()
	session := &model.Session{ID: "sid", UserID: 42}
	stored := map[string]string{sessionKey("sid"): `{"user_id":42}`}

	tests := []struct {
		name      string
		prefill   map[string]string
		redisDown bool
		act       func(r *sessionRepo) error
		wantErr   error
	}{
		{
			name: "create then get",
			act: func(r *sessionRepo) error {
				require.NoError(t, r.Create(ctx, session, time.Hour))
				got, err := r.Get(ctx, "sid")
				require.Equal(t, session, got)
				return err
			},
		},
		{name: "get unknown session", act: func(r *sessionRepo) error { _, err := r.Get(ctx, "sid"); return err }, wantErr: model.ErrNotFound},
		{
			name:    "take is one-shot: second take finds nothing",
			prefill: stored,
			act: func(r *sessionRepo) error {
				require.NoError(t, r.Take(ctx, "sid"))
				return r.Take(ctx, "sid")
			},
			wantErr: model.ErrNotFound,
		},
		{
			name:    "deleted session is gone",
			prefill: stored,
			act: func(r *sessionRepo) error {
				require.NoError(t, r.Delete(ctx, "sid"))
				_, err := r.Get(ctx, "sid")
				return err
			},
			wantErr: model.ErrNotFound,
		},
		{name: "redis down on get is not «not found»", redisDown: true, act: func(r *sessionRepo) error { _, err := r.Get(ctx, "sid"); return err }, wantErr: errRedis},
		{name: "redis down on take is not «not found»", redisDown: true, act: func(r *sessionRepo) error { return r.Take(ctx, "sid") }, wantErr: errRedis},
		{name: "redis down on create", redisDown: true, act: func(r *sessionRepo) error { return r.Create(ctx, session, time.Hour) }, wantErr: errRedis},
		{name: "redis down on delete", redisDown: true, act: func(r *sessionRepo) error { return r.Delete(ctx, "sid") }, wantErr: errRedis},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			store := newMemCache()
			for k, v := range tt.prefill {
				store.data[k] = []byte(v)
			}
			if tt.redisDown {
				store.err = errRedis
			}

			err := tt.act(NewSessionRepo(store))

			if tt.wantErr == nil {
				require.NoError(t, err)
				return
			}
			require.ErrorIs(t, err, tt.wantErr)
			// Сбой Redis не должен превращаться в «сессии нет»: иначе пользователь получил бы 401 вместо 500.
			if tt.redisDown {
				require.NotErrorIs(t, err, model.ErrNotFound)
			}
		})
	}
}
