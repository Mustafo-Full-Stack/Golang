package pgrepo

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/pkg/database"
)

type resumeRepo struct {
	db database.DB
}

func NewResumeRepo(db database.DB) *resumeRepo {
	return &resumeRepo{db: db}
}

func (r *resumeRepo) Upsert(ctx context.Context, resume *model.Resume) error {
	err := r.db.QueryRow(ctx,
		`INSERT INTO resumes (applicant_id, title, about, city, experience_years, salary_expectation, skills)
		 VALUES ($1, $2, $3, $4, $5, $6, $7)
		 ON CONFLICT (applicant_id) DO UPDATE SET
		   title = EXCLUDED.title,
		   about = EXCLUDED.about,
		   city = EXCLUDED.city,
		   experience_years = EXCLUDED.experience_years,
		   salary_expectation = EXCLUDED.salary_expectation,
		   skills = EXCLUDED.skills,
		   updated_at = now()
		 RETURNING updated_at`,
		resume.ApplicantID, resume.Title, resume.About, resume.City, resume.ExperienceYears, resume.SalaryExpectation, nonNil(resume.Skills),
	).Scan(&resume.UpdatedAt)
	if err != nil {
		return fmt.Errorf("upsert resume: %w", err)
	}
	return nil
}

func (r *resumeRepo) GetByApplicant(ctx context.Context, applicantID int64) (*model.Resume, error) {
	rows, err := r.db.Query(ctx,
		`SELECT applicant_id, title, about, city, experience_years, salary_expectation, skills, updated_at
		 FROM resumes WHERE applicant_id = $1`, applicantID)
	if err != nil {
		return nil, fmt.Errorf("get resume: %w", err)
	}
	row, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[resumeRow])
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, model.NotFound("resume")
		}
		return nil, fmt.Errorf("get resume: %w", err)
	}
	resume := row.toModel()
	return &resume, nil
}

func (r *resumeRepo) Delete(ctx context.Context, applicantID int64) error {
	tag, err := r.db.Exec(ctx, `DELETE FROM resumes WHERE applicant_id = $1`, applicantID)
	if err != nil {
		return fmt.Errorf("delete resume: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return model.NotFound("resume")
	}
	return nil
}
