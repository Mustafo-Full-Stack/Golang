package redisrepo

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository"
	"github.com/rabboni171/job-board/pkg/cache"
)

// tombstone кладётся вместо карточки удалённой вакансии, чтобы запоздалый читатель не вернул её из Postgres-снимка.
const tombstone = "deleted"

type CacheTTL struct {
	VacancyTTL time.Duration
	SearchTTL  time.Duration
}

type cachedVacancyRepo struct {
	next  repository.VacancyRepository
	cache cache.Cache
	ttl   CacheTTL
	log   *slog.Logger
}

func NewCachedVacancyRepo(next repository.VacancyRepository, store cache.Cache, ttl CacheTTL, log *slog.Logger) *cachedVacancyRepo {
	return &cachedVacancyRepo{next: next, cache: store, ttl: ttl, log: log}
}

func vacancyKey(id int64) string {
	return fmt.Sprintf("vacancy:%d", id)
}

func searchKey(f model.VacancyFilter) (string, error) {
	b, err := json.Marshal(f)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(b)
	return "vacancies:search:" + hex.EncodeToString(sum[:]), nil
}

func (c *cachedVacancyRepo) GetByID(ctx context.Context, id int64) (*model.Vacancy, error) {
	key := vacancyKey(id)
	corrupted := false
	if raw, ok := c.getRaw(ctx, key); ok {
		if string(raw) == tombstone {
			return nil, model.NotFound("vacancy")
		}
		var cached model.Vacancy
		err := json.Unmarshal(raw, &cached)
		if err == nil {
			return &cached, nil
		}
		c.log.WarnContext(ctx, "cache unmarshal failed", "key", key, "err", err)
		corrupted = true
	}

	v, err := c.next.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if corrupted {
		// SetNX не заменил бы битое значение, и оно жило бы до TTL.
		c.setJSON(ctx, key, v, c.ttl.VacancyTTL)
		return v, nil
	}
	// Не перезаписываем значение, которое положил писатель: наш снимок из Postgres мог устареть.
	c.setJSONNX(ctx, key, v, c.ttl.VacancyTTL)
	return v, nil
}

func (c *cachedVacancyRepo) Search(ctx context.Context, f model.VacancyFilter) (*model.Paged[model.Vacancy], error) {
	key, err := searchKey(f)
	if err != nil {
		c.log.WarnContext(ctx, "build search cache key failed", "err", err)
		return c.next.Search(ctx, f)
	}

	var cached model.Paged[model.Vacancy]
	if c.getJSON(ctx, key, &cached) {
		return &cached, nil
	}

	result, err := c.next.Search(ctx, f)
	if err != nil {
		return nil, err
	}
	c.setJSON(ctx, key, result, c.ttl.SearchTTL)
	return result, nil
}

func (c *cachedVacancyRepo) ListByEmployer(ctx context.Context, employerID int64, p model.Page) (*model.Paged[model.Vacancy], error) {
	return c.next.ListByEmployer(ctx, employerID, p)
}

func (c *cachedVacancyRepo) Create(ctx context.Context, v *model.Vacancy) error {
	return c.next.Create(ctx, v)
}

func (c *cachedVacancyRepo) Update(ctx context.Context, v *model.Vacancy) error {
	err := c.next.Update(ctx, v)
	if err == nil || errors.Is(err, model.ErrConflict) {
		c.refresh(ctx, v.ID)
	}
	return err
}

func (c *cachedVacancyRepo) UpdateStatus(ctx context.Context, v *model.Vacancy) error {
	err := c.next.UpdateStatus(ctx, v)
	if err == nil || errors.Is(err, model.ErrConflict) {
		c.refresh(ctx, v.ID)
	}
	return err
}

func (c *cachedVacancyRepo) Delete(ctx context.Context, id int64) error {
	if err := c.next.Delete(ctx, id); err != nil {
		return err
	}
	c.putVacancy(ctx, id, []byte(tombstone))
	return nil
}

// refresh вызывается и после конфликта версии: решение было принято по устаревшей карточке,
// и без перечитывания повторный запрос получал бы тот же конфликт до истечения TTL.
// Значение берём из БД после коммита, а не из памяти запроса, чтобы параллельный писатель не затёр более новое состояние старым.
func (c *cachedVacancyRepo) refresh(ctx context.Context, id int64) {
	fresh, err := c.next.GetByID(ctx, id)
	if errors.Is(err, model.ErrNotFound) {
		c.putVacancy(ctx, id, []byte(tombstone))
		return
	}
	if err != nil {
		c.log.WarnContext(ctx, "reread vacancy failed", "id", id, "err", err)
		c.invalidate(ctx, id)
		return
	}
	data, err := json.Marshal(fresh)
	if err != nil {
		c.log.WarnContext(ctx, "cache marshal failed", "id", id, "err", err)
		c.invalidate(ctx, id)
		return
	}
	c.putVacancy(ctx, id, data)
}

// Без Del при ошибке записи в кэше осталась бы старая карточка до TTL.
func (c *cachedVacancyRepo) putVacancy(ctx context.Context, id int64, data []byte) {
	key := vacancyKey(id)
	if err := c.cache.Set(ctx, key, data, c.ttl.VacancyTTL); err != nil {
		c.log.WarnContext(ctx, "cache set failed", "key", key, "err", err)
		c.invalidate(ctx, id)
	}
}

func (c *cachedVacancyRepo) invalidate(ctx context.Context, id int64) {
	key := vacancyKey(id)
	if err := c.cache.Del(ctx, key); err != nil {
		c.log.WarnContext(ctx, "cache del failed", "key", key, "err", err)
	}
}

func (c *cachedVacancyRepo) getRaw(ctx context.Context, key string) ([]byte, bool) {
	data, err := c.cache.Get(ctx, key)
	if err != nil {
		if !errors.Is(err, cache.ErrNotFound) {
			c.log.WarnContext(ctx, "cache get failed", "key", key, "err", err)
		}
		return nil, false
	}
	return data, true
}

func (c *cachedVacancyRepo) getJSON(ctx context.Context, key string, dst any) bool {
	data, ok := c.getRaw(ctx, key)
	if !ok {
		return false
	}
	if err := json.Unmarshal(data, dst); err != nil {
		c.log.WarnContext(ctx, "cache unmarshal failed", "key", key, "err", err)
		return false
	}
	return true
}

func (c *cachedVacancyRepo) setJSON(ctx context.Context, key string, val any, ttl time.Duration) {
	data, err := json.Marshal(val)
	if err != nil {
		c.log.WarnContext(ctx, "cache marshal failed", "key", key, "err", err)
		return
	}
	if err := c.cache.Set(ctx, key, data, ttl); err != nil {
		c.log.WarnContext(ctx, "cache set failed", "key", key, "err", err)
	}
}

func (c *cachedVacancyRepo) setJSONNX(ctx context.Context, key string, val any, ttl time.Duration) {
	data, err := json.Marshal(val)
	if err != nil {
		c.log.WarnContext(ctx, "cache marshal failed", "key", key, "err", err)
		return
	}
	if _, err := c.cache.SetNX(ctx, key, data, ttl); err != nil {
		c.log.WarnContext(ctx, "cache setnx failed", "key", key, "err", err)
	}
}
