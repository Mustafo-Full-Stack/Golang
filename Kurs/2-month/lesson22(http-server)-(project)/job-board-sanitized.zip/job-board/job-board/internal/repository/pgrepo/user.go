package pgrepo

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/pkg/database"
)

type userRepo struct {
	db database.DB
}

func NewUserRepo(db database.DB) *userRepo {
	return &userRepo{db: db}
}

func (r *userRepo) Create(ctx context.Context, u *model.User) error {
	err := r.db.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, name, role)
		 VALUES ($1, $2, $3, $4)
		 RETURNING id, created_at`,
		u.Email, u.PasswordHash, u.Name, string(u.Role),
	).Scan(&u.ID, &u.CreatedAt)
	if err != nil {
		if isUniqueViolation(err) {
			return model.Conflict("email already registered")
		}
		return fmt.Errorf("create user: %w", err)
	}
	return nil
}

func (r *userRepo) GetByID(ctx context.Context, id int64) (*model.User, error) {
	rows, err := r.db.Query(ctx,
		`SELECT id, email, password_hash, name, role, created_at
		 FROM users WHERE id = $1`, id)
	if err != nil {
		return nil, fmt.Errorf("get user by id: %w", err)
	}
	row, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[userRow])
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, model.NotFound("user")
		}
		return nil, fmt.Errorf("get user by id: %w", err)
	}
	u := row.toModel()
	return &u, nil
}

func (r *userRepo) GetByEmail(ctx context.Context, email string) (*model.User, error) {
	rows, err := r.db.Query(ctx,
		`SELECT id, email, password_hash, name, role, created_at
		 FROM users WHERE email = $1`, email)
	if err != nil {
		return nil, fmt.Errorf("get user by email: %w", err)
	}
	row, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[userRow])
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, model.NotFound("user")
		}
		return nil, fmt.Errorf("get user by email: %w", err)
	}
	u := row.toModel()
	return &u, nil
}
