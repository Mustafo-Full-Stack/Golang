package pgrepo

import (
	"time"

	"github.com/rabboni171/job-board/internal/model"
)

// Структуры строк сопоставляются с колонками по имени (pgx.RowToStructByName),
// поэтому порядок колонок в SELECT не важен, а алиасы должны совпадать с тегами.

type userRow struct {
	ID           int64      `db:"id"`
	Email        string     `db:"email"`
	PasswordHash string     `db:"password_hash"`
	Name         string     `db:"name"`
	Role         model.Role `db:"role"`
	CreatedAt    time.Time  `db:"created_at"`
}

func (r userRow) toModel() model.User {
	return model.User{
		ID:           r.ID,
		Email:        r.Email,
		PasswordHash: r.PasswordHash,
		Name:         r.Name,
		Role:         r.Role,
		CreatedAt:    r.CreatedAt,
	}
}

type vacancyRow struct {
	ID             int64                `db:"id"`
	EmployerID     int64                `db:"employer_id"`
	EmployerName   string               `db:"employer_name"`
	Title          string               `db:"title"`
	Description    string               `db:"description"`
	City           string               `db:"city"`
	EmploymentType model.EmploymentType `db:"employment_type"`
	SalaryFrom     *int                 `db:"salary_from"`
	SalaryTo       *int                 `db:"salary_to"`
	Tags           []string             `db:"tags"`
	Status         model.VacancyStatus  `db:"status"`
	CreatedAt      time.Time            `db:"created_at"`
	UpdatedAt      time.Time            `db:"updated_at"`
}

func (r vacancyRow) toModel() model.Vacancy {
	return model.Vacancy{
		ID:             r.ID,
		EmployerID:     r.EmployerID,
		EmployerName:   r.EmployerName,
		Title:          r.Title,
		Description:    r.Description,
		City:           r.City,
		EmploymentType: r.EmploymentType,
		SalaryFrom:     r.SalaryFrom,
		SalaryTo:       r.SalaryTo,
		Tags:           nonNil(r.Tags),
		Status:         r.Status,
		CreatedAt:      r.CreatedAt,
		UpdatedAt:      r.UpdatedAt,
	}
}

type resumeRow struct {
	ApplicantID       int64     `db:"applicant_id"`
	Title             string    `db:"title"`
	About             string    `db:"about"`
	City              string    `db:"city"`
	ExperienceYears   int       `db:"experience_years"`
	SalaryExpectation *int      `db:"salary_expectation"`
	Skills            []string  `db:"skills"`
	UpdatedAt         time.Time `db:"updated_at"`
}

func (r resumeRow) toModel() model.Resume {
	return model.Resume{
		ApplicantID:       r.ApplicantID,
		Title:             r.Title,
		About:             r.About,
		City:              r.City,
		ExperienceYears:   r.ExperienceYears,
		SalaryExpectation: r.SalaryExpectation,
		Skills:            nonNil(r.Skills),
		UpdatedAt:         r.UpdatedAt,
	}
}

type applicationRow struct {
	ID          int64                   `db:"id"`
	VacancyID   int64                   `db:"vacancy_id"`
	ApplicantID int64                   `db:"applicant_id"`
	CoverLetter string                  `db:"cover_letter"`
	Status      model.ApplicationStatus `db:"status"`
	CreatedAt   time.Time               `db:"created_at"`
	UpdatedAt   time.Time               `db:"updated_at"`
}

func (r applicationRow) toModel() model.Application {
	return model.Application{
		ID:          r.ID,
		VacancyID:   r.VacancyID,
		ApplicantID: r.ApplicantID,
		CoverLetter: r.CoverLetter,
		Status:      r.Status,
		CreatedAt:   r.CreatedAt,
		UpdatedAt:   r.UpdatedAt,
	}
}

// applicationWithResumeRow: поля резюме — указатели, т.к. резюме берётся LEFT JOIN
// и может отсутствовать (соискатель удалил его после отклика).
type applicationWithResumeRow struct {
	applicationRow
	ApplicantName           string     `db:"applicant_name"`
	ResumeApplicantID       *int64     `db:"resume_applicant_id"`
	ResumeTitle             *string    `db:"resume_title"`
	ResumeAbout             *string    `db:"resume_about"`
	ResumeCity              *string    `db:"resume_city"`
	ResumeExperienceYears   *int       `db:"resume_experience_years"`
	ResumeSalaryExpectation *int       `db:"resume_salary_expectation"`
	ResumeSkills            []string   `db:"resume_skills"`
	ResumeUpdatedAt         *time.Time `db:"resume_updated_at"`
}

func (r applicationWithResumeRow) toModel() model.ApplicationWithResume {
	it := model.ApplicationWithResume{
		Application:   r.applicationRow.toModel(),
		ApplicantName: r.ApplicantName,
	}
	// остальные resume_* колонки NOT NULL в resumes, так что nil только у всей группы сразу
	if r.ResumeApplicantID != nil {
		it.Resume = &model.Resume{
			ApplicantID:       *r.ResumeApplicantID,
			Title:             *r.ResumeTitle,
			About:             *r.ResumeAbout,
			City:              *r.ResumeCity,
			ExperienceYears:   *r.ResumeExperienceYears,
			SalaryExpectation: r.ResumeSalaryExpectation,
			Skills:            nonNil(r.ResumeSkills),
			UpdatedAt:         *r.ResumeUpdatedAt,
		}
	}
	return it
}

type applicationWithVacancyRow struct {
	applicationRow
	VacancyTitle  string              `db:"vacancy_title"`
	EmployerName  string              `db:"employer_name"`
	VacancyStatus model.VacancyStatus `db:"vacancy_status"`
}

func (r applicationWithVacancyRow) toModel() model.ApplicationWithVacancy {
	return model.ApplicationWithVacancy{
		Application:   r.applicationRow.toModel(),
		VacancyTitle:  r.VacancyTitle,
		EmployerName:  r.EmployerName,
		VacancyStatus: r.VacancyStatus,
	}
}
