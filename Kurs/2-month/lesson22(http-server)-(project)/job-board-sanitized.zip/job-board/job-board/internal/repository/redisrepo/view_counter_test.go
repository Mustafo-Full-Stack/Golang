package redisrepo

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestViewCounter(t *testing.T) {
	ctx := context.Background()
	const vacancyID, viewerID = int64(10), int64(7)
	counter, mark := viewCountKey(vacancyID), viewMarkKey(vacancyID, viewerID)
	seenOnce := map[string]string{mark: "1", counter: "5"} // пользователь 7 уже смотрел, всего 5 просмотров

	tests := []struct {
		name        string
		prefill     map[string]string
		redisDown   bool
		act         func(c *viewCounter) int64
		want        int64
		wantCounter string // значение счётчика после операции; "" — ключа нет
	}{
		{name: "first view is counted", act: func(c *viewCounter) int64 { return c.Hit(ctx, vacancyID, viewerID) }, want: 1, wantCounter: "1"},
		{name: "repeat view within an hour is not counted", prefill: seenOnce, act: func(c *viewCounter) int64 { return c.Hit(ctx, vacancyID, viewerID) }, want: 5, wantCounter: "5"},
		{name: "view of another user is counted", prefill: seenOnce, act: func(c *viewCounter) int64 { return c.Hit(ctx, vacancyID, viewerID+1) }, want: 6, wantCounter: "6"},
		{name: "count does not add a view", prefill: seenOnce, act: func(c *viewCounter) int64 { return c.Count(ctx, vacancyID) }, want: 5, wantCounter: "5"},
		{name: "count without views", act: func(c *viewCounter) int64 { return c.Count(ctx, vacancyID) }, want: 0},
		{name: "corrupted counter degrades to 0", prefill: map[string]string{counter: "abc"}, act: func(c *viewCounter) int64 { return c.Count(ctx, vacancyID) }, want: 0, wantCounter: "abc"},
		{name: "redis down: hit degrades to 0", redisDown: true, act: func(c *viewCounter) int64 { return c.Hit(ctx, vacancyID, viewerID) }, want: 0},
		{name: "redis down: count degrades to 0", redisDown: true, act: func(c *viewCounter) int64 { return c.Count(ctx, vacancyID) }, want: 0},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			store := newMemCache()
			for k, v := range tt.prefill {
				store.data[k] = []byte(v)
			}
			if tt.redisDown {
				store.err = errRedis
			}

			got := tt.act(NewViewCounter(store, discardLog()))

			require.Equal(t, tt.want, got)
			require.Equal(t, tt.wantCounter, string(store.data[counter]))
		})
	}
}
