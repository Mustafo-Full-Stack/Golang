package pgrepo

import (
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
)

func TestEscapeLike(t *testing.T) {
	tests := []struct{ name, in, want string }{
		{"plain", "go dev", "go dev"},
		{"percent", "100%", `100\%`},
		{"underscore", "a_b", `a\_b`},
		{"backslash", `a\b`, `a\\b`},
		{"all", `\%_`, `\\\%\_`},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			require.Equal(t, tt.want, escapeLike(tt.in))
		})
	}
}

func TestApplicationWithResumeRow_toModel(t *testing.T) {
	now := time.Now()
	id, years, salary := int64(3), 5, 100
	title, about, city := "Go dev", "about", "Almaty"
	base := applicationWithResumeRow{
		ID: 1, VacancyID: 2, ApplicantID: 3, Status: model.ApplicationNew,
		ApplicantName: "Ann",
	}
	withResume := base
	withResume.ResumeApplicantID, withResume.ResumeTitle, withResume.ResumeAbout, withResume.ResumeCity = &id, &title, &about, &city
	withResume.ResumeExperienceYears, withResume.ResumeSalaryExpectation, withResume.ResumeUpdatedAt = &years, &salary, &now
	application := model.Application{ID: 1, VacancyID: 2, ApplicantID: 3, Status: model.ApplicationNew}

	tests := []struct {
		name string
		row  applicationWithResumeRow
		want model.ApplicationWithResume
	}{
		{
			name: "resume deleted after applying: LEFT JOIN gives NULLs",
			row:  base,
			want: model.ApplicationWithResume{Application: application, ApplicantName: "Ann"},
		},
		{
			name: "resume present",
			row:  withResume,
			want: model.ApplicationWithResume{Application: application, ApplicantName: "Ann", Resume: &model.Resume{
				ApplicantID: 3, Title: title, About: about, City: city, ExperienceYears: 5,
				SalaryExpectation: &salary, Skills: []string{}, UpdatedAt: now,
			}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			require.Equal(t, tt.want, tt.row.toModel())
		})
	}
}

func TestBuildSearchWhere(t *testing.T) {
	salary := 100
	tests := []struct {
		name      string
		filter    model.VacancyFilter
		wantWhere string
		wantArgs  []any
	}{
		{name: "empty filter has no where and no args", filter: model.VacancyFilter{}, wantWhere: "", wantArgs: nil},
		{
			name:      "status is filtered only when set",
			filter:    model.VacancyFilter{Status: model.VacancyOpen},
			wantWhere: " WHERE v.status = $1",
			wantArgs:  []any{"open"},
		},
		{
			name:      "query is escaped and reused for title and description",
			filter:    model.VacancyFilter{Query: "100%"},
			wantWhere: " WHERE (v.title ILIKE $1 OR v.description ILIKE $1)",
			wantArgs:  []any{`%100\%%`},
		},
		{
			name: "all conditions are numbered in order",
			filter: model.VacancyFilter{
				Status: model.VacancyClosed, City: "Almaty", EmploymentType: model.EmploymentRemote,
				SalaryFrom: &salary, Tags: []string{"go"},
			},
			wantWhere: " WHERE v.status = $1 AND lower(v.city) = lower($2) AND v.employment_type = $3" +
				" AND COALESCE(v.salary_to, v.salary_from) >= $4 AND v.tags @> $5",
			wantArgs: []any{"closed", "Almaty", "remote", 100, []string{"go"}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			where, args := buildSearchWhere(tt.filter)

			require.Equal(t, tt.wantWhere, where)
			require.Equal(t, tt.wantArgs, args)
		})
	}
}
