package redisrepo

import (
	"context"
	"encoding/json"
	"errors"
	"testing"
	"time"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/internal/repository/mocks"
)

var (
	errRedis = errors.New("redis is down")
	errDB    = errors.New("db is down")
)

func TestCachedVacancyRepo(t *testing.T) {
	ctx := context.Background()
	fromDB := &model.Vacancy{ID: 1, Status: model.VacancyOpen, Title: "from db"}
	closed := &model.Vacancy{ID: 1, Status: model.VacancyClosed, Title: "from db"}
	stale := &model.Vacancy{ID: 1, Status: model.VacancyOpen, Title: "stale"}
	key := vacancyKey(1)

	tests := []struct {
		name    string
		setup   func(next *mocks.VacancyRepository, store *memCache) // моки строгие: лишний поход в БД валит тест
		act     func(repo *cachedVacancyRepo) error
		wantErr error
		want    *model.Vacancy // что лежит в кэше после операции; nil — проверяем cached
		cached  string         // сырое значение в кэше, если want == nil
		dropped bool           // ключа в кэше быть не должно
	}{
		{
			name: "get: miss reads db and fills cache",
			setup: func(next *mocks.VacancyRepository, _ *memCache) {
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(fromDB, nil).Once()
			},
			act:  func(repo *cachedVacancyRepo) error { _, err := repo.GetByID(ctx, 1); return err },
			want: fromDB,
		},
		{
			name:  "get: hit does not touch db",
			setup: func(_ *mocks.VacancyRepository, store *memCache) { store.data[key] = mustJSON(t, fromDB) },
			act: func(repo *cachedVacancyRepo) error {
				got, err := repo.GetByID(ctx, 1)
				require.Equal(t, fromDB, got)
				return err
			},
			want: fromDB,
		},
		{
			name:    "get: tombstone means deleted, db is not asked",
			setup:   func(_ *mocks.VacancyRepository, store *memCache) { store.data[key] = []byte(tombstone) },
			act:     func(repo *cachedVacancyRepo) error { _, err := repo.GetByID(ctx, 1); return err },
			wantErr: model.ErrNotFound,
			cached:  tombstone,
		},
		{
			name: "get: corrupted value is replaced",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = []byte("{broken")
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(fromDB, nil).Once()
			},
			act:  func(repo *cachedVacancyRepo) error { _, err := repo.GetByID(ctx, 1); return err },
			want: fromDB,
		},
		{
			name: "get: does not overwrite value written by a concurrent writer",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				// Писатель успевает записать tombstone, пока читатель держит старый снимок из Postgres.
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(fromDB, nil).
					Run(func(context.Context, int64) { store.data[key] = []byte(tombstone) }).Once()
			},
			act:    func(repo *cachedVacancyRepo) error { _, err := repo.GetByID(ctx, 1); return err },
			cached: tombstone,
		},
		{
			name: "get: redis down falls back to db",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.err = errRedis
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(fromDB, nil).Once()
			},
			act: func(repo *cachedVacancyRepo) error {
				got, err := repo.GetByID(ctx, 1)
				require.Equal(t, fromDB, got)
				return err
			},
		},
		{
			name: "get: db error is passed through",
			setup: func(next *mocks.VacancyRepository, _ *memCache) {
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(nil, errDB)
			},
			act:     func(repo *cachedVacancyRepo) error { _, err := repo.GetByID(ctx, 1); return err },
			wantErr: errDB,
		},
		{
			name: "update caches the re-read value, not the request",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, stale)
				next.EXPECT().Update(mock.Anything, mock.Anything).Return(nil)
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(fromDB, nil).Once()
			},
			act: func(repo *cachedVacancyRepo) error {
				return repo.Update(ctx, &model.Vacancy{ID: 1, Title: "from request"})
			},
			want: fromDB,
		},
		{
			name: "update of a vacancy deleted meanwhile leaves tombstone",
			setup: func(next *mocks.VacancyRepository, _ *memCache) {
				next.EXPECT().Update(mock.Anything, mock.Anything).Return(nil)
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(nil, model.NotFound("vacancy")).Once()
			},
			act:    func(repo *cachedVacancyRepo) error { return repo.Update(ctx, &model.Vacancy{ID: 1}) },
			cached: tombstone,
		},
		{
			name: "failed update keeps the cache",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, stale)
				next.EXPECT().Update(mock.Anything, mock.Anything).Return(errDB)
			},
			act:     func(repo *cachedVacancyRepo) error { return repo.Update(ctx, &model.Vacancy{ID: 1}) },
			wantErr: errDB,
			want:    stale,
		},
		{
			name: "update conflict refreshes the stale cache from db",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, stale)
				next.EXPECT().Update(mock.Anything, mock.Anything).Return(model.Conflict("vacancy was changed, try again"))
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(fromDB, nil).Once()
			},
			act:     func(repo *cachedVacancyRepo) error { return repo.Update(ctx, &model.Vacancy{ID: 1}) },
			wantErr: model.ErrConflict,
			want:    fromDB,
		},
		{
			name: "update status rewrites cache with the re-read value",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, fromDB)
				next.EXPECT().UpdateStatus(mock.Anything, mock.Anything).Return(nil)
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(closed, nil).Once()
			},
			act: func(repo *cachedVacancyRepo) error {
				return repo.UpdateStatus(ctx, &model.Vacancy{ID: 1, Status: model.VacancyClosed})
			},
			want: closed,
		},
		{
			name: "update status conflict refreshes the stale cache from db",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, stale)
				next.EXPECT().UpdateStatus(mock.Anything, mock.Anything).Return(model.Conflict("vacancy was changed, try again"))
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(closed, nil).Once()
			},
			act: func(repo *cachedVacancyRepo) error {
				return repo.UpdateStatus(ctx, &model.Vacancy{ID: 1, Status: model.VacancyClosed})
			},
			wantErr: model.ErrConflict,
			want:    closed,
		},
		{
			name: "failed update status keeps the cache",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, fromDB)
				next.EXPECT().UpdateStatus(mock.Anything, mock.Anything).Return(errDB)
			},
			act:     func(repo *cachedVacancyRepo) error { return repo.UpdateStatus(ctx, &model.Vacancy{ID: 1}) },
			wantErr: errDB,
			want:    fromDB,
		},
		{
			name: "update status: re-read failure drops the stale value",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, fromDB)
				next.EXPECT().UpdateStatus(mock.Anything, mock.Anything).Return(nil)
				next.EXPECT().GetByID(mock.Anything, int64(1)).Return(nil, errDB).Once()
			},
			act:     func(repo *cachedVacancyRepo) error { return repo.UpdateStatus(ctx, &model.Vacancy{ID: 1}) },
			dropped: true,
		},
		{
			name: "delete leaves tombstone",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, fromDB)
				next.EXPECT().Delete(mock.Anything, int64(1)).Return(nil)
			},
			act:    func(repo *cachedVacancyRepo) error { return repo.Delete(ctx, 1) },
			cached: tombstone,
		},
		{
			name: "failed delete keeps the cache",
			setup: func(next *mocks.VacancyRepository, store *memCache) {
				store.data[key] = mustJSON(t, fromDB)
				next.EXPECT().Delete(mock.Anything, int64(1)).Return(model.Conflict("vacancy has applications"))
			},
			act:     func(repo *cachedVacancyRepo) error { return repo.Delete(ctx, 1) },
			wantErr: model.ErrConflict,
			want:    fromDB,
		},
		{
			name: "search: second identical query is served from cache",
			setup: func(next *mocks.VacancyRepository, _ *memCache) {
				next.EXPECT().Search(mock.Anything, mock.Anything).Return(&model.Paged[model.Vacancy]{Items: []model.Vacancy{*fromDB}, Total: 1}, nil).Once()
			},
			act: func(repo *cachedVacancyRepo) error {
				f := model.VacancyFilter{Query: "go", Page: model.Page{Limit: 20}}
				first, err := repo.Search(ctx, f)
				require.NoError(t, err)
				second, err := repo.Search(ctx, f)
				require.Equal(t, first, second)
				return err
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			next, store := mocks.NewVacancyRepository(t), newMemCache()
			tt.setup(next, store)
			repo := NewCachedVacancyRepo(next, store, CacheTTL{VacancyTTL: time.Minute, SearchTTL: time.Minute}, discardLog())

			err := tt.act(repo)

			require.ErrorIs(t, err, tt.wantErr)
			raw, ok := store.data[key]
			switch {
			case tt.want != nil:
				require.True(t, ok, "vacancy is not cached")
				var got model.Vacancy
				require.NoError(t, json.Unmarshal(raw, &got))
				require.Equal(t, *tt.want, got)
			case tt.cached != "":
				require.Equal(t, tt.cached, string(raw))
			case tt.dropped:
				require.False(t, ok, "stale value must be dropped")
			}
		})
	}
}

func mustJSON(t *testing.T, v any) []byte {
	t.Helper()
	b, err := json.Marshal(v)
	require.NoError(t, err)
	return b
}
