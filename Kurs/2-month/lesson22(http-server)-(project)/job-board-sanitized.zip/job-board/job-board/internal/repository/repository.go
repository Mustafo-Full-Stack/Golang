package repository

import (
	"context"
	"time"

	"github.com/rabboni171/job-board/internal/model"
)

// Репозитории — простой SQL без бизнес-условий (списки — count + выборка): все решения принимает сервис.
//
// Update/UpdateStatus/Delete с моделью на входе — optimistic lock: строка меняется, только если
// её updated_at совпадает с прочитанным сервисом (никто не изменил её после чтения),
// иначе model.ErrConflict. Так решение сервиса не применится к устаревшим данным.

type UserRepository interface {
	Create(ctx context.Context, u *model.User) error
	GetByEmail(ctx context.Context, email string) (*model.User, error)
	GetByID(ctx context.Context, id int64) (*model.User, error)
}

type VacancyReader interface {
	GetByID(ctx context.Context, id int64) (*model.Vacancy, error)
	Search(ctx context.Context, f model.VacancyFilter) (*model.Paged[model.Vacancy], error)
	ListByEmployer(ctx context.Context, employerID int64, p model.Page) (*model.Paged[model.Vacancy], error)
}

type VacancyWriter interface {
	Create(ctx context.Context, v *model.Vacancy) error
	// Update сохраняет поля вакансии, кроме статуса.
	Update(ctx context.Context, v *model.Vacancy) error
	UpdateStatus(ctx context.Context, v *model.Vacancy) error
	Delete(ctx context.Context, id int64) error
}

type VacancyRepository interface {
	VacancyReader
	VacancyWriter
}

type ResumeRepository interface {
	Upsert(ctx context.Context, r *model.Resume) error
	GetByApplicant(ctx context.Context, applicantID int64) (*model.Resume, error)
	Delete(ctx context.Context, applicantID int64) error
}

type ApplicationReader interface {
	GetByID(ctx context.Context, id int64) (*model.Application, error)
	ExistsByVacancy(ctx context.Context, vacancyID int64) (bool, error)
	// ListByVacancy: пустой status — отклики в любом статусе.
	ListByVacancy(ctx context.Context, vacancyID int64, status model.ApplicationStatus, p model.Page) (*model.Paged[model.ApplicationWithResume], error)
	ListByApplicant(ctx context.Context, applicantID int64, p model.Page) (*model.Paged[model.ApplicationWithVacancy], error)
}

type ApplicationWriter interface {
	Create(ctx context.Context, a *model.Application) error
	UpdateStatus(ctx context.Context, a *model.Application) error
	Delete(ctx context.Context, a *model.Application) error
}

type ApplicationRepository interface {
	ApplicationReader
	ApplicationWriter
}

type ViewCounter interface {
	// Hit засчитывает просмотр и возвращает их число; при недоступном хранилище — 0.
	Hit(ctx context.Context, vacancyID, userID int64) int64
	// Count возвращает число просмотров без засчитывания; при недоступном хранилище — 0.
	Count(ctx context.Context, vacancyID int64) int64
}

type SessionReader interface {
	Get(ctx context.Context, id string) (*model.Session, error)
}

type SessionWriter interface {
	Create(ctx context.Context, s *model.Session, ttl time.Duration) error
	// Take атомарно читает и удаляет сессию: повторно забрать её нельзя.
	Take(ctx context.Context, id string) error
	Delete(ctx context.Context, id string) error
}

type SessionRepository interface {
	SessionReader
	SessionWriter
}
