package redisrepo

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strconv"
	"time"

	"github.com/rabboni171/job-board/pkg/cache"
)

const viewedTTL = time.Hour

type viewCounter struct {
	cache cache.Cache
	log   *slog.Logger
}

func NewViewCounter(store cache.Cache, log *slog.Logger) *viewCounter {
	return &viewCounter{cache: store, log: log}
}

func viewCountKey(vacancyID int64) string {
	return fmt.Sprintf("vacancy:views:%d", vacancyID)
}

func viewMarkKey(vacancyID, userID int64) string {
	return fmt.Sprintf("vacancy:viewed:%d:%d", vacancyID, userID)
}

// Просмотры живут только в Redis и не критичны: при его сбое пишем WARN и отдаём 0,
// чтобы не ломать просмотр вакансии.
func (c *viewCounter) Hit(ctx context.Context, vacancyID, userID int64) int64 {
	n, err := c.hit(ctx, vacancyID, userID)
	if err != nil {
		c.log.WarnContext(ctx, "view counter failed", "vacancy_id", vacancyID, "err", err)
		return 0
	}
	return n
}

func (c *viewCounter) Count(ctx context.Context, vacancyID int64) int64 {
	n, err := c.count(ctx, vacancyID)
	if err != nil {
		c.log.WarnContext(ctx, "view counter failed", "vacancy_id", vacancyID, "err", err)
		return 0
	}
	return n
}

func (c *viewCounter) count(ctx context.Context, vacancyID int64) (int64, error) {
	raw, err := c.cache.Get(ctx, viewCountKey(vacancyID))
	if errors.Is(err, cache.ErrNotFound) {
		return 0, nil
	}
	if err != nil {
		return 0, fmt.Errorf("get vacancy views: %w", err)
	}
	n, err := strconv.ParseInt(string(raw), 10, 64)
	if err != nil {
		return 0, fmt.Errorf("parse vacancy views: %w", err)
	}
	return n, nil
}

// SET NX — «один просмотр на пользователя в час», INCR атомарен.
func (c *viewCounter) hit(ctx context.Context, vacancyID, userID int64) (int64, error) {
	created, err := c.cache.SetNX(ctx, viewMarkKey(vacancyID, userID), 1, viewedTTL)
	if err != nil {
		return 0, fmt.Errorf("mark vacancy viewed: %w", err)
	}

	if created {
		n, err := c.cache.Incr(ctx, viewCountKey(vacancyID))
		if err != nil {
			return 0, fmt.Errorf("incr vacancy views: %w", err)
		}
		return n, nil
	}

	return c.count(ctx, vacancyID)
}
