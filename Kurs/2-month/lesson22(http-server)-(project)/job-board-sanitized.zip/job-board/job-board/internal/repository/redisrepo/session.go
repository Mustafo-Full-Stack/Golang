package redisrepo

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/pkg/cache"
)

// Сессии не деградируют: без Redis нельзя ни проверить, ни отозвать токен,
// поэтому ошибки уходят наверх и здесь не логируются.
type sessionRepo struct {
	cache cache.Cache
}

func NewSessionRepo(store cache.Cache) *sessionRepo {
	return &sessionRepo{cache: store}
}

type sessionRecord struct {
	UserID int64 `json:"user_id"`
}

func sessionKey(id string) string { return "session:" + id }

func (r *sessionRepo) Create(ctx context.Context, s *model.Session, ttl time.Duration) error {
	raw, err := json.Marshal(sessionRecord{UserID: s.UserID})
	if err != nil {
		return fmt.Errorf("marshal session: %w", err)
	}
	if err := r.cache.Set(ctx, sessionKey(s.ID), raw, ttl); err != nil {
		return fmt.Errorf("save session: %w", err)
	}
	return nil
}

func (r *sessionRepo) Get(ctx context.Context, id string) (*model.Session, error) {
	raw, err := r.cache.Get(ctx, sessionKey(id))
	if err != nil {
		return nil, sessionReadErr("get", err)
	}
	return decodeSession(id, raw)
}

func (r *sessionRepo) Take(ctx context.Context, id string) error {
	if _, err := r.cache.GetDel(ctx, sessionKey(id)); err != nil {
		return sessionReadErr("take", err)
	}
	return nil
}

func (r *sessionRepo) Delete(ctx context.Context, id string) error {
	if err := r.cache.Del(ctx, sessionKey(id)); err != nil {
		return fmt.Errorf("delete session: %w", err)
	}
	return nil
}

func sessionReadErr(op string, err error) error {
	if errors.Is(err, cache.ErrNotFound) {
		return model.NotFound("session")
	}
	return fmt.Errorf("%s session: %w", op, err)
}

func decodeSession(id string, raw []byte) (*model.Session, error) {
	var rec sessionRecord
	if err := json.Unmarshal(raw, &rec); err != nil {
		return nil, fmt.Errorf("unmarshal session: %w", err)
	}
	return &model.Session{ID: id, UserID: rec.UserID}, nil
}
