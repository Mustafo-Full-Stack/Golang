package pgrepo

import (
	"errors"

	"github.com/jackc/pgx/v5/pgconn"
)

const (
	uniqueViolation     = "23505"
	foreignKeyViolation = "23503"
)

func isUniqueViolation(err error) bool { return hasCode(err, uniqueViolation) }

func isForeignKeyViolation(err error) bool { return hasCode(err, foreignKeyViolation) }

func hasCode(err error, code string) bool {
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == code
}

// nonNil — в БД колонки NOT NULL, а pgx кодирует nil-слайс как NULL
func nonNil(s []string) []string {
	if s == nil {
		return []string{}
	}
	return s
}
