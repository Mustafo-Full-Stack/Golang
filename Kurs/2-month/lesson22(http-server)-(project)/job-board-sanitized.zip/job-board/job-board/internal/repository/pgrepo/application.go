package pgrepo

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/rabboni171/job-board/internal/model"
	"github.com/rabboni171/job-board/pkg/database"
)

var errApplicationChanged = model.Conflict("application was changed, try again")

type applicationRepo struct {
	db database.DB
}

func NewApplicationRepo(db database.DB) *applicationRepo {
	return &applicationRepo{db: db}
}

func (r *applicationRepo) Create(ctx context.Context, a *model.Application) error {
	err := r.db.QueryRow(ctx,
		`INSERT INTO applications (vacancy_id, applicant_id, cover_letter, status)
		 VALUES ($1, $2, $3, $4)
		 RETURNING id, created_at, updated_at`,
		a.VacancyID, a.ApplicantID, a.CoverLetter, string(a.Status),
	).Scan(&a.ID, &a.CreatedAt, &a.UpdatedAt)
	if err != nil {
		if isUniqueViolation(err) {
			return model.Conflict("already applied to this vacancy")
		}
		// Вакансию удалили между проверкой в сервисе и вставкой.
		if isForeignKeyViolation(err) {
			return model.NotFound("vacancy")
		}
		return fmt.Errorf("create application: %w", err)
	}
	return nil
}

func (r *applicationRepo) GetByID(ctx context.Context, id int64) (*model.Application, error) {
	rows, err := r.db.Query(ctx,
		`SELECT id, vacancy_id, applicant_id, cover_letter, status, created_at, updated_at
		 FROM applications WHERE id = $1`, id)
	if err != nil {
		return nil, fmt.Errorf("get application: %w", err)
	}
	row, err := pgx.CollectOneRow(rows, pgx.RowToStructByName[applicationRow])
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, model.NotFound("application")
		}
		return nil, fmt.Errorf("get application: %w", err)
	}
	a := row.toModel()
	return &a, nil
}

func (r *applicationRepo) ExistsByVacancy(ctx context.Context, vacancyID int64) (bool, error) {
	var exists bool
	err := r.db.QueryRow(ctx,
		`SELECT EXISTS (SELECT 1 FROM applications WHERE vacancy_id = $1)`, vacancyID).Scan(&exists)
	if err != nil {
		return false, fmt.Errorf("check vacancy applications: %w", err)
	}
	return exists, nil
}

func (r *applicationRepo) UpdateStatus(ctx context.Context, a *model.Application) error {
	err := r.db.QueryRow(ctx,
		`UPDATE applications SET status = $3, updated_at = now()
		 WHERE id = $1 AND updated_at = $2
		 RETURNING updated_at`,
		a.ID, a.UpdatedAt, string(a.Status),
	).Scan(&a.UpdatedAt)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return errApplicationChanged
		}
		return fmt.Errorf("update application status: %w", err)
	}
	return nil
}

func (r *applicationRepo) Delete(ctx context.Context, a *model.Application) error {
	tag, err := r.db.Exec(ctx,
		`DELETE FROM applications WHERE id = $1 AND updated_at = $2`, a.ID, a.UpdatedAt)
	if err != nil {
		return fmt.Errorf("delete application: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return errApplicationChanged
	}
	return nil
}

func (r *applicationRepo) ListByVacancy(ctx context.Context, vacancyID int64, status model.ApplicationStatus, p model.Page) (*model.Paged[model.ApplicationWithResume], error) {
	where, args := ` WHERE a.vacancy_id = $1`, []any{vacancyID}
	if status != "" {
		where += ` AND a.status = $2`
		args = append(args, string(status))
	}

	var total int
	if err := r.db.QueryRow(ctx, `SELECT count(*) FROM applications a`+where, args...).Scan(&total); err != nil {
		return nil, fmt.Errorf("count applications: %w", err)
	}

	rows, err := r.db.Query(ctx,
		`SELECT a.id, a.vacancy_id, a.applicant_id, a.cover_letter, a.status, a.created_at, a.updated_at,
		        u.name AS applicant_name,
		        rs.applicant_id AS resume_applicant_id, rs.title AS resume_title, rs.about AS resume_about,
		        rs.city AS resume_city, rs.experience_years AS resume_experience_years,
		        rs.salary_expectation AS resume_salary_expectation, rs.skills AS resume_skills,
		        rs.updated_at AS resume_updated_at
		 FROM applications a
		 JOIN users u ON u.id = a.applicant_id
		 LEFT JOIN resumes rs ON rs.applicant_id = a.applicant_id`+where+
			fmt.Sprintf(` ORDER BY a.created_at DESC, a.id DESC LIMIT $%d OFFSET $%d`, len(args)+1, len(args)+2),
		append(args, p.Limit, p.Offset)...)
	if err != nil {
		return nil, fmt.Errorf("list applications by vacancy: %w", err)
	}
	list, err := pgx.CollectRows(rows, pgx.RowToStructByName[applicationWithResumeRow])
	if err != nil {
		return nil, fmt.Errorf("list applications by vacancy: %w", err)
	}

	items := make([]model.ApplicationWithResume, 0, len(list))
	for _, row := range list {
		items = append(items, row.toModel())
	}
	return &model.Paged[model.ApplicationWithResume]{Items: items, Total: total}, nil
}

func (r *applicationRepo) ListByApplicant(ctx context.Context, applicantID int64, p model.Page) (*model.Paged[model.ApplicationWithVacancy], error) {
	var total int
	if err := r.db.QueryRow(ctx, `SELECT count(*) FROM applications WHERE applicant_id = $1`,
		applicantID).Scan(&total); err != nil {
		return nil, fmt.Errorf("count applications: %w", err)
	}

	rows, err := r.db.Query(ctx,
		`SELECT a.id, a.vacancy_id, a.applicant_id, a.cover_letter, a.status, a.created_at, a.updated_at,
		        v.title AS vacancy_title, e.name AS employer_name, v.status AS vacancy_status
		 FROM applications a
		 JOIN vacancies v ON v.id = a.vacancy_id
		 JOIN users e ON e.id = v.employer_id
		 WHERE a.applicant_id = $1
		 ORDER BY a.created_at DESC, a.id DESC LIMIT $2 OFFSET $3`,
		applicantID, p.Limit, p.Offset)
	if err != nil {
		return nil, fmt.Errorf("list applications by applicant: %w", err)
	}
	list, err := pgx.CollectRows(rows, pgx.RowToStructByName[applicationWithVacancyRow])
	if err != nil {
		return nil, fmt.Errorf("list applications by applicant: %w", err)
	}

	items := make([]model.ApplicationWithVacancy, 0, len(list))
	for _, row := range list {
		items = append(items, row.toModel())
	}
	return &model.Paged[model.ApplicationWithVacancy]{Items: items, Total: total}, nil
}
