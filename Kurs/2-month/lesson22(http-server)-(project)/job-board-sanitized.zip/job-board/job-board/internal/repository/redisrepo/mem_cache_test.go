package redisrepo

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"strconv"
	"time"

	"github.com/rabboni171/job-board/pkg/cache"
)

// memCache — cache.Cache в памяти. err имитирует недоступный Redis: его возвращают все методы.
type memCache struct {
	data map[string][]byte
	err  error
}

func newMemCache() *memCache { return &memCache{data: map[string][]byte{}} }

func toBytes(v any) []byte {
	switch x := v.(type) {
	case []byte:
		return x
	case string:
		return []byte(x)
	default:
		return []byte(fmt.Sprint(x))
	}
}

func (m *memCache) Get(_ context.Context, key string) ([]byte, error) {
	if m.err != nil {
		return nil, m.err
	}
	v, ok := m.data[key]
	if !ok {
		return nil, cache.ErrNotFound
	}
	return v, nil
}

func (m *memCache) Set(_ context.Context, key string, value any, _ time.Duration) error {
	if m.err != nil {
		return m.err
	}
	m.data[key] = toBytes(value)
	return nil
}

func (m *memCache) SetNX(_ context.Context, key string, value any, _ time.Duration) (bool, error) {
	if m.err != nil {
		return false, m.err
	}
	if _, ok := m.data[key]; ok {
		return false, nil
	}
	m.data[key] = toBytes(value)
	return true, nil
}

func (m *memCache) Incr(_ context.Context, key string) (int64, error) {
	if m.err != nil {
		return 0, m.err
	}
	n, _ := strconv.ParseInt(string(m.data[key]), 10, 64)
	n++
	m.data[key] = []byte(strconv.FormatInt(n, 10))
	return n, nil
}

func (m *memCache) GetDel(ctx context.Context, key string) ([]byte, error) {
	v, err := m.Get(ctx, key)
	if err == nil {
		delete(m.data, key)
	}
	return v, err
}

func (m *memCache) Del(_ context.Context, keys ...string) error {
	if m.err != nil {
		return m.err
	}
	for _, k := range keys {
		delete(m.data, k)
	}
	return nil
}

func (m *memCache) Ping(context.Context) error { return m.err }
func (m *memCache) Close() error               { return nil }

func discardLog() *slog.Logger { return slog.New(slog.NewTextHandler(io.Discard, nil)) }
