# job-board

[![Go](https://img.shields.io/badge/Go-1.27-00ADD8?logo=go&logoColor=white)](https://go.dev/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-4169E1?logo=postgresql&logoColor=white)](https://www.postgresql.org/)
[![Redis](https://img.shields.io/badge/Redis-7-DC382D?logo=redis&logoColor=white)](https://redis.io/)
[![OpenAPI](https://img.shields.io/badge/OpenAPI-3-6BA539?logo=openapiinitiative&logoColor=white)](docs/openapi.yaml)

REST API биржи вакансий на Go. Работодатели публикуют вакансии и разбирают отклики, соискатели ведут резюме, ищут вакансии и откликаются.

## Содержание

- [О проекте](#о-проекте)
- [Возможности](#возможности)
- [Бизнес-модель](#бизнес-модель): сущности, связи в БД, роли, жизненные циклы
- [Стек](#стек)
- [Быстрый старт](#быстрый-старт)
- [Как устроен проект](#как-устроен-проект)
- [API](#api)
- [Аутентификация](#аутентификация)
- [Бизнес-правила](#бизнес-правила)
- [Кэш и Redis](#кэш-и-redis)
- [Конфигурация](#конфигурация)
- [Логи](#логи)
- [Разработка](#разработка)
- [Решение проблем](#решение-проблем)
- [Известные ограничения](#известные-ограничения)

---

## О проекте

**job-board** — бэкенд биржи вакансий. Он соединяет две стороны найма: компании публикуют вакансии и выбирают кандидатов, соискатели ищут работу и откликаются. Весь путь от публикации вакансии до приглашения на собеседование идёт через REST API.

| Роль | Кто это | Что может |
|---|---|---|
| `employer` — работодатель | компания или рекрутер | публикует, редактирует, закрывает и удаляет вакансии; смотрит отклики вместе с резюме; принимает решение по каждому отклику |
| `applicant` — соискатель | кандидат | ведёт одно резюме, ищет открытые вакансии, откликается с сопроводительным письмом, следит за статусом, отзывает непросмотренный отклик |

Роль выбирается при регистрации и больше не меняется. Она определяет, какие ручки доступны: ручка чужой роли отвечает `403`.

Процесс найма в пяти шагах (подробно — в разделе [Бизнес-модель](#бизнес-модель)):

1. Работодатель регистрируется и публикует вакансию — она сразу открыта и видна в поиске.
2. Соискатель регистрируется и заполняет резюме: без резюме откликнуться нельзя.
3. Соискатель находит вакансию в поиске, открывает карточку и откликается. Отклик получает статус `new`.
4. Работодатель видит отклик вместе с актуальным резюме и переводит его в `viewed`, `invited` или `rejected`.
5. Соискатель видит статусы своих откликов. Пока отклик `new`, его можно отозвать.

---

## Возможности

- Регистрация и вход: пара access/refresh JWT, обновление пары, выход с мгновенным отзывом токенов.
- Вакансии: создание, редактирование, закрытие, удаление, список своих вакансий.
- Поиск открытых вакансий по тексту, городу, типу занятости, тегам и зарплате, с пагинацией.
- Резюме соискателя (одно на пользователя) и отклики на вакансии.
- Статусы откликов `new → viewed → invited / rejected`, отзыв отклика соискателем.
- Счётчик уникальных просмотров вакансии, кэш карточки и поиска в Redis.
- Кэш и просмотры переживают недоступность Redis (ответы идут из Postgres). Сессии нет: без Redis защищённые ручки отвечают `500`.
- Swagger UI, health-check, структурные логи (`slog`) с `request_id`, CORS, graceful shutdown.

---

## Бизнес-модель

### Глоссарий

| Термин | Что это |
|---|---|
| **Работодатель** (`employer`) | Компания или рекрутер. Публикует вакансии и решает, кого пригласить. |
| **Соискатель** (`applicant`) | Человек, который ищет работу. Ведёт резюме и откликается на вакансии. |
| **Вакансия** | Объявление о работе: должность, описание, город, тип занятости, вилка зарплаты, теги. Бывает открытой (`open`) или закрытой (`closed`). |
| **Резюме** | Профиль соискателя: желаемая должность, опыт, навыки, город, ожидаемая зарплата. У соискателя одно резюме. |
| **Отклик** | Заявка соискателя на конкретную вакансию: сопроводительное письмо и статус рассмотрения (`new`, `viewed`, `invited`, `rejected`). |
| **Сессия** | Вход пользователя с одного устройства: пара access/refresh-токенов. Выход удаляет сессию, и оба токена сразу перестают работать. |
| **Просмотр** | Факт открытия карточки вакансии. Один пользователь даёт не больше одного просмотра в час. |

### Сущности и где они хранятся

| Сущность | Хранилище | За что отвечает |
|---|---|---|
| **Пользователь** | Postgres, `users` | Учётная запись и роль. Один и тот же тип записи для обеих ролей; роль решает, какие действия доступны. |
| **Вакансия** | Postgres, `vacancies` | Предложение работы. По вакансиям ищут, на них откликаются, их закрывают. |
| **Резюме** | Postgres, `resumes` | Профиль соискателя, который работодатель видит в каждом отклике. |
| **Отклик** | Postgres, `applications` | Связь «соискатель ↔ вакансия» со своими данными: письмо и статус. Через отклики стороны взаимодействуют. |
| **Сессия** | Redis, `session:{jti}` | Действующий вход. Данные временные: живут `JWT_REFRESH_TTL`. |
| **Просмотры** | Redis, `vacancy:views:{id}` | Счётчик просмотров вакансии. Не критичны: при сбое Redis показываем `0`. |

Постоянные бизнес-данные лежат в Postgres, временные и счётчики — в Redis. Подробности о ключах Redis — в разделе [Кэш и Redis](#кэш-и-redis).

### Схема БД

```mermaid
erDiagram
    USERS ||--o{ VACANCIES : "работодатель публикует 0..N"
    USERS ||--o| RESUMES : "соискатель ведёт 0..1"
    USERS ||--o{ APPLICATIONS : "соискатель подаёт 0..N"
    VACANCIES ||--o{ APPLICATIONS : "получает 0..N"

    USERS {
        bigint id PK
        text email UK "нижний регистр"
        text password_hash "bcrypt"
        text name "ФИО или компания"
        text role "employer | applicant"
        timestamptz created_at
    }
    VACANCIES {
        bigint id PK
        bigint employer_id FK "→ users.id"
        text title
        text description
        text city
        text employment_type "full | part | remote | internship"
        int salary_from "может быть NULL"
        int salary_to "может быть NULL"
        text_array tags "нижний регистр, до 10"
        text status "open | closed"
        timestamptz created_at
        timestamptz updated_at "версия для optimistic lock"
    }
    RESUMES {
        bigint applicant_id PK, FK "→ users.id"
        text title "желаемая должность"
        text about
        text city
        int experience_years "0..60"
        int salary_expectation "может быть NULL"
        text_array skills "до 20"
        timestamptz updated_at
    }
    APPLICATIONS {
        bigint id PK
        bigint vacancy_id FK "→ vacancies.id"
        bigint applicant_id FK "→ users.id"
        text cover_letter
        text status "new | viewed | invited | rejected"
        timestamptz created_at
        timestamptz updated_at "версия для optimistic lock"
    }
```

Как читать обозначения на линиях: `||` — ровно один, `o|` — ноль или один, `o{` — ноль или много.
Та же схема для [dbdiagram.io](https://dbdiagram.io) — [`assets/db_diagram.txt`](assets/db_diagram.txt) (вставьте текст файла на сайт), картинка — [`assets/db_diagram.png`](assets/db_diagram.png). Источник правды — SQL в [`migrations/`](migrations). Описания таблиц, допустимых значений и ограничений лежат и в самой БД (`COMMENT ON`, миграция `00003`): их видно в `\d+ vacancies` или в DBeaver.

### Связи между таблицами

| Связь | Кардинальность | Как устроена | При удалении родителя |
|---|---|---|---|
| работодатель → вакансии | **один ко многим** (1 : 0..N) | `vacancies.employer_id → users.id` | `CASCADE`: вакансии удаляются вместе с работодателем |
| соискатель → резюме | **один к одному**, необязательная (1 : 0..1) | `resumes.applicant_id` — одновременно первичный и внешний ключ | `CASCADE` |
| соискатель → отклики | **один ко многим** (1 : 0..N) | `applications.applicant_id → users.id` | `CASCADE` |
| вакансия → отклики | **один ко многим** (1 : 0..N) | `applications.vacancy_id → vacancies.id` | **`RESTRICT`**: удалить вакансию с откликами нельзя |
| соискатели ↔ вакансии | **многие ко многим** (M : N) | через таблицу `applications`, `UNIQUE (vacancy_id, applicant_id)` | — |

Что это значит на практике:

- **Работодатель → вакансии (1:N).** У одного работодателя сколько угодно вакансий, у каждой вакансии ровно один владелец. Только он может её менять, закрывать, удалять и смотреть отклики.
- **Соискатель → резюме (1:0..1).** Резюме может не быть (сразу после регистрации), но больше одного не бывает. Так получается потому, что первичный ключ `resumes` — это и есть `applicant_id`: вторая строка с тем же id невозможна. Поэтому сохранение резюме — `PUT` (создать или заменить), а не `POST`.
- **Соискатель → отклики (1:N).** Соискатель откликается на любое число вакансий и видит их все в «Мои отклики».
- **Вакансия → отклики (1:N).** На вакансию откликается любое число соискателей. Пока у вакансии есть хотя бы один отклик, её нельзя удалить (`RESTRICT`), только закрыть: иначе отклики пропали бы у соискателей из истории.
- **Соискатели ↔ вакансии (M:N).** Это связь «многие ко многим», и `applications` в ней — связующая таблица. Но у неё есть свои данные (письмо, статус, даты), поэтому отклик — полноценная сущность со своим `id`, а не просто пара ключей. `UNIQUE (vacancy_id, applicant_id)` даёт правило «один отклик от соискателя на вакансию» (повтор — `409`). После отзыва отклик удаляется, и откликнуться можно снова.

Чего БД не проверяет (это делает код):
- **Роль.** Внешний ключ проверяет только то, что пользователь существует. Что `employer_id` указывает на работодателя, а `applicant_id` на соискателя, гарантирует приложение: ручки работодателя доступны только роли `employer` (`RequireRole`), и сервис берёт id из токена.
- **Допустимые значения статусов, ролей и типов занятости.** Хранятся как `TEXT` без `CHECK`; правила в `model` (`Valid()`, `CanChangeTo`).
- **`CASCADE` по пользователю** сработает только при удалении пользователя напрямую в БД: ручки удаления аккаунта в API нет.

### Таблицы подробно

<details>
<summary><b>users</b> — учётные записи обеих ролей</summary>

| Колонка | Тип | Ограничения | Смысл |
|---|---|---|---|
| `id` | `BIGSERIAL` | PK | id пользователя, он же `sub` в JWT |
| `email` | `TEXT` | `NOT NULL`, `UNIQUE` | логин; приводится к нижнему регистру, поэтому уникален без учёта регистра |
| `password_hash` | `TEXT` | `NOT NULL` | bcrypt-хеш пароля; сам пароль не хранится |
| `name` | `TEXT` | `NOT NULL` | ФИО соискателя или название компании; показывается в вакансиях и откликах |
| `role` | `TEXT` | `NOT NULL` | `employer` или `applicant`, задаётся при регистрации и не меняется |
| `created_at` | `TIMESTAMPTZ` | `DEFAULT now()` | дата регистрации |

</details>

<details>
<summary><b>vacancies</b> — вакансии работодателей</summary>

| Колонка | Тип | Ограничения | Смысл |
|---|---|---|---|
| `id` | `BIGSERIAL` | PK | |
| `employer_id` | `BIGINT` | `NOT NULL`, FK → `users.id`, `CASCADE` | владелец вакансии |
| `title`, `description` | `TEXT` | `NOT NULL` | должность и описание; по ним ищет параметр `q` |
| `city` | `TEXT` | `NOT NULL` | город; поиск по нему без учёта регистра |
| `employment_type` | `TEXT` | `NOT NULL` | `full`, `part`, `remote`, `internship` |
| `salary_from`, `salary_to` | `INT` | могут быть `NULL` | вилка зарплаты; можно указать одну границу или не указывать ни одной |
| `tags` | `TEXT[]` | `NOT NULL`, `DEFAULT '{}'` | теги (технологии, навыки) в нижнем регистре, до 10; поиск по тегам требует все указанные |
| `status` | `TEXT` | `NOT NULL` | `open` или `closed` |
| `created_at` | `TIMESTAMPTZ` | | сортировка выдачи: новые сверху |
| `updated_at` | `TIMESTAMPTZ` | | время последнего изменения и версия строки для optimistic lock |

Индексы: `employer_id` (мои вакансии), `(status, created_at DESC)` (поиск открытых, новые сверху), GIN по `tags` (поиск по тегам).

</details>

<details>
<summary><b>resumes</b> — резюме соискателей</summary>

| Колонка | Тип | Ограничения | Смысл |
|---|---|---|---|
| `applicant_id` | `BIGINT` | PK, FK → `users.id`, `CASCADE` | владелец; то, что это первичный ключ, даёт «одно резюме на соискателя» |
| `title` | `TEXT` | `NOT NULL` | желаемая должность |
| `about` | `TEXT` | `NOT NULL` | о себе |
| `city` | `TEXT` | `NOT NULL` | город |
| `experience_years` | `INT` | `NOT NULL` | опыт, 0..60 лет |
| `salary_expectation` | `INT` | может быть `NULL` | ожидаемая зарплата |
| `skills` | `TEXT[]` | `NOT NULL`, `DEFAULT '{}'` | навыки в нижнем регистре, до 20 |
| `updated_at` | `TIMESTAMPTZ` | | когда резюме меняли последний раз |

Отдельного `id` нет: резюме всегда находится по соискателю.

</details>

<details>
<summary><b>applications</b> — отклики (связь соискателей и вакансий)</summary>

| Колонка | Тип | Ограничения | Смысл |
|---|---|---|---|
| `id` | `BIGSERIAL` | PK | id отклика: по нему работодатель меняет статус, а соискатель отзывает |
| `vacancy_id` | `BIGINT` | `NOT NULL`, FK → `vacancies.id`, `RESTRICT` | на какую вакансию |
| `applicant_id` | `BIGINT` | `NOT NULL`, FK → `users.id`, `CASCADE` | кто откликнулся |
| `cover_letter` | `TEXT` | `NOT NULL` | сопроводительное письмо |
| `status` | `TEXT` | `NOT NULL` | `new`, `viewed`, `invited`, `rejected` |
| `created_at` | `TIMESTAMPTZ` | | когда подан; сортировка списков |
| `updated_at` | `TIMESTAMPTZ` | | когда менялся статус; версия для optimistic lock |

Ограничения и индексы: `UNIQUE (vacancy_id, applicant_id)` — один отклик на вакансию (этот же индекс ускоряет «отклики на вакансию»), индекс `applicant_id` — «мои отклики».

</details>

Резюме в отклике не копируется: работодатель всегда видит **текущую** версию резюме соискателя (через `JOIN` по `applicant_id`). Если соискатель удалил резюме уже после отклика, в отклике приходит `resume: null`.

### Что умеет каждая роль

**Работодатель**

| Действие | Ручка | Правила |
|---|---|---|
| Опубликовать вакансию | `POST /employer/vacancies` | вакансия сразу `open` и видна в поиске; теги нормализуются, вилка проверяется (`salary_from <= salary_to`) |
| Посмотреть свои вакансии | `GET /employer/vacancies` | все свои, открытые и закрытые, новые сверху, с пагинацией |
| Изменить вакансию | `PUT /employer/vacancies/{id}` | только открытую и только свою; поля заменяются целиком |
| Закрыть вакансию | `POST /employer/vacancies/{id}/close` | вакансия уходит из поиска, новые отклики невозможны, поданные остаются; закрытие необратимо |
| Удалить вакансию | `DELETE /employer/vacancies/{id}` | только если на неё ни разу не откликались (или все отклики отозваны) |
| Посмотреть отклики | `GET /employer/vacancies/{id}/applications?status=` | по своей вакансии, с фильтром по статусу; к каждому отклику — имя соискателя и его текущее резюме |
| Принять решение | `PATCH /employer/applications/{id}/status` | `viewed`, `invited` или `rejected` по [диаграмме переходов](#жизненный-цикл-отклика) |
| Увидеть интерес к вакансии | `GET /vacancies/{id}` | владелец видит счётчик просмотров, свои заходы его не увеличивают |

**Соискатель**

| Действие | Ручка | Правила |
|---|---|---|
| Заполнить или обновить резюме | `PUT /applicant/resume` | создаёт или заменяет единственное резюме; навыки нормализуются |
| Посмотреть или удалить резюме | `GET` / `DELETE /applicant/resume` | после удаления откликнуться нельзя, пока не заполнить снова |
| Искать вакансии | `GET /vacancies?q=&city=&employment_type=&tags=&salary_from=` | только открытые; `q` — подстрока в названии или описании, `tags` — все указанные теги, `salary_from` — вилка достигает желаемой суммы |
| Открыть карточку | `GET /vacancies/{id}` | засчитывается просмотр; закрытая вакансия — `404` |
| Откликнуться | `POST /applicant/applications` | вакансия открыта, резюме заполнено, на эту вакансию ещё не откликался |
| Следить за откликами | `GET /applicant/applications` | статус каждого отклика, название вакансии, компания и открыта ли вакансия |
| Отозвать отклик | `DELETE /applicant/applications/{id}` | только в статусе `new`; отклик удаляется |

**Любой пользователь:** регистрация, вход, обновление токенов, выход, поиск и просмотр открытых вакансий (работодатель тоже может искать — например, смотреть вакансии конкурентов).

### Кто какие данные видит

| Данные | Работодатель | Соискатель |
|---|---|---|
| Открытые вакансии | все | все |
| Закрытая вакансия | только своя | не видит (`404`) |
| Отклики на вакансию | только на свои вакансии, вместе с резюме и именем соискателя | — |
| Свои отклики | — | все, со статусом и названием компании |
| Резюме соискателя | только в откликах на свои вакансии | только своё |
| Email и пароль других | никогда | никогда |
| Счётчик просмотров | у своих вакансий; у чужих — тоже, но тогда засчитывается просмотр | у любой открытой вакансии |

### Жизненный цикл вакансии

```mermaid
stateDiagram-v2
    [*] --> open: работодатель создал
    open --> open: редактирование
    open --> closed: работодатель закрыл
    open --> [*]: удаление, если нет откликов
    closed --> [*]: удаление, если нет откликов
```

| Статус | В поиске | Карточку видят | Откликнуться | Редактировать | Разбирать отклики |
|---|---|---|---|---|---|
| `open` | да | все | да | да | да |
| `closed` | нет | только владелец (остальным `404`) | нет (`404`) | нет (`409`) | да |

Закрытие необратимо: открыть вакансию снова нельзя. Удалить можно только вакансию без откликов, иначе она остаётся в истории соискателей. Закрытая вакансия перестаёт собирать отклики, но поданные можно разбирать дальше.

### Жизненный цикл отклика

```mermaid
stateDiagram-v2
    [*] --> new: соискатель откликнулся
    new --> viewed: работодатель посмотрел
    new --> invited: работодатель пригласил
    new --> rejected: работодатель отказал
    viewed --> invited
    viewed --> rejected
    new --> [*]: соискатель отозвал (отклик удаляется)
    invited --> [*]
    rejected --> [*]
```

| Статус | Что значит | Кто меняет дальше |
|---|---|---|
| `new` | подан, работодатель ещё не смотрел | работодатель → `viewed` / `invited` / `rejected`; соискатель может отозвать |
| `viewed` | работодатель посмотрел и думает | работодатель → `invited` / `rejected` |
| `invited` | приглашение на собеседование, финальное решение | — |
| `rejected` | отказ, финальное решение | — |

- Статус меняет только владелец вакансии. Назад (`viewed → new`) и из финальных статусов перейти нельзя (`409`). Повтор того же статуса — не ошибка (`204`).
- Отозвать можно только `new`. Иначе соискатель мог бы отозвать отклик и подать заново, сбросив решение работодателя. После отзыва можно откликнуться снова.

### Процесс найма целиком

```mermaid
sequenceDiagram
    autonumber
    actor E as Работодатель
    participant API as job-board API
    actor A as Соискатель

    E->>API: POST /employer/vacancies
    API-->>E: 201, вакансия open — сразу в поиске
    A->>API: PUT /applicant/resume
    A->>API: GET /vacancies?q=go&tags=go,sql
    API-->>A: только открытые вакансии
    A->>API: GET /vacancies/{id}
    API-->>A: карточка, засчитан просмотр
    A->>API: POST /applicant/applications (vacancy_id, cover_letter)
    Note over API: вакансия открыта? резюме есть? ещё не откликался?
    API-->>A: 201, отклик new
    E->>API: GET /employer/vacancies/{id}/applications?status=new
    API-->>E: отклики с текущим резюме соискателя
    E->>API: PATCH /employer/applications/{id}/status (invited)
    A->>API: GET /applicant/applications
    API-->>A: статус invited
    E->>API: POST /employer/vacancies/{id}/close
    Note over API: вакансия уходит из поиска, отклики остаются
```

### Домены и зоны ответственности

Бизнес-логика разделена на три сервиса (`internal/service`). Каждый отвечает за свою сторону процесса и знает только нужные ему репозитории.

| Домен | Пакет | Отвечает за | Сущности | Ручки |
|---|---|---|---|---|
| **auth** | `service/auth` | регистрацию, вход, выпуск и обмен токенов, проверку токена на каждом запросе, выход | пользователь, сессия | `/sign-up`, `/login`, `/refresh`, `/logout`, middleware `Auth` |
| **employer** | `service/employer` | вакансии работодателя (создать, изменить, закрыть, удалить) и разбор откликов на них | вакансия, отклик (чтение и смена статуса) | `/employer/*` |
| **applicant** | `service/applicant` | поиск и карточку вакансии, резюме, подачу и отзыв откликов | вакансия (чтение), резюме, отклик, просмотры | `/vacancies`, `/applicant/*` |

Кто чем владеет: вакансия принадлежит работодателю (`employer_id`), резюме и отклик — соискателю (`applicant_id`). Сервис проверяет владельца на каждом действии. Чужой ресурс неотличим от несуществующего (`404`): так нельзя перебором узнать чужие id.

---

## Стек

| Задача | Инструмент |
|---|---|
| HTTP | стандартный `net/http` (`ServeMux` с методами и `{id}` в шаблонах) |
| База данных | PostgreSQL 16, [pgx/v5](https://github.com/jackc/pgx) |
| Миграции | [goose](https://github.com/pressly/goose), файлы вшиты в бинарник через `embed` |
| Кэш и сессии | Redis 7, [go-redis/v9](https://github.com/redis/go-redis) |
| Аутентификация | JWT HS256 ([golang-jwt/v5](https://github.com/golang-jwt/jwt)), сессии в Redis, bcrypt |
| Валидация | [validator/v10](https://github.com/go-playground/validator) + правила в доменных моделях |
| Конфигурация | [godotenv](https://github.com/joho/godotenv) (`.env`) + [envconfig](https://github.com/kelseyhightower/envconfig) (переменные окружения) |
| Логи | `log/slog`: logfmt в файл локально, JSON в stdout в проде |
| Тесты | [testify](https://github.com/stretchr/testify), моки [mockery v3](https://vektra.github.io/mockery/) |
| Документация | OpenAPI 3 + [http-swagger](https://github.com/swaggo/http-swagger) |

---

## Быстрый старт

**Нужно:** Go 1.27+, Docker и Docker Compose. Для `make db-schema` ничего ставить не надо. mockery и goose ставит `make setup`
(`$(go env GOPATH)/bin` должен быть в `PATH`). Если `make` нет, те же команды собраны в [`assets/commands.txt`](assets/commands.txt).

### Вариант 1. Локальная разработка

Postgres и Redis в Docker, приложение запускается из исходников.

```bash
make infra-up     # Postgres и Redis в Docker, ждём healthcheck
make db-schema    # накатить схему без goose (или make migrate при MIGRATIONS_ENABLED=true)
make run          # приложение: go run ./cmd/api
```

Конфиг берётся из `.env`: `cp .env.example .env` (в `.env.example` стоит dev-секрет, для реального окружения замените).

### Вариант 2. Всё в Docker

```bash
JWT_SECRET=$(openssl rand -hex 32) make up   # Postgres, Redis, миграции (сервис migrate) и приложение
make down                                    # остановить
```

Данные Postgres и Redis лежат в volume `pgdata` и `redisdata` и переживают перезапуск контейнеров (Redis пишет AOF, поэтому сессии не теряются). Снести всё с данными: `make db-reset`.
Порты Postgres и Redis открыты только на `127.0.0.1`. В образе по умолчанию `APP_ENV=prod` (JSON-логи в stdout), процесс работает не под root, при остановке Docker ждёт graceful shutdown до 15 секунд.

### Вариант 3. Демо с нуля одной командой

```bash
make demo     # удалить всё (контейнеры, данные, образ приложения), собрать и поднять заново, накатить схему
make logs     # смотреть логи приложения
make clean    # после демо: удалить всё
```

`make demo` начинается с удаления данных, поэтому на базе с нужными данными его не запускайте. Чем отличаются `down`, `clean-data` и `clean`, написано в комментариях `Makefile` и в таблице раздела [Разработка](#разработка).

### Проверить, что всё работает

```bash
curl -s http://localhost:8080/health
# {"status":"ok"}
```

| Адрес | Что там |
|---|---|
| http://localhost:8080/api/docs | Swagger UI: можно вызывать ручки прямо из браузера |
| http://localhost:8080/docs/openapi.yaml | спецификация OpenAPI |
| http://localhost:8080/health | состояние Postgres и Redis: `200` или `503` |

**Postman:** `Import` → вставьте URL `http://localhost:8080/docs/openapi.yaml`. В телах запросов уже стоят рабочие примеры.

---

## Как устроен проект

### Архитектура

Запрос проходит слои сверху вниз. Каждый слой знает нижний только через интерфейс, поэтому сервисы тестируются с моками, без базы.

```mermaid
flowchart TB
    client([Клиент: Swagger, Postman, curl])

    subgraph handlerLayer["internal/handler: HTTP"]
        mw["middleware: RequestID, Recover, Logging, CORS, Timeout, Auth, RequireRole"]
        v1["v1: хендлеры и DTO, валидация формата"]
        httpx["httpx: JSON-ответы, ошибки в HTTP-коды"]
    end

    subgraph serviceLayer["internal/service: бизнес-логика"]
        authSvc["auth"]
        empSvc["employer"]
        appSvc["applicant"]
    end

    subgraph repoLayer["internal/repository: доступ к данным"]
        cache["redisrepo: кэш вакансий (декоратор над pgrepo)"]
        sessions["redisrepo: сессии"]
        views["redisrepo: просмотры"]
        pg["pgrepo: SQL"]
    end

    pgdb[(PostgreSQL)]
    rdb[(Redis)]

    client --> mw --> v1
    v1 -.-> httpx
    v1 --> authSvc & empSvc & appSvc
    authSvc --> pg & sessions
    empSvc --> cache & pg
    appSvc --> cache & pg & views
    cache --> pg
    cache & sessions & views --> rdb
    pg --> pgdb
```

### Жизненный цикл запроса

Middleware оборачивают роутер в таком порядке, снаружи внутрь (`internal/handler/router.go`). Ответ идёт обратно тем же путём.

| # | Шаг | Что делает | Чем может ответить сам |
|---|---|---|---|
| 1 | `RequestID` | берёт id из заголовка `X-Request-ID` или генерирует UUID; кладёт его в context (попадёт во все строки лога) и в заголовок ответа | — |
| 2 | `Recover` | ловит панику ниже по цепочке, пишет `panic recovered` со стеком | `500` |
| 3 | `Logging` | после ответа пишет строку `http request`: метод, путь, статус, длительность | — |
| 4 | `CORS` | для разрешённого `Origin` добавляет CORS-заголовки ([подробнее](#cors)) | `204` на preflight `OPTIONS` |
| 5 | `Timeout` | кладёт в context дедлайн `HTTP_REQUEST_TIMEOUT`, его видят Postgres и Redis | — (истёкший дедлайн даёт `503`) |
| 6 | `ServeMux` | выбирает ручку по методу и пути | `404`, `405` |
| 7 | `Auth` | все ручки `/api/v1`, кроме sign-up, login, refresh, logout: подпись, срок и тип JWT, сессия в Redis; claims в context | `401` |
| 8 | `RequireRole` | ручки `/employer/*` и `/applicant/*`: сверяет роль из токена | `403` |
| 9 | Handler `v1` | разбирает JSON и параметры в DTO, проверяет формат, вызывает сервис, отдаёт DTO | `400` |
| 10 | Service → Repository | бизнес-правила, владелец, данные из Redis и Postgres | `404`, `409`, `422`, `500`, `503` |

Любой ответ с ошибкой на шагах 7–10 проходит через `httpx`, который пишет в лог строку `request failed` с причиной.
На примере `GET /api/v1/vacancies/10`:

```mermaid
sequenceDiagram
    autonumber
    participant C as Клиент
    participant M as Middleware
    participant H as Handler v1
    participant S as Service
    participant R as Repository
    participant D as Postgres / Redis

    C->>M: GET /api/v1/vacancies/10, Bearer access
    M->>M: RequestID, Recover, Logging, CORS, Timeout (дедлайн в context)
    M->>S: Auth: подпись, срок и сессия в Redis
    M->>H: claims в context, роль проверена
    H->>S: GetVacancy(ctx, id, userID)
    S->>R: GetByID: сначала кэш, потом Postgres
    R->>D: GET vacancy:10 / SELECT ...
    D-->>R: данные или ошибка
    R-->>S: *model.Vacancy или ошибка, обёрнутая через %w
    S-->>H: результат или ошибка (клиентская — *model.Error)
    H-->>C: 200 JSON или {"error": "..."} с кодом из httpx, заголовок X-Request-ID
    M->>M: строка лога http request (и request failed при ошибке), обе с request_id
```

### CORS

Браузер не даёт странице с одного origin (фронт на `http://localhost:3000`) читать ответы API с другого (`http://localhost:8080`), пока API явно этого не разрешит. Это и делает middleware `CORS`. curl, Postman и Swagger UI (он открыт с того же origin) CORS не касается.

- Разрешённые origin задаются в `CORS_ALLOWED_ORIGINS` через запятую. Пусто — CORS выключен.
- Для разрешённого origin в ответ добавляются `Access-Control-Allow-Origin: <этот origin>` (не `*`), `Access-Control-Expose-Headers: X-Request-ID` (чтобы фронт мог прочитать id запроса) и `Vary: Origin`.
- Перед запросом с `Authorization` или JSON браузер шлёт preflight `OPTIONS`. На него сразу отвечаем `204` со списком методов и заголовков (`Authorization`, `Content-Type`, `X-Request-ID`); браузер запоминает ответ на 10 минут.
- Чужому origin заголовки не выставляются, и браузер не отдаст ему ответ. Cookies не используются (токен идёт в `Authorization`), поэтому `Allow-Credentials` не нужен.

### Структура каталогов

```
.
├── cmd/
│   ├── api/main.go           # HTTP API: app.Run()
│   └── migrate/main.go       # шаг миграций: app.Migrate(), применяет goose и завершается
├── internal/
│   ├── app/                  # сборка зависимостей, запуск и graceful shutdown
│   ├── config/               # загрузка и проверка конфигурации (envconfig)
│   ├── handler/              # роутер, health, Swagger
│   │   ├── middleware/       # request id, recover, логирование, CORS, таймаут, токен и роль
│   │   ├── httpx/            # JSON-ответы, маппинг ошибок в HTTP-коды, пагинация
│   │   └── v1/               # ручки и DTO версии v1
│   ├── service/              # бизнес-логика: auth, employer, applicant + их интерфейсы
│   ├── repository/           # интерфейсы репозиториев и моки
│   │   ├── pgrepo/           # реализация на Postgres
│   │   └── redisrepo/        # кэш-декоратор вакансий, счётчик просмотров, сессии
│   └── model/                # доменные типы, правила валидности, клиентские ошибки (model.Error)
├── pkg/                      # переиспользуемое, не зависит от internal
│   ├── cache/                # интерфейс Cache + клиент Redis
│   ├── database/             # интерфейс DB + клиент Postgres и запуск миграций
│   ├── logger/               # slog: logfmt в файл или JSON в stdout
│   └── retry/                # повтор подключения при старте
├── migrations/               # SQL-миграции goose (вшиваются в бинарник)
├── docs/                     # спецификация OpenAPI (вшивается в бинарник)
└── assets/                   # схема БД: картинка и исходник для dbdiagram.io
```

### Принципы

- **Зависимости направлены вниз.** `handler → service → repository → model`. Интерфейсы репозиториев лежат в `internal/repository`, интерфейсы сервисов в `internal/service`. Все зависимости собираются вручную в `internal/app`.
- **Модели без json-тегов.** Формат API задают DTO в `handler/v1`. Несовместимая версия API добавляется как `handler/v2` над теми же сервисами.
- **Две валидации.** Форма запроса (обязательные поля, длина, формат) проверяется в handler и даёт `400`.
  Бизнес-правила и нормализация (trim, lowercase email, теги) живут в конструкторах `model` (`NewUser`, `NewVacancy`, `NewResume`, `NewApplication`) и дают `422` или `409`.
  Сервис добавляет проверку владельца (чужой ресурс даёт `404`) и проверки по данным из БД.
- **Ошибки.** Клиентские ошибки это `*model.Error` (вид + текст для клиента), создаются конструкторами `model.NotFound`, `Conflict`, `InvalidInput`, `Unauthorized`. Виды: `ErrNotFound`, `ErrConflict`, `ErrInvalidInput`, `ErrUnauthorized`.
  Каждый слой добавляет контекст через `fmt.Errorf("op: %w", err)`, не теряя цепочку. В HTTP-коды ошибки переводятся в одном месте, `httpx.WriteServiceError`: статус по виду, текст `Msg` уходит клиенту как есть, сколько бы раз ошибку ни обернули.
- **Клиенту и в лог идут разные тексты.** Клиент получает текст клиентских ошибок (401/404/409/422) как есть, а вместо внутренних `internal server error`. Причина любого ответа с ошибкой (400–5xx, включая полную цепочку ошибки сервиса) пишется в лог отдельной строкой `request failed`.
- **Логирование только в HTTP-слое.** Одна строка на запрос, уровень по статусу (5xx `ERROR`, 4xx `WARN`, остальное `INFO`); на любой ответ с ошибкой `httpx` добавляет строку `request failed` с причиной (4xx `WARN`, 5xx `ERROR`). Обе строки связаны полем `request_id`.
  Исключение: кэш вакансий и просмотры в `redisrepo` переживают сбой Redis и сами пишут `WARN`.
- **Репозиторий выполняет простой SQL без бизнес-условий.** Конкурентные изменения вакансии и отклика ловит optimistic lock: `UPDATE/DELETE ... WHERE id = $1 AND updated_at = $2`, при нуле строк ответ `409` (`... was changed, try again`). Бизнес-правила (только открытые вакансии в поиске, вакансию с откликами нельзя удалить) проверяет сервис. `GETDEL` в Redis не оставляет окна при refresh.

---

## API

Базовый путь `/api/v1`. Все ручки, кроме регистрации, входа, `/refresh` и `/logout`, требуют заголовок
`Authorization: Bearer <access_token>`. Описание полей: [`docs/openapi.yaml`](docs/openapi.yaml) или Swagger UI.

| Метод | Путь | Роль | Описание | Успех |
|---|---|---|---|---|
| `POST` | `/sign-up` | — | регистрация | `201 {"id"}` |
| `POST` | `/login` | — | вход, возвращает пару токенов | `200` |
| `POST` | `/refresh` | — | обменять refresh-токен на новую пару | `200` |
| `POST` | `/logout` | — | завершить сессию | `204` |
| `GET` | `/vacancies` | любая | поиск открытых вакансий | `200` |
| `GET` | `/vacancies/{id}` | любая | карточка вакансии со счётчиком просмотров | `200` |
| `POST` | `/employer/vacancies` | employer | создать вакансию | `201 {"id"}` |
| `GET` | `/employer/vacancies` | employer | мои вакансии | `200` |
| `PUT` | `/employer/vacancies/{id}` | employer | обновить вакансию | `204` |
| `POST` | `/employer/vacancies/{id}/close` | employer | закрыть вакансию | `204` |
| `DELETE` | `/employer/vacancies/{id}` | employer | удалить вакансию | `204` |
| `GET` | `/employer/vacancies/{id}/applications` | employer | отклики на вакансию (фильтр `?status=`) | `200` |
| `PATCH` | `/employer/applications/{id}/status` | employer | сменить статус отклика | `204` |
| `PUT` | `/applicant/resume` | applicant | создать или обновить резюме | `204` |
| `GET` | `/applicant/resume` | applicant | моё резюме | `200` |
| `DELETE` | `/applicant/resume` | applicant | удалить резюме | `204` |
| `POST` | `/applicant/applications` | applicant | откликнуться на вакансию | `201 {"id"}` |
| `GET` | `/applicant/applications` | applicant | мои отклики | `200` |
| `DELETE` | `/applicant/applications/{id}` | applicant | отозвать отклик | `204` |

**Поиск** `GET /vacancies`: `q`, `city`, `employment_type` (`full`, `part`, `remote`, `internship`), `tags` (через запятую), `salary_from`.

**Списки** принимают `limit` (по умолчанию 20, максимум 100) и `offset` и возвращают `{"items": [...], "total": N}`.

**Ошибки** всегда приходят в формате `{"error": "..."}`:

| Код | Когда |
|---|---|
| `400` | битый JSON, лишнее или пустое обязательное поле, неверный формат параметра |
| `401` | нет токена, токен недействителен или отозван, неверный email или пароль |
| `403` | не та роль |
| `404` | ресурс не найден или принадлежит другому пользователю |
| `409` | дубль email или отклика, недопустимый переход статуса, закрытая вакансия, вакансия с откликами, нет резюме для отклика, конкурентное изменение вакансии или отклика (`... was changed, try again`) |
| `422` | нарушено бизнес-правило: неизвестное значение enum, зарплата, лимиты |
| `500` | внутренняя ошибка, в том числе недоступен Redis на защищённых ручках |
| `503` | запрос не уложился в `HTTP_REQUEST_TIMEOUT` |

<details>
<summary><b>Пример полного сценария на curl</b></summary>

Нужен `jq`.

```bash
API=http://localhost:8080/api/v1

# регистрация и вход
curl -s -X POST $API/sign-up -d '{"email":"hr@acme.io","password":"Secret123","name":"Acme","role":"employer"}'
curl -s -X POST $API/sign-up -d '{"email":"dev@mail.io","password":"Secret123","name":"Иван Петров","role":"applicant"}'
EMP=$(curl -s -X POST $API/login -d '{"email":"hr@acme.io","password":"Secret123"}' | jq -r .access_token)
APP=$(curl -s -X POST $API/login -d '{"email":"dev@mail.io","password":"Secret123"}' | jq -r .access_token)

# работодатель публикует вакансию
curl -s -X POST $API/employer/vacancies -H "Authorization: Bearer $EMP" \
  -d '{"title":"Go developer","description":"Backend","city":"Moscow","employment_type":"remote","salary_from":200000,"salary_to":300000,"tags":["go","postgres"]}'

# соискатель заполняет резюме, ищет вакансию и откликается
curl -s -X PUT $API/applicant/resume -H "Authorization: Bearer $APP" \
  -d '{"title":"Go developer","about":"3 года на Go","city":"Moscow","experience_years":3,"skills":["go","sql"]}'
curl -s "$API/vacancies?q=go&tags=go,postgres&salary_from=250000" -H "Authorization: Bearer $APP"
curl -s $API/vacancies/1 -H "Authorization: Bearer $APP"
curl -s -X POST $API/applicant/applications -H "Authorization: Bearer $APP" \
  -d '{"vacancy_id":1,"cover_letter":"Здравствуйте!"}'

# работодатель смотрит отклики и приглашает кандидата
curl -s $API/employer/vacancies/1/applications -H "Authorization: Bearer $EMP"
curl -s -X PATCH $API/employer/applications/1/status -H "Authorization: Bearer $EMP" -d '{"status":"invited"}'

# обновление пары и выход (refresh-токен одноразовый)
REFRESH=$(curl -s -X POST $API/login -d '{"email":"dev@mail.io","password":"Secret123"}' | jq -r .refresh_token)
REFRESH=$(curl -s -X POST $API/refresh -d "{\"refresh_token\":\"$REFRESH\"}" | jq -r .refresh_token)
curl -s -X POST $API/logout -d "{\"refresh_token\":\"$REFRESH\"}"
```

</details>

---

## Аутентификация

```mermaid
sequenceDiagram
    participant C as Клиент
    participant A as API
    participant P as Postgres
    participant R as Redis

    C->>A: POST /login (email, password)
    A->>P: найти пользователя, сверить bcrypt
    A->>R: SET session:{jti} = user_id, TTL = JWT_REFRESH_TTL
    A-->>C: access + refresh (в обоих jti = id сессии)

    C->>A: любой защищённый запрос с Bearer access
    A->>R: GET session:{jti}: сессия жива и принадлежит sub?
    A-->>C: ответ

    C->>A: POST /refresh (refresh)
    A->>R: проверить сессию
    A->>P: взять актуальную роль
    A->>R: GETDEL session:{jti}: старая пара умирает
    A->>R: SET session:{новый jti}
    A-->>C: новая пара

    C->>A: POST /logout (refresh)
    A->>R: DEL session:{jti}
    A-->>C: 204
```

- `/login` возвращает два JWT, подписанных `JWT_SECRET` (HS256): access (по умолчанию 1 час, `JWT_ACCESS_TTL`) и refresh (30 дней, `JWT_REFRESH_TTL`).
  В обоих `sub` это id пользователя, `jti` это id сессии, `typ` это `access` или `refresh`. Refresh не принимается вместо access и наоборот.
- Каждый защищённый запрос проверяет подпись, алгоритм, срок, тип и наличие сессии. Сессия должна принадлежать `sub`.
- `/refresh` забирает сессию атомарно (`GETDEL`), поэтому из двух параллельных обменов одним токеном пройдёт один. Повторный `/refresh` тем же токеном даёт `401`.
- `/refresh` и `/logout` отзывают сразу и access, и refresh, не дожидаясь истечения access.
- `/logout` идемпотентен: невалидный токен или уже закрытая сессия дают `204` без действия; `400`, если нет поля `refresh_token`.
- Для неизвестного email `/login` всё равно считает bcrypt, чтобы по времени ответа нельзя было узнать, зарегистрирован ли адрес.
- `JWT_SECRET` должен быть не короче 32 байт (`openssl rand -hex 32`). В `docker-compose.yml` значения по умолчанию нет: `JWT_SECRET=... make up`.

---

## Бизнес-правила

Роли, статусы, доступ и процесс найма описаны в [Бизнес-модели](#бизнес-модель). Здесь — лимиты и проверка данных (нарушение даёт `422`, неверный формат — `400`).

| Что | Правило |
|---|---|
| Email | уникален без учёта регистра; домен должен оканчиваться на существующую зону (`a@b.qnxt` → `400`); существование ящика не проверяется |
| Пароль | 8–64 символа и не больше 72 байт (лимит bcrypt), без пробелов, минимум одна заглавная, одна строчная буква и одна цифра |
| Зарплата вакансии | от 0 до 1 000 000 000, `salary_from <= salary_to`, любая граница может отсутствовать |
| Теги вакансии | до 10, в нижнем регистре, дубли удаляются |
| Резюме | до 20 навыков (нормализуются как теги), опыт 0..60 лет, ожидаемая зарплата от 0 до 1 000 000 000 |
| Поиск | `q` и `city` обрезаются по краям, `city` без учёта регистра, до 10 тегов |
| Отклик | один на вакансию от соискателя (`409`), нужно резюме (`409`) |

---

## Кэш и Redis

| Ключ | TTL | Назначение |
|---|---|---|
| `vacancy:{id}` | `CACHE_VACANCY_TTL` (5m) | карточка вакансии. После Update/UpdateStatus перечитывается из БД и записывается в кэш; удалённая помечается tombstone, чтобы запоздалый читатель её не «воскресил» |
| `vacancies:search:{hash}` | `CACHE_SEARCH_TTL` (60s) | результаты поиска. Не инвалидируются, поэтому могут отставать до `CACHE_SEARCH_TTL` |
| `vacancy:views:{id}` | — | счётчик просмотров |
| `vacancy:viewed:{id}:{user_id}` | 1h | отметка просмотра: один пользователь даёт один просмотр в час |
| `session:{jti}` | `JWT_REFRESH_TTL` | сессия (`user_id`) |

Если Redis недоступен, кэш вакансий и просмотры деградируют: запросы идут в Postgres, просмотры возвращаются как `0`, в лог пишется `WARN`.
Сессии не деградируют: без Redis нельзя ни проверить, ни отозвать токен, поэтому защищённые ручки отвечают `500`.

---

## Конфигурация

Источники по приоритету: **переменные окружения → `.env` → значения по умолчанию из кода**.
`.env` из рабочей директории подхватывает `godotenv/autoload` (уже заданные переменные окружения он не перезаписывает), в структуры читает `envconfig`. Шаблон: `.env.example`, локально `cp .env.example .env`.
При старте конфиг проверяется (секрет, положительные таймауты, `HTTP_WRITE_TIMEOUT > HTTP_REQUEST_TIMEOUT`), и при ошибке приложение не запускается.

> **Про секреты.** В реальных проектах секреты нельзя хранить в конфигах в открытом виде: их передают через переменные окружения или секрет-хранилище.
> Файл `.env` в git не попадает; в репозитории лежит только шаблон `.env.example` с dev-значениями.

<details>
<summary><b>Все переменные</b></summary>

| Переменная | По умолчанию | Описание |
|---|---|---|
| `APP_ENV` | `local` | `local`: logfmt в файл `LOG_FILE`; любое другое значение (например `prod`): JSON в stdout |
| `LOG_LEVEL` | `info` | `debug`, `info`, `warn`, `error`; неверное значение: приложение не запустится |
| `LOG_FILE` | `logs.txt` | файл для логов, используется только при `APP_ENV=local` |
| `HTTP_PORT` | `8080` | порт HTTP-сервера |
| `HTTP_READ_HEADER_TIMEOUT` | `5s` | чтение заголовков запроса |
| `HTTP_READ_TIMEOUT` | `10s` | чтение всего запроса |
| `HTTP_WRITE_TIMEOUT` | `25s` | запись ответа; должен быть больше `HTTP_REQUEST_TIMEOUT` |
| `HTTP_IDLE_TIMEOUT` | `60s` | простой keep-alive соединения |
| `HTTP_REQUEST_TIMEOUT` | `20s` | дедлайн обработки запроса, после него `503 request timeout` |
| `HTTP_SHUTDOWN_TIMEOUT` | `10s` | время на завершение активных запросов при остановке |
| `CORS_ALLOWED_ORIGINS` | пусто | origin фронтенда через запятую (`http://localhost:3000,https://app.example.com`); пусто — CORS выключен |
| `JWT_SECRET` | — | **обязательна**, секрет подписи JWT, не короче 32 байт |
| `JWT_ACCESS_TTL` | `1h` | время жизни access-токена |
| `JWT_REFRESH_TTL` | `720h` | время жизни refresh-токена и сессии (30 дней) |
| `MIGRATIONS_ENABLED` | `false` | только для `cmd/migrate`: `true` — миграции применяет goose, `false` — goose не запускается, схему накатывает `make db-schema`. API этот флаг не читает |
| `CACHE_VACANCY_TTL` | `5m` | TTL карточки вакансии в Redis |
| `CACHE_SEARCH_TTL` | `60s` | TTL результатов поиска в Redis |
| `POSTGRES_HOST` | `localhost` | хост Postgres |
| `POSTGRES_PORT` | `5432` | порт Postgres |
| `POSTGRES_USER` | `jobboard` | пользователь |
| `POSTGRES_PASSWORD` | `jobboard` | пароль |
| `POSTGRES_DB` | `jobboard` | имя базы |
| `POSTGRES_SSLMODE` | `disable` | режим SSL |
| `POSTGRES_MAX_CONNS` | `10` | размер пула соединений |
| `POSTGRES_CONNECT_RETRIES` | `3` | попыток подключения при старте (пауза растёт: 1s, 2s, ...) |
| `POSTGRES_CONNECT_TIMEOUT` | `5s` | таймаут подключения |
| `REDIS_HOST` | `localhost` | хост Redis |
| `REDIS_PORT` | `6379` | порт Redis |
| `REDIS_PASSWORD` | пусто | пароль Redis |
| `REDIS_DB` | `0` | номер базы Redis |
| `REDIS_POOL_SIZE` | `10` | размер пула соединений |
| `REDIS_CONNECT_RETRIES` | `3` | попыток подключения при старте |
| `REDIS_DIAL_TIMEOUT` | `5s` | таймаут подключения |
| `REDIS_READ_TIMEOUT` | `3s` | таймаут чтения |
| `REDIS_WRITE_TIMEOUT` | `3s` | таймаут записи |

</details>

**Миграции** — отдельный шаг, API их не применяет. Отдельный бинарник `cmd/migrate` применяет миграции goose (они вшиты через `embed`) и завершается: при деплое сначала `migrate`, потом API. Так несколько реплик API не мигрируют одновременно, а упавшая миграция останавливает выкатку, а не работающий сервис.

| Как | Когда | Что делает |
|---|---|---|
| сервис `migrate` в Docker Compose | `make up`, `make demo` | запускается перед `app`; `app` стартует, только если миграции прошли |
| `make migrate` | локально, `MIGRATIONS_ENABLED=true` в `.env` | goose применяет новые миграции и ведёт версии в таблице `goose_db_version` |
| `make db-schema` | локально, `MIGRATIONS_ENABLED=false` (по умолчанию) | без goose: секции `+goose Up` из `migrations/*.sql` через psql; все миграции идемпотентны |

Postgres и Redis должны быть доступны при старте: подключение повторяется, затем приложение завершается с ошибкой.

---

## Логи

| `APP_ENV` | Формат |
|---|---|
| `local` | logfmt (стандартный `slog.TextHandler`) в файл `LOG_FILE`: `time=2026-10-08T21:22:20.000+03:00 level=INFO msg="http request" method=GET path=/health status=200 duration=6.85ms` |
| любое другое (`prod`) | JSON в stdout, одна запись на строку (для сборщиков логов) |

- `local`: логи идут **только в файл** (`LOG_FILE`, по умолчанию `logs.txt`), консоль остаётся чистой. Иначе `LOG_FILE` не используется, логи в stdout (так в Docker).
- Если приложение падает при старте, `main` дополнительно печатает причину в stderr как `fatal: ...`, поэтому запуск не падает молча.
- На каждый HTTP-запрос пишется строка `http request` (`method`, `path`, `status`, `duration`), уровень по статусу.
- На любой ответ с ошибкой (`httpx.WriteError` / `WriteServiceError`) дополнительно пишется строка `request failed` с причиной в поле `err`: 4xx — `WARN`, 5xx (и 503 по таймауту) — `ERROR`. Для ошибок сервиса это полная цепочка (`get vacancy: vacancy not found`), для 400 — ошибка разбора (`unexpected EOF`), для 401/403 — почему отказано.
- У каждого запроса есть `request_id`: id из заголовка `X-Request-ID` запроса (если фронт или прокси его прислали) или новый UUID. Он есть во всех строках лога запроса (включая `WARN` кэша и панику) и возвращается в заголовке `X-Request-ID`. Найти всё по запросу: `grep <id> logs.txt`.

```text
level=WARN msg="request failed" method=GET path=/api/v1/vacancies/999999 status=404 err="get vacancy: vacancy not found" request_id=9f1c2b7e-3d4a-4f6b-8c2d-1e5a7b9c0d3f
level=WARN msg="http request" method=GET path=/api/v1/vacancies/999999 status=404 duration=5.3ms request_id=9f1c2b7e-3d4a-4f6b-8c2d-1e5a7b9c0d3f
```

---

## Разработка

| Команда | Что делает |
|---|---|
| `make run` | запустить приложение локально |
| `make test` | unit-тесты с `-race` и покрытием |
| `make setup` | установить mockery и goose CLI |
| `make mocks` | перегенерировать моки после изменения `internal/repository/repository.go` |
| `make infra-up` / `make infra-down` | поднять / остановить Postgres и Redis |
| `make db-reset` | пересоздать базу и Redis с нуля |
| `make migrate` | применить миграции goose (при `MIGRATIONS_ENABLED=true`) |
| `make db-schema` | накатить схему БД без goose |
| `make up` / `make down` | всё в Docker / остановить (данные и образы остаются) |
| `make ps` | статус контейнеров |
| `make logs` | последние 100 строк логов приложения и дальше в реальном времени; другой сервис и число строк: `make logs service=postgres lines=20` |
| `make docker-df` | сколько места занимает Docker (образы, volume, кэш сборки) |
| `make docker-prune` | безопасно освободить место: кэш сборки и «висячие» образы `<none>`; данные и используемые образы не трогает |
| `make clean-data` | удалить контейнеры и volume: **все данные Postgres и Redis**, без возможности отменить |
| `make clean` | как `clean-data` + образ приложения (образы postgres и redis остаются) |
| `make demo` | с нуля: `clean`, сборка образа, запуск всего стека, накат схемы |
| `make migration name=add_x` | создать миграцию |
| `make tidy` | `go mod tidy` |

**Новая фича:** порядок работы, ответственность слоёв, где какая валидация и как логировать — в [`assets/feature_rules.md`](assets/feature_rules.md).

**Тесты.** Unit-тесты в стиле table-driven покрывают бизнес-правила моделей и сервисов. Репозитории подменяются моками mockery (`.mockery.yaml`), база для тестов не нужна.

```bash
go test ./... -race -cover                                                   # все тесты
go test ./internal/service/employer -run 'TestService_ChangeApplicationStatus' -v   # один тест
```

**Redis вручную:**

```bash
docker compose exec redis redis-cli KEYS '*'
docker compose exec redis redis-cli TTL vacancy:1
docker compose exec redis redis-cli GET vacancy:views:1
```

**Изменили `openapi.yaml` или миграции?** Перезапустите приложение: эти файлы вшиваются в бинарник при сборке (`go:embed`).

---

## Решение проблем

| Симптом | Причина и решение |
|---|---|
| `fatal: load config: required key JWT_SECRET missing value` или `JWT_SECRET must be at least 32 bytes` | Секрет не задан или пустой (в Docker без `JWT_SECRET=...` он пустой). Задайте `JWT_SECRET` не короче 32 байт или создайте `.env`: `cp .env.example .env` |
| `fatal: connect to postgres: ...` или `connect to redis: ...` | Инфраструктура не запущена: `make infra-up` |
| Запросы отвечают `500`, в логе `relation "users" does not exist` | Не накатана схема: `make db-schema` или `make migrate` с `MIGRATIONS_ENABLED=true` |
| Все защищённые ручки отвечают `500` | Недоступен Redis: без него нельзя проверить сессию |
| В консоли нет логов | `APP_ENV=local`: логи в файле `LOG_FILE` (по умолчанию `logs.txt`) |
| Swagger показывает старую спецификацию | `openapi.yaml` вшит в бинарник, перезапустите приложение |
| Фронт в браузере получает CORS error | Добавьте его origin в `CORS_ALLOWED_ORIGINS` (точно, со схемой и портом: `http://localhost:3000`) |
| Свежей вакансии нет в поиске | Кэш поиска живёт до `CACHE_SEARCH_TTL` (60s) |
| `mockery: command not found` | `make setup` и добавьте `$(go env GOPATH)/bin` в `PATH` |

---

## Известные ограничения

- Кэш поиска не инвалидируется при изменении вакансий: выдача может отставать до 60 секунд.
- Просмотры хранятся только в Redis и обнуляются при его сбросе.
- Пагинация через `LIMIT/OFFSET`: на больших смещениях медленно, при вставках элементы могут «съезжать» между страницами.
- Нет rate limiting (например, на `/login`).
- Повтор подключения при старте без jitter.
- Отклик, поданный в ту же миллисекунду, когда вакансию закрывают, может пройти: вставка отклика не блокирует вакансию. Это осознанный компромисс ради простого SQL без бизнес-условий.
- Клиентский `X-Request-ID` принимается как есть (до 128 символов): им можно подписать свой запрос чужим id. Для поиска по логам это не опасно, но доверять ему как идентификатору нельзя.
- Шаг `migrate` не берёт блокировку в БД: запускайте его один раз на деплой, а не параллельно в нескольких копиях.
- Обрыв соединения клиентом (`context.Canceled`) классифицируется как `500` и пишется в лог как `ERROR`.
